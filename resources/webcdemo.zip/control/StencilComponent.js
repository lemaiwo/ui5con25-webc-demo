/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/webc/WebComponent"],function(t){"use strict";return t.extend("be.wl.webc.demo.control.StencilComponent",{invalidate:function(){if(this.getDomRef()&&this.getVisible()){t.prototype.setProperty.call(this,"visible",false,true);setTimeout(function(e,i){t.prototype.setProperty.call(this,"visible",true);setTimeout(window.scrollTo.bind(window,e,i),10)}.bind(this,window.scrollX,window.scrollY),1)}return t.prototype.invalidate.apply(this,arguments)},setProperty:function(e,i,o){var r=this.getDomRef()&&e in this.getDomRef();var s=t.prototype.setProperty.call(this,e,i,r);if(r){if(e!=="text"){this.getDomRef()[e]=this.getProperty(e)}else{this.getDomRef().text.textContent=this.getProperty(e)}}return s}})});
//# sourceMappingURL=StencilComponent.js.map