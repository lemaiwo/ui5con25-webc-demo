sap.ui.define(['exports'], (function (exports) { 'use strict';

    /* eslint-disable @typescript-eslint/no-explicit-any */
    /**
     * All properties that should be excluded from the deep copy of an HTML element.
     */
    const excludedProps = new Set([
        // Text and content-related properties
        'textContent',
        'innerText',
        'outerText',
        'innerHTML',
        'outerHTML',
        'text',
        // Form element properties
        'value',
        'defaultValue',
        'checked',
        'defaultChecked',
        'selectionStart',
        'selectionEnd',
        'selectionDirection',
        'form',
        'willValidate',
        'validity',
        'validationMessage',
        'labels',
        'list',
        'maxLength',
        'minLength',
        'valueAsDate',
        'valueAsNumber',
        // Editability and namespaces
        'contentEditable',
        'isContentEditable',
        'namespaceURI',
        // Child-related properties (handled recursively)
        'attributes',
        'children',
        'childNodes',
        'firstChild',
        'lastChild',
        // Blazor-related properties
        'origin',
        'dataset',
        'attributeStyleMap',
        'prefix',
        'localName',
        'tagName',
        'shadowRoot',
        'assignedSlot',
        'scrollWidth',
        'scrollHeight',
        'clientTop',
        'clientLeft',
        'clientWidth',
        'clientHeight',
        'firstElementChild',
        'lastElementChild',
        'childElementCount',
        'previousElementSibling',
        'nextElementSibling',
        'currentCSSZoom',
        'nodeType',
        'nodeName',
        'baseURI',
        'isConnected',
        'ownerDocument',
        'parentNode',
        'parentElement',
        'previousSibling',
        'nextSibling',
        'ELEMENT_NODE',
        'ATTRIBUTE_NODE',
        'TEXT_NODE',
        'CDATA_SECTION_NODE',
        'ENTITY_REFERENCE_NODE',
        'ENTITY_NODE',
        'PROCESSING_INSTRUCTION_NODE',
        'COMMENT_NODE',
        'DOCUMENT_NODE',
        'DOCUMENT_TYPE_NODE',
        'DOCUMENT_FRAGMENT_NODE',
        'NOTATION_NODE',
        'DOCUMENT_POSITION_DISCONNECTED',
        'DOCUMENT_POSITION_PRECEDING',
        'DOCUMENT_POSITION_FOLLOWING',
        'DOCUMENT_POSITION_CONTAINS',
        'DOCUMENT_POSITION_CONTAINED_BY',
        'DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC',
    ]);
    /**
     * Deep copy an HTML element with all its attributes, properties, and child nodes.
     * This method is useful for creating a clone of an element that can be safely modified without affecting the original.
     * @param {HTMLElement} element - The HTML element to copy.
     * @returns {HTMLElement} - A deep copy of the HTML element.
     * @example const copy = deepCopyElement(document.getElementById('myElement'));
     */
    function deepCopyElement(element) {
        const copy = document.createElement(element.tagName);
        // ✅ Copy attributes
        Array.from(element.attributes).forEach(attr => {
            copy.setAttribute(attr.name, attr.value);
        });
        // ✅ Dynamically extract relevant properties
        const properties = new Set();
        // Collect only own enumerable properties
        Object.keys(element).forEach(key => properties.add(key));
        // Collect inherited properties from prototypes (HTMLElement -> Element -> Node)
        let proto = Object.getPrototypeOf(element);
        while (proto && proto !== HTMLElement.prototype) {
            Object.keys(proto).forEach(key => properties.add(key));
            proto = Object.getPrototypeOf(proto);
        }
        // ✅ Filter and copy only non-function properties (methods are excluded) and non-event listeners
        properties.forEach(prop => {
            if (typeof element[prop] !== 'function' && // Ignore methods
                !prop.startsWith('on') && // Ignore event listeners (onclick, oninput, etc.)
                !excludedProps.has(prop) // 🚨 Prevent text duplication and irrelevant props
            ) {
                try {
                    copy[prop] = element[prop];
                }
                catch (error) {
                    console.warn(`Could not copy property ${prop}:`, error.message);
                }
            }
        });
        // ✅ Copy dataset separately
        Object.assign(copy.dataset, element.dataset);
        // ✅ Handle form elements specifically
        if (element instanceof HTMLInputElement) {
            copy.value = element.value;
            copy.checked = element.checked;
            copy.defaultValue = element.defaultValue;
            copy.defaultChecked = element.defaultChecked;
            copy.selectionStart = element.selectionStart;
            copy.selectionEnd = element.selectionEnd;
            copy.selectionDirection = element.selectionDirection;
        }
        else if (element instanceof HTMLTextAreaElement) {
            copy.value = element.value;
            copy.defaultValue = element.defaultValue;
            copy.selectionStart = element.selectionStart;
            copy.selectionEnd = element.selectionEnd;
            copy.selectionDirection =
                element.selectionDirection;
        }
        else if (element instanceof HTMLSelectElement) {
            copy.value = element.value;
            copy.selectedIndex = element.selectedIndex;
        }
        // ✅ Recursively copy child nodes (prevent duplicates)
        element.childNodes.forEach(child => {
            let childCopy;
            if (child.nodeType === Node.ELEMENT_NODE) {
                childCopy = deepCopyElement(child);
            }
            else {
                childCopy = child.cloneNode(true);
            }
            copy.appendChild(childCopy);
        });
        return copy;
    }

    exports.deepCopyElement = deepCopyElement;
    exports.excludedProps = excludedProps;

}));
