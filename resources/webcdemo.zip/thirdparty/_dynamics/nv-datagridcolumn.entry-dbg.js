sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2'], (function (exports, index) { 'use strict';

    const NvDatagridcolumn = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            /**
             * Whether the column need to be repeated with the template.
             */
            this.repeatTemplate = false;
        }
        //#endregion PROPERTIES
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '20839d4a0abfa07e55a49b434ad26e3ddaebb66b' }, index.h("slot", { key: '2c1b24aef73e9be8e500d48741e4dc6a42ed6f06', name: "header" }), index.h("slot", { key: 'cbc4bcbb080f8647c6f702e4a52411fe9be1f6ca', name: "cell" })));
        }
    };

    exports.nv_datagridcolumn = NvDatagridcolumn;

}));
