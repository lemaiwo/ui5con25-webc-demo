sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2'], (function (exports, index) { 'use strict';

    const nvFielddropdownitemCss = "nv-fielddropdownitem{display:flex;gap:var(--spacing-2);flex-wrap:wrap;align-items:center;width:100%;padding:var(--list-dropdown-item-padding-y) var(--list-dropdown-item-padding-x);font-weight:var(--menu-contextual-item-font-weight);font-size:var(--list-dropdown-font-size);line-height:var(--list-dropdown-line-height);color:var(--components-list-dropdown-item-label-default);border-radius:var(--list-dropdown-item-radius);transition:background-color 150ms ease-out, color 150ms ease-out;cursor:pointer}nv-fielddropdownitem:hover,nv-fielddropdownitem:focus,nv-fielddropdownitem:focus-within{background-color:var(--components-list-dropdown-item-background-hover);color:var(--components-menu-contextual-item-content-hover)}nv-fielddropdownitem[disabled]:not([disabled=false]){cursor:not-allowed;background-color:unset;color:var(--components-menu-contextual-item-content-disabled)}nv-fielddropdownitem .text-wrapper{display:flex;flex-grow:1;align-items:center;justify-content:space-between}nv-fielddropdownitem [data-scope=text]{flex-grow:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}nv-fielddropdownitem nv-icon[data-scope=selected]{color:var(--components-list-dropdown-item-label-default);align-self:center;margin-left:auto}";
    const NvFielddropdownitemStyle0 = nvFielddropdownitemCss;

    const NvFielddropdownitem = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.dropdownItemSelected = index.createEvent(this, "dropdownItemSelected");
            this.composed = false;
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Disables the item, preventing any user interaction.
             */
            this.disabled = false;
            /**
             * Indicates if the item is selected.
             */
            this.selected = false;
            //#endregion EVENTS
            /****************************************************************************/
            //#region METHODS
            this.handleSelected = () => {
                if (this.disabled)
                    return;
                this.dropdownItemSelected.emit({
                    label: this.label,
                    value: this.value,
                });
            };
        }
        handleKeyDown(event) {
            var _a, _b;
            if (event.target !== this.el)
                return;
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                this.handleSelected();
                (_b = (_a = this.el
                    .closest('nv-fielddropdown')) === null || _a === void 0 ? void 0 : _a.querySelector("[data-scope='focusable']")) === null || _b === void 0 ? void 0 : _b.focus();
            }
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillLoad() {
            var _a;
            this.composed = Boolean(this.el.children.length);
            if (!this.value) {
                const fallback = (_a = this.label) !== null && _a !== void 0 ? _a : this.el.textContent;
                this.value = fallback.replace(/\W+/g, ''); // Remove non-word characters
            }
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '86699901e52c35392ae5e60013f542427973a626', role: "menuitem", tabindex: '-1', onClick: this.handleSelected }, index.h("slot", { key: 'f2d893f0692821fc0e918da9283eb174c3429173' }), !this.composed && (index.h("div", { key: '5e62842ee3b0e79333f99a3ec8d92dd843ebd96e', class: "text-wrapper" }, index.h("span", { key: 'baa00ac59b5d85d912f34fc16fbf82d87af849e2', "data-scope": "text" }, this.label))), this.selected && (index.h("nv-icon", { key: 'f9a5082e4cee6b68531809f9861e3da83b3001d6', name: "check", "aria-hidden": "true", "data-scope": "selected" }))));
        }
        get el() { return index.getElement(this); }
    };
    NvFielddropdownitem.style = NvFielddropdownitemStyle0;

    exports.nv_fielddropdownitem = NvFielddropdownitem;

}));
