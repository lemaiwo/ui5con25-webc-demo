sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2'], (function (exports, index) { 'use strict';

    const NvTablecolumn = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
        }
        //#endregion PROPERTIES
        /****************************************************************************/
        //#region RENDER
        render() {
            return null;
        }
    };

    exports.nv_tablecolumn = NvTablecolumn;

}));
