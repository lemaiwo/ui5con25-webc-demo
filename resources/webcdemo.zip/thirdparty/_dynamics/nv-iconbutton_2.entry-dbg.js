sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/clsx-297c1ffe'], (function (exports, index, clsx297c1ffe) { 'use strict';

    const nvIconbuttonCss = "nv-iconbutton.root{display:inline-flex;justify-content:center;align-items:center;font-style:normal;font-weight:500;font-family:\"TT Norms Pro\", sans-serif;transition:background-color 150ms ease-out;height:fit-content;width:fit-content}nv-iconbutton.size-xs{padding:var(--button-xs-icon-button-padding);gap:var(--button-xs-gap);border-radius:var(--button-xs-border-radius);line-height:var(--button-xs-line-height);font-size:var(--button-xs-font-size)}nv-iconbutton.size-sm{padding:var(--button-sm-icon-button-padding);gap:var(--button-sm-gap);border-radius:var(--button-sm-border-radius);line-height:var(--button-sm-line-height);font-size:var(--button-sm-font-size)}nv-iconbutton.size-md{padding:var(--button-md-icon-button-padding);gap:var(--button-md-gap);border-radius:var(--button-md-border-radius);line-height:var(--button-md-line-height);font-size:var(--button-md-font-size)}nv-iconbutton.size-lg{padding:var(--button-lg-icon-button-padding);gap:var(--button-lg-gap);border-radius:var(--button-lg-border-radius);line-height:var(--button-lg-line-height);font-size:var(--button-lg-font-size)}nv-iconbutton.emphasis-high{background:var(--components-button-high-background);border:1px solid var(--components-button-high-border);color:var(--components-button-high-text)}nv-iconbutton.emphasis-high:hover{background:var(--components-button-high-background-hover);color:var(--components-button-high-text-hover)}nv-iconbutton.emphasis-high:focus,nv-iconbutton.emphasis-high:focus-within{outline:none}nv-iconbutton.emphasis-high:focus-visible,nv-iconbutton.emphasis-high:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-brand);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-iconbutton.emphasis-high:disabled{background:var(--components-button-high-background);color:var(--components-button-high-text);opacity:0.5;cursor:not-allowed;box-shadow:none}nv-iconbutton.emphasis-high nv-icon>svg{color:var(--components-button-high-icon)}nv-iconbutton.emphasis-medium{background:var(--components-button-medium-background);border:1px solid var(--components-button-medium-border);color:var(--components-button-medium-text)}nv-iconbutton.emphasis-medium:hover{background:var(--components-button-medium-background-hover);color:var(--components-button-medium-text-hover)}nv-iconbutton.emphasis-medium:focus,nv-iconbutton.emphasis-medium:focus-within{outline:none}nv-iconbutton.emphasis-medium:focus-visible,nv-iconbutton.emphasis-medium:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-brand);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-iconbutton.emphasis-medium:disabled{background:var(--components-button-medium-background);color:var(--components-button-medium-text);opacity:0.5;cursor:not-allowed;box-shadow:none}nv-iconbutton.emphasis-medium nv-icon>svg{color:var(--components-button-medium-icon)}nv-iconbutton.emphasis-low{background:var(--components-button-low-background);border:1px solid var(--components-button-low-border);color:var(--components-button-low-text)}nv-iconbutton.emphasis-low:hover{background:var(--components-button-low-background-hover);color:var(--components-button-low-text-hover)}nv-iconbutton.emphasis-low:focus,nv-iconbutton.emphasis-low:focus-within{outline:none}nv-iconbutton.emphasis-low:focus-visible,nv-iconbutton.emphasis-low:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-brand);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-iconbutton.emphasis-low:disabled{background:var(--components-button-low-background);color:var(--components-button-low-text);opacity:0.5;cursor:not-allowed;box-shadow:none}nv-iconbutton.emphasis-low nv-icon>svg{color:var(--components-button-low-icon)}nv-iconbutton.emphasis-lower{background:var(--components-button-lower-background);border:1px solid var(--components-button-lower-border);color:var(--components-button-lower-text)}nv-iconbutton.emphasis-lower:hover{background:var(--components-button-lower-background-hover);color:var(--components-button-lower-text-hover)}nv-iconbutton.emphasis-lower:focus,nv-iconbutton.emphasis-lower:focus-within{outline:none}nv-iconbutton.emphasis-lower:focus-visible,nv-iconbutton.emphasis-lower:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-brand);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-iconbutton.emphasis-lower:disabled{background:var(--components-button-lower-background);color:var(--components-button-lower-text);opacity:0.5;cursor:not-allowed;box-shadow:none}nv-iconbutton.emphasis-lower nv-icon>svg{color:var(--components-button-lower-icon)}nv-iconbutton.loading [slot=leading-icon]{display:none}nv-iconbutton.shape-rounded{border-radius:var(--radius-rounded-full)}";
    const NvIconbuttonStyle0 = nvIconbuttonCss;

    const NvIconbutton = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            if (hostRef.$hostElement$["s-ei"]) {
                this.internals = hostRef.$hostElement$["s-ei"];
            }
            else {
                this.internals = hostRef.$hostElement$.attachInternals();
                hostRef.$hostElement$["s-ei"] = this.internals;
            }
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Determines how large or small the button appears, allowing for
             * customization of the button's dimensions to fit different design
             * specifications and user needs.
             */
            this.size = 'md';
            /**
             * Adjusts the button’s emphasis to make it more or less visually prominent
             * to users. Use this to draw attention to important actions or reduce focus
             * on less critical ones.
             */
            this.emphasis = 'high';
            /**
             * Set this to true to show a spinner on the button, letting users know that
             * their action is being processed. It helps improve user experience by
             * indicating ongoing activities. The icon is not displayed when the button
             * is loading. Also, the button is disabled. If you want to disable the
             * button, it is not possible. It is automatically disabled when loading.
             */
            this.loading = false;
            /**
             * Disables the button, preventing user interaction.
             */
            this.disabled = false;
            /**
             * Makes the button look active when it’s within a compatible component
             * like a button group.
             */
            this.active = false;
            /**
             * Sets the button type to control its function in forms. Use 'submit' to send
             * form data, 'reset' to clear the form, or 'button' for a standard button
             * that doesn’t interact with form submission by default.
             */
            this.type = 'button';
            /**
             * Sets the shape of the button. Choose between square and rounded.
             */
            this.shape = 'square';
            //#endregion PROPERTIES
            /****************************************************************************/
            //#region METHODS
            /**
             * Handles form-related actions when the button is clicked.
             * - Submits the form if the button type is 'submit'.
             * - Resets the form if the button type is 'reset'.
             * @param {Event} event - The click event.
             */
            this.handleClick = (event) => {
                var _a, _b, _c, _d;
                if (this.disabled) {
                    event.preventDefault();
                    return;
                }
                if (this.type === 'submit') {
                    (_b = (_a = this.internals) === null || _a === void 0 ? void 0 : _a.form) === null || _b === void 0 ? void 0 : _b.requestSubmit();
                }
                if (this.type === 'reset') {
                    (_d = (_c = this.internals) === null || _c === void 0 ? void 0 : _c.form) === null || _d === void 0 ? void 0 : _d.reset();
                }
            };
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region WATCHERS
        handleLoadingChange(loading) {
            this.loading = loading;
            this.disabled = loading;
        }
        handleDisabledChange(disabled) {
            if (this.loading) {
                this.disabled = this.loading;
            }
            else {
                this.disabled = disabled;
            }
        }
        //#endregion WATCHERS
        /****************************************************************************/
        //#region EVENTS
        handleKeyDown(event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                this.el.click();
            }
        }
        handleTouchStart(event) {
            if (event.touches.length > 1)
                return;
            event.preventDefault();
            this.el.click();
        }
        //#endregion EVENTS
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillLoad() {
            if (this.loading) {
                this.disabled = this.loading;
            }
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: 'f678bd976942aa35ae36c536fdd86cd65a43263a', role: "button", type: this.type, tabindex: "0", disabled: this.disabled ? true : undefined, class: clsx297c1ffe.clsx('root', `size-${this.size}`, `emphasis-${this.emphasis}`, this.loading && 'loading', `shape-${this.shape}`), onClick: this.handleClick }, this.loading && index.h("nv-loader", { key: 'b874de8701de163c1f4235c2034a13da30279191', size: this.size }), !this.loading && index.h("nv-icon", { key: '222ccc93e3af3dcec81308b3b90ca724ecdfa2fb', name: this.name, size: this.size }), index.h("slot", { key: 'c7a257f7715a9320ffe46e09b59a2d570d1f052c' })));
        }
        static get formAssociated() { return true; }
        get el() { return index.getElement(this); }
        static get watchers() { return {
            "loading": ["handleLoadingChange"],
            "disabled": ["handleDisabledChange"]
        }; }
    };
    NvIconbutton.style = NvIconbuttonStyle0;

    const nvLoaderCss = "@keyframes rotation{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}nv-loader{display:inline-block;position:relative;aspect-ratio:1/1;border-radius:9999px;color:inherit}nv-loader.size-xs{width:var(--loader-size-xs);height:var(--loader-size-xs)}nv-loader.size-xs::before,nv-loader.size-xs::after{content:\" \";position:absolute;top:0;left:0;border-radius:inherit;width:100%;height:100%}nv-loader.size-xs::before{content:\" \";border:calc(var(--loader-size-xs) / 10) solid;opacity:0.3}nv-loader.size-xs::after{content:\" \";border-top:calc(var(--loader-size-xs) / 10) solid transparent;border-left:calc(var(--loader-size-xs) / 10) solid transparent;border-right:calc(var(--loader-size-xs) / 10) solid transparent;border-bottom:calc(var(--loader-size-xs) / 10) solid;animation:rotation 1s linear infinite}nv-loader.size-sm{width:var(--loader-size-sm);height:var(--loader-size-sm)}nv-loader.size-sm::before,nv-loader.size-sm::after{content:\" \";position:absolute;top:0;left:0;border-radius:inherit;width:100%;height:100%}nv-loader.size-sm::before{content:\" \";border:calc(var(--loader-size-sm) / 10) solid;opacity:0.3}nv-loader.size-sm::after{content:\" \";border-top:calc(var(--loader-size-sm) / 10) solid transparent;border-left:calc(var(--loader-size-sm) / 10) solid transparent;border-right:calc(var(--loader-size-sm) / 10) solid transparent;border-bottom:calc(var(--loader-size-sm) / 10) solid;animation:rotation 1s linear infinite}nv-loader.size-md{width:var(--loader-size-md);height:var(--loader-size-md)}nv-loader.size-md::before,nv-loader.size-md::after{content:\" \";position:absolute;top:0;left:0;border-radius:inherit;width:100%;height:100%}nv-loader.size-md::before{content:\" \";border:calc(var(--loader-size-md) / 10) solid;opacity:0.3}nv-loader.size-md::after{content:\" \";border-top:calc(var(--loader-size-md) / 10) solid transparent;border-left:calc(var(--loader-size-md) / 10) solid transparent;border-right:calc(var(--loader-size-md) / 10) solid transparent;border-bottom:calc(var(--loader-size-md) / 10) solid;animation:rotation 1s linear infinite}nv-loader.size-lg{width:var(--loader-size-lg);height:var(--loader-size-lg)}nv-loader.size-lg::before,nv-loader.size-lg::after{content:\" \";position:absolute;top:0;left:0;border-radius:inherit;width:100%;height:100%}nv-loader.size-lg::before{content:\" \";border:calc(var(--loader-size-lg) / 10) solid;opacity:0.3}nv-loader.size-lg::after{content:\" \";border-top:calc(var(--loader-size-lg) / 10) solid transparent;border-left:calc(var(--loader-size-lg) / 10) solid transparent;border-right:calc(var(--loader-size-lg) / 10) solid transparent;border-bottom:calc(var(--loader-size-lg) / 10) solid;animation:rotation 1s linear infinite}nv-loader.size-xl{width:var(--loader-size-xl);height:var(--loader-size-xl)}nv-loader.size-xl::before,nv-loader.size-xl::after{content:\" \";position:absolute;top:0;left:0;border-radius:inherit;width:100%;height:100%}nv-loader.size-xl::before{content:\" \";border:calc(var(--loader-size-xl) / 10) solid;opacity:0.3}nv-loader.size-xl::after{content:\" \";border-top:calc(var(--loader-size-xl) / 10) solid transparent;border-left:calc(var(--loader-size-xl) / 10) solid transparent;border-right:calc(var(--loader-size-xl) / 10) solid transparent;border-bottom:calc(var(--loader-size-xl) / 10) solid;animation:rotation 1s linear infinite}nv-loader.color-brand::before{border-color:var(--components-loader-brand-background);opacity:1}nv-loader.color-brand::after{border-bottom-color:var(--components-loader-brand-foreground)}nv-loader.color-white::before{border-color:var(--components-loader-white-background);opacity:1}nv-loader.color-white::after{border-bottom-color:var(--components-loader-white-foreground)}";
    const NvLoaderStyle0 = nvLoaderCss;

    const NvLoader = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Choose the size of the loader to best fit your application’s needs, whether
             * it’s a small spinner for subtle loading indicators or a large one for more
             * prominent displays.
             */
            this.size = 'md';
        }
        //#endregion PROPERTIES
        /****************************************************************************/
        //#region RENDER
        /* <slot> empty to force rendering change */
        render() {
            return (index.h(index.Host, { key: 'f3094e46eb7072534f497694d3c28030f0118acc', class: clsx297c1ffe.clsx(this.size && `size-${this.size}`, this.color && `color-${this.color}`) }));
        }
    };
    NvLoader.style = NvLoaderStyle0;

    exports.nv_iconbutton = NvIconbutton;
    exports.nv_loader = NvLoader;

}));
