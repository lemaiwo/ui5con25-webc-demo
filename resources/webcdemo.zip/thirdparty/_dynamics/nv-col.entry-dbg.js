sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/clsx-297c1ffe'], (function (exports, index, clsx297c1ffe) { 'use strict';

    const nvColCss = "nv-col{display:block;flex:1 1 0%;padding-left:calc(var(--spacing-4) / 2);padding-right:calc(var(--spacing-4) / 2)}nv-col[class*=w-]{flex:none}nv-col.w-1\\/12{width:calc(100% * 1 / 12)}nv-col.w-2\\/12{width:calc(100% * 2 / 12)}nv-col.w-3\\/12{width:calc(100% * 3 / 12)}nv-col.w-4\\/12{width:calc(100% * 4 / 12)}nv-col.w-5\\/12{width:calc(100% * 5 / 12)}nv-col.w-6\\/12{width:calc(100% * 6 / 12)}nv-col.w-7\\/12{width:calc(100% * 7 / 12)}nv-col.w-8\\/12{width:calc(100% * 8 / 12)}nv-col.w-9\\/12{width:calc(100% * 9 / 12)}nv-col.w-10\\/12{width:calc(100% * 10 / 12)}nv-col.w-11\\/12{width:calc(100% * 11 / 12)}nv-col.w-12\\/12{width:calc(100% * 12 / 12)}";
    const NvColStyle0 = nvColCss;

    const NvCol = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
        }
        //#endregion PROPERTIES
        /****************************************************************************/
        //#region METHODS
        /**
         * Get the column size class.
         * @returns {string | undefined} The column size class.
         */
        getColSize() {
            if (this.size) {
                if (this.size < 1 || this.size > 12)
                    return;
                return `w-${this.size}/12`;
            }
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '8f7112dc8ce8896d9e7265741f06b7449dd508df', class: clsx297c1ffe.clsx(this.getColSize()) }, index.h("slot", { key: '3bedff11752d04db2615a5f26d4d910d95dee76c' })));
        }
    };
    NvCol.style = NvColStyle0;

    exports.nv_col = NvCol;

}));
