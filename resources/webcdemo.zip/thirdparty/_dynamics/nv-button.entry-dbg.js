sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/constants-98e2dcc2'], (function (exports, index, constants98e2dcc2) { 'use strict';

    const nvButtonCss = "nv-button{text-decoration:none;display:inline-flex;justify-content:center;align-items:center;font-style:normal;font-weight:var(--font-weight-medium-emphasis);font-family:\"TT Norms Pro\", sans-serif;transition:background-color 150ms ease-out;user-select:none;cursor:pointer;height:fit-content;width:fit-content}nv-button[size=xs]{padding:var(--button-xs-padding-y) var(--button-xs-padding-x);gap:var(--button-xs-gap);border-radius:var(--button-xs-border-radius);line-height:var(--button-xs-line-height);font-size:var(--button-xs-font-size)}nv-button[size=xs] nv-icon>svg{width:var(--spacing-3);height:var(--spacing-3);stroke-width:1.2px}nv-button[size=sm]{padding:var(--button-sm-padding-y) var(--button-sm-padding-x);gap:var(--button-sm-gap);border-radius:var(--button-sm-border-radius);line-height:var(--button-sm-line-height);font-size:var(--button-sm-font-size)}nv-button[size=sm] nv-icon>svg{width:var(--spacing-4);height:var(--spacing-4);stroke-width:1.5px}nv-button[size=md]{padding:var(--button-md-padding-y) var(--button-md-padding-x);gap:var(--button-md-gap);border-radius:var(--button-md-border-radius);line-height:var(--button-md-line-height);font-size:var(--button-md-font-size)}nv-button[size=md] nv-icon>svg{width:var(--spacing-5);height:var(--spacing-5);stroke-width:1.6px}nv-button[size=lg]{padding:var(--button-lg-padding-y) var(--button-lg-padding-x);gap:var(--button-lg-gap);border-radius:var(--button-lg-border-radius);line-height:var(--button-lg-line-height);font-size:var(--button-lg-font-size)}nv-button[size=lg] nv-icon>svg{width:var(--spacing-6);height:var(--spacing-6);stroke-width:1.8px}nv-button[emphasis=high]{background:var(--components-button-high-background);border:1px solid var(--components-button-high-border);color:var(--components-button-high-text)}nv-button[emphasis=high]:hover{background:var(--components-button-high-background-hover);border:1px solid var(--components-button-high-border);color:var(--components-button-high-text-hover)}nv-button[emphasis=high]:active{background:var(--components-button-high-background-active);border:1px solid var(--components-button-high-border-active);color:var(--components-button-high-text-active)}nv-button[emphasis=high]:focus,nv-button[emphasis=high]:focus-within{outline:none}nv-button[emphasis=high]:focus-visible,nv-button[emphasis=high]:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-brand);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-button[emphasis=high]:disabled:not([disabled=false]){opacity:0.5;cursor:not-allowed;box-shadow:none}nv-button[emphasis=high][active]:not([active=false]){background:var(--components-button-high-background-active);border:1px solid var(--components-button-high-border-active);color:var(--components-button-high-text-active)}nv-button[emphasis=high][danger]:not([danger=false]){background:var(--components-button-destructive-high-background);border:1px solid transparent;color:var(--components-button-destructive-high-text)}nv-button[emphasis=high][danger]:not([danger=false]):hover{background:var(--components-button-destructive-high-background-hover);border:1px solid transparent;color:var(--components-button-destructive-high-text-hover)}nv-button[emphasis=high][danger]:not([danger=false]):focus,nv-button[emphasis=high][danger]:not([danger=false]):focus-within{outline:none}nv-button[emphasis=high][danger]:not([danger=false]):focus-visible,nv-button[emphasis=high][danger]:not([danger=false]):has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-destructive);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-button[emphasis=medium]{background:var(--components-button-medium-background);border:1px solid var(--components-button-medium-border);color:var(--components-button-medium-text)}nv-button[emphasis=medium]:hover{background:var(--components-button-medium-background-hover);border:1px solid var(--components-button-medium-border);color:var(--components-button-medium-text-hover)}nv-button[emphasis=medium]:active{background:var(--components-button-medium-background-active);border:1px solid var(--components-button-medium-border-active);color:var(--components-button-medium-text-active)}nv-button[emphasis=medium]:focus,nv-button[emphasis=medium]:focus-within{outline:none}nv-button[emphasis=medium]:focus-visible,nv-button[emphasis=medium]:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-brand);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-button[emphasis=medium]:disabled:not([disabled=false]){opacity:0.5;cursor:not-allowed;box-shadow:none}nv-button[emphasis=medium][active]:not([active=false]){background:var(--components-button-medium-background-active);border:1px solid var(--components-button-medium-border-active);color:var(--components-button-medium-text-active)}nv-button[emphasis=medium][danger]:not([danger=false]){background:var(--components-button-destructive-medium-background);border:1px solid var(--components-button-destructive-medium-border);color:var(--components-button-destructive-medium-text)}nv-button[emphasis=medium][danger]:not([danger=false]):hover{background:var(--components-button-destructive-medium-background-hover);border:1px solid var(--components-button-destructive-medium-border);color:var(--components-button-destructive-medium-text-hover)}nv-button[emphasis=medium][danger]:not([danger=false]):focus,nv-button[emphasis=medium][danger]:not([danger=false]):focus-within{outline:none}nv-button[emphasis=medium][danger]:not([danger=false]):focus-visible,nv-button[emphasis=medium][danger]:not([danger=false]):has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-destructive);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-button[emphasis=low]{background:var(--components-button-low-background);border:1px solid var(--components-button-low-border);color:var(--components-button-low-text)}nv-button[emphasis=low]:hover{background:var(--components-button-low-background-hover);border:1px solid var(--components-button-low-border);color:var(--components-button-low-text-hover)}nv-button[emphasis=low]:active{background:var(--components-button-low-background-active);border:1px solid var(--components-button-low-border-active);color:var(--components-button-low-text-active)}nv-button[emphasis=low]:focus,nv-button[emphasis=low]:focus-within{outline:none}nv-button[emphasis=low]:focus-visible,nv-button[emphasis=low]:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-brand);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-button[emphasis=low]:disabled:not([disabled=false]){opacity:0.5;cursor:not-allowed;box-shadow:none}nv-button[emphasis=low][active]:not([active=false]){background:var(--components-button-low-background-active);border:1px solid var(--components-button-low-border-active);color:var(--components-button-low-text-active)}nv-button[emphasis=low][danger]:not([danger=false]){background:var(--components-button-destructive-low-background);border:1px solid var(--components-button-destructive-low-border);color:var(--components-button-destructive-low-text)}nv-button[emphasis=low][danger]:not([danger=false]):hover{background:var(--components-button-destructive-low-background-hover);border:1px solid var(--components-button-destructive-low-border);color:var(--components-button-destructive-low-text-hover)}nv-button[emphasis=low][danger]:not([danger=false]):focus,nv-button[emphasis=low][danger]:not([danger=false]):focus-within{outline:none}nv-button[emphasis=low][danger]:not([danger=false]):focus-visible,nv-button[emphasis=low][danger]:not([danger=false]):has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-destructive);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-button[emphasis=lower]{background:var(--components-button-lower-background);border:1px solid var(--components-button-lower-border);color:var(--components-button-lower-text)}nv-button[emphasis=lower]:hover{background:var(--components-button-lower-background-hover);border:1px solid var(--components-button-lower-border);color:var(--components-button-lower-text-hover)}nv-button[emphasis=lower]:active{background:var(--components-button-lower-background-active);border:1px solid var(--components-button-lower-border-active);color:var(--components-button-lower-text-active)}nv-button[emphasis=lower]:focus,nv-button[emphasis=lower]:focus-within{outline:none}nv-button[emphasis=lower]:focus-visible,nv-button[emphasis=lower]:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-brand);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-button[emphasis=lower]:disabled:not([disabled=false]){opacity:0.5;cursor:not-allowed;box-shadow:none}nv-button[emphasis=lower][active]:not([active=false]){background:var(--components-button-lower-background-active);border:1px solid var(--components-button-lower-border-active);color:var(--components-button-lower-text-active)}nv-button[emphasis=lower][danger]:not([danger=false]){background:var(--components-button-destructive-lower-background);border:1px solid var(--components-button-destructive-lower-border);color:var(--components-button-destructive-lower-text)}nv-button[emphasis=lower][danger]:not([danger=false]):hover{background:var(--components-button-destructive-lower-background-hover);border:1px solid var(--components-button-destructive-lower-border);color:var(--components-button-destructive-lower-text-hover)}nv-button[emphasis=lower][danger]:not([danger=false]):focus,nv-button[emphasis=lower][danger]:not([danger=false]):focus-within{outline:none}nv-button[emphasis=lower][danger]:not([danger=false]):focus-visible,nv-button[emphasis=lower][danger]:not([danger=false]):has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-destructive);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-button[fluid]:not([fluid=false]){width:100%}nv-button[loading]:not([loading=false]) [slot=leading-icon]{display:none}";
    const NvButtonStyle0 = nvButtonCss;

    const NvButton = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            if (hostRef.$hostElement$["s-ei"]) {
                this.internals = hostRef.$hostElement$["s-ei"];
            }
            else {
                this.internals = hostRef.$hostElement$.attachInternals();
                hostRef.$hostElement$["s-ei"] = this.internals;
            }
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Determines how large or small the button appears, allowing for
             * customization of the button's dimensions to fit different design
             * specifications and user needs.
             */
            this.size = 'md';
            /**
             * Adjusts the button's emphasis to make it more or less visually prominent
             * to users. Use this to draw attention to important actions or reduce focus
             * on less critical ones
             */
            this.emphasis = 'high';
            /**
             * Use this prop to highlight the button when it represents the current page
             * or active selection. This helps users understand their navigation context.
             */
            this.active = false;
            /**
             * Applies styling that visually indicates the button represents a dangerous
             * action.
             */
            this.danger = false;
            /**
             * Set this to true to show a spinner on the button, letting users know that
             * their action is being processed. It helps improve user experience by
             * indicating ongoing activities.
             */
            this.loading = false;
            /**
             * Disables the button, preventing user interaction.
             */
            this.disabled = false;
            /**
             * Allows the button to stretch and fill the entire width of its container.
             */
            this.fluid = false;
            /**
             * Sets the button type to control its function in forms. Use 'submit' to send
             * form data, 'reset' to clear the form, or 'button' for a standard button
             * that doesn't interact with form submission by default.
             */
            this.type = 'button';
            //#endregion PROPERTIES
            /****************************************************************************/
            //#region METHODS
            /**
             * Handles button click events, managing form actions and disabled states.
             * Prevents default behavior when button is disabled or loading, and
             * processes form submissions/resets when appropriate.
             * @param {Event} event - The click event.
             */
            this.handleButtonClick = (event) => {
                var _a;
                if (this.loading || this.disabled) {
                    event.preventDefault();
                    return;
                }
                if (this.type !== constants98e2dcc2.ButtonType.Button &&
                    (this.form || ((_a = this.internals) === null || _a === void 0 ? void 0 : _a.form))) {
                    this.processFormAction();
                }
                else if (this.form && this.type === constants98e2dcc2.ButtonType.Button) {
                    console.warn('Button has a form id but is not of type submit or reset so no form action will be processed.', `Button:`, this.el);
                }
            };
            /**
             * Processes form-related actions by finding the associated form element
             * and triggering the appropriate action (submit/reset) based on button type.
             * Falls back to ElementInternals form if no explicit form ID is provided.
             */
            this.processFormAction = () => {
                var _a, _b;
                const formElement = this.form
                    ? document.getElementById(this.form)
                    : (_a = this.internals) === null || _a === void 0 ? void 0 : _a.form;
                if (!formElement) {
                    console.warn('No form element found.', `Form ID: ${this.form || 'Not provided'}`, `Internals form:`, (_b = this.internals) === null || _b === void 0 ? void 0 : _b.form);
                    return;
                }
                switch (this.type) {
                    case constants98e2dcc2.ButtonType.Submit:
                        formElement.requestSubmit();
                        break;
                    case constants98e2dcc2.ButtonType.Reset:
                        formElement.reset();
                        break;
                }
            };
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region EVENTS
        handleKeyDown(event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                this.el.click();
            }
        }
        handleTouchStart(event) {
            if (event.touches.length > 1)
                return;
            event.preventDefault();
            this.el.click();
        }
        //#endregion EVENTS
        /****************************************************************************/
        //#region WATCHERS
        handleLoadingChange(loading) {
            this.loading = loading;
            this.disabled = loading;
        }
        handleDisabledChange(disabled) {
            if (this.loading) {
                this.disabled = this.loading;
            }
            else {
                this.disabled = disabled;
            }
        }
        //#endregion WATCHERS
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillLoad() {
            if (this.loading) {
                this.disabled = this.loading;
            }
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: 'f8b20f9052d71f93eaf03f98550a7237225cadf2', role: "button", tabindex: "0", onClick: this.handleButtonClick }, this.loading && (index.h("nv-loader", { key: 'c1cefa72ee24dad9ce16bbfe1f51e6cec6dc7fbc', size: this.size === constants98e2dcc2.ButtonSize.Large ? 'sm' : 'xs' })), index.h("slot", { key: '36a311494e45ebc23b1133923a676d58e87f3800', name: "leading-icon" }), index.h("slot", { key: 'f6fea826cda9a09f7152f4e30cc6981c89e73ebe' }), index.h("slot", { key: 'd59c23ff85ea7efc16c69c5adbeb0e91786f1f68', name: "trailing-icon" })));
        }
        static get formAssociated() { return true; }
        get el() { return index.getElement(this); }
        static get watchers() { return {
            "loading": ["handleLoadingChange"],
            "disabled": ["handleDisabledChange"]
        }; }
    };
    NvButton.style = NvButtonStyle0;

    exports.nv_button = NvButton;

}));
