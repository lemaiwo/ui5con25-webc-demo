sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2'], (function (exports, index) { 'use strict';

    const nvTooltipCss = "nv-tooltip{display:inline-block;position:relative}nv-tooltip:has([fluid]:not([fluid=false])){display:block}nv-tooltip [data-scope=popover]{background:var(--components-tooltip-background);color:var(--components-tooltip-text);font-weight:var(--font-weight-medium-emphasis);padding:var(--tooltip-padding-y) var(--tooltip-padding-x);font-size:var(--tooltip-font-size);border-radius:var(--tooltip-radius);border:none;box-shadow:0px var(--shadow-y-axis-lg-1) var(--shadow-blur-lg-1) var(--shadow-spread-lg-1) var(--shadow-color-opacity-1), 0px var(--shadow-y-axis-lg-2) var(--shadow-blur-lg-2) var(--shadow-spread-lg-2) var(--shadow-color-opacity-2)}nv-tooltip [data-scope=popover] [data-scope=arrow]{background:var(--components-tooltip-background);box-shadow:none;border:none}";
    const NvTooltipStyle0 = nvTooltipCss;

    const NvTooltip = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            /**
             * Decides where the tooltip shows up next to the element it’s linked to
             * (above, below, to the sides). If there isn’t enough room, it will adjust
             * it's position on the axis to fit on the screen, so users can always see it.
             */
            this.placement = 'bottom';
            /**
             * Controls how long (in milliseconds) the tooltip waits to show after you
             * hover over or focus on an element. If you move away before the delay is up,
             * the tooltip won’t appear.
             */
            this.enterDelay = 0;
        }
        //#endregion PROPERTIES
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillLoad() {
            if (!this.triggerElement)
                this.triggerElement = Array.from(this.el.children).find(child => {
                    return child.getAttribute('slot') === null;
                });
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '8309e08944469fad76997a6dfcb8b434461aa5a3' }, index.h("slot", { key: 'f3da94e2f2f581f7b8c93f4b3e70de67e305508a' }), index.h("nv-popover", { key: 'a28c50f59f9a781afd8a8ab60260d065dcadf96d', triggerMode: "hover", hasArrow: true, placement: this.placement, triggerElement: this.triggerElement, groupName: 'tooltip', enterDelay: this.enterDelay }, index.h("p", { key: '76f63a5f220de640f4eeada8aeba97e9ead73fc9', slot: "content" }, this.message), index.h("slot", { key: 'f55f71b357b23c29b40b9c022a5a1718c4c8c8fb', name: "content" }))));
        }
        get el() { return index.getElement(this); }
    };
    NvTooltip.style = NvTooltipStyle0;

    exports.nv_tooltip = NvTooltip;

}));
