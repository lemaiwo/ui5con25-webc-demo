sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/clsx-297c1ffe', 'be/wl/webc/demo/thirdparty/timeline.animation-1b88f052', 'be/wl/webc/demo/thirdparty/fade.animation-2a077983'], (function (exports, index, clsx297c1ffe, timeline_animation1b88f052, fade_animation2a077983) { 'use strict';

    const nvBadgeCss = "nv-badge{padding:var(--badge-padding-y) var(--badge-padding-x);display:inline-flex !important;vertical-align:middle;align-items:center;border-radius:var(--radius-rounded-full);border-style:solid;border-width:0.5px;height:fit-content;width:fit-content}nv-badge.with-gap{padding:var(--badge-padding-y) var(--badge-padding-x);display:inline-flex !important;vertical-align:middle;align-items:center;border-radius:var(--radius-rounded-full);border-style:solid;border-width:0.5px;height:fit-content;width:fit-content;gap:var(--badge-gap-x)}nv-badge.visually-hidden{position:absolute;padding:0;border:0;overflow:hidden;white-space:nowrap;width:1px;height:1px;margin:-1px;clip:rect(0, 0, 0, 0)}nv-badge:not(.with-gap){padding:var(--badge-padding-y) var(--badge-padding-x);display:inline-flex !important;vertical-align:middle;align-items:center;border-radius:var(--radius-rounded-full);border-style:solid;border-width:0.5px;height:fit-content;width:fit-content}nv-badge.badge-1{color:var(--color-rainbow-1-text);background-color:var(--color-rainbow-1-background);border-color:var(--color-rainbow-1-border)}nv-badge.badge-1 .close:focus,nv-badge.badge-1 .close:focus-within{outline:none}nv-badge.badge-1 .close:focus-visible,nv-badge.badge-1 .close:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-rainbow-1-content);outline-offset:calc(var(--focus-outline-offset) * 0.2)}nv-badge.badge-1 nv-icon{color:var(--color-rainbow-1-icon)}nv-badge.badge-2{color:var(--color-rainbow-2-text);background-color:var(--color-rainbow-2-background);border-color:var(--color-rainbow-2-border)}nv-badge.badge-2 .close:focus,nv-badge.badge-2 .close:focus-within{outline:none}nv-badge.badge-2 .close:focus-visible,nv-badge.badge-2 .close:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-rainbow-2-content);outline-offset:calc(var(--focus-outline-offset) * 0.2)}nv-badge.badge-2 nv-icon{color:var(--color-rainbow-2-icon)}nv-badge.badge-3{color:var(--color-rainbow-3-text);background-color:var(--color-rainbow-3-background);border-color:var(--color-rainbow-3-border)}nv-badge.badge-3 .close:focus,nv-badge.badge-3 .close:focus-within{outline:none}nv-badge.badge-3 .close:focus-visible,nv-badge.badge-3 .close:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-rainbow-3-content);outline-offset:calc(var(--focus-outline-offset) * 0.2)}nv-badge.badge-3 nv-icon{color:var(--color-rainbow-3-icon)}nv-badge.badge-4{color:var(--color-rainbow-4-text);background-color:var(--color-rainbow-4-background);border-color:var(--color-rainbow-4-border)}nv-badge.badge-4 .close:focus,nv-badge.badge-4 .close:focus-within{outline:none}nv-badge.badge-4 .close:focus-visible,nv-badge.badge-4 .close:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-rainbow-4-content);outline-offset:calc(var(--focus-outline-offset) * 0.2)}nv-badge.badge-4 nv-icon{color:var(--color-rainbow-4-icon)}nv-badge.badge-5{color:var(--color-rainbow-5-text);background-color:var(--color-rainbow-5-background);border-color:var(--color-rainbow-5-border)}nv-badge.badge-5 .close:focus,nv-badge.badge-5 .close:focus-within{outline:none}nv-badge.badge-5 .close:focus-visible,nv-badge.badge-5 .close:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-rainbow-5-content);outline-offset:calc(var(--focus-outline-offset) * 0.2)}nv-badge.badge-5 nv-icon{color:var(--color-rainbow-5-icon)}nv-badge.badge-6{color:var(--color-rainbow-6-text);background-color:var(--color-rainbow-6-background);border-color:var(--color-rainbow-6-border)}nv-badge.badge-6 .close:focus,nv-badge.badge-6 .close:focus-within{outline:none}nv-badge.badge-6 .close:focus-visible,nv-badge.badge-6 .close:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-rainbow-6-content);outline-offset:calc(var(--focus-outline-offset) * 0.2)}nv-badge.badge-6 nv-icon{color:var(--color-rainbow-6-icon)}nv-badge.badge-7{color:var(--color-rainbow-7-text);background-color:var(--color-rainbow-7-background);border-color:var(--color-rainbow-7-border)}nv-badge.badge-7 .close:focus,nv-badge.badge-7 .close:focus-within{outline:none}nv-badge.badge-7 .close:focus-visible,nv-badge.badge-7 .close:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-rainbow-7-content);outline-offset:calc(var(--focus-outline-offset) * 0.2)}nv-badge.badge-7 nv-icon{color:var(--color-rainbow-7-icon)}nv-badge.badge-8{color:var(--color-rainbow-8-text);background-color:var(--color-rainbow-8-background);border-color:var(--color-rainbow-8-border)}nv-badge.badge-8 .close:focus,nv-badge.badge-8 .close:focus-within{outline:none}nv-badge.badge-8 .close:focus-visible,nv-badge.badge-8 .close:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-rainbow-8-content);outline-offset:calc(var(--focus-outline-offset) * 0.2)}nv-badge.badge-8 nv-icon{color:var(--color-rainbow-8-icon)}nv-badge.badge-9{color:var(--color-rainbow-9-text);background-color:var(--color-rainbow-9-background);border-color:var(--color-rainbow-9-border)}nv-badge.badge-9 .close:focus,nv-badge.badge-9 .close:focus-within{outline:none}nv-badge.badge-9 .close:focus-visible,nv-badge.badge-9 .close:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-rainbow-9-content);outline-offset:calc(var(--focus-outline-offset) * 0.2)}nv-badge.badge-9 nv-icon{color:var(--color-rainbow-9-icon)}nv-badge.badge-10{color:var(--color-rainbow-10-text);background-color:var(--color-rainbow-10-background);border-color:var(--color-rainbow-10-border)}nv-badge.badge-10 .close:focus,nv-badge.badge-10 .close:focus-within{outline:none}nv-badge.badge-10 .close:focus-visible,nv-badge.badge-10 .close:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-rainbow-10-content);outline-offset:calc(var(--focus-outline-offset) * 0.2)}nv-badge.badge-10 nv-icon{color:var(--color-rainbow-10-icon)}nv-badge span{font-size:var(--font-size-xs);line-height:var(--line-height-xs) !important}nv-badge nv-icon>svg.icon-xs{width:var(--spacing-3);height:var(--spacing-3);stroke-width:1.2px}nv-badge nv-icon>svg.icon-sm{width:var(--spacing-3);height:var(--spacing-3);stroke-width:1.2px}nv-badge nv-icon>svg.icon-md{width:var(--spacing-3);height:var(--spacing-3);stroke-width:1.2px}nv-badge nv-icon>svg.icon-lg{width:var(--spacing-3);height:var(--spacing-3);stroke-width:1.2px}nv-badge nv-icon>svg.icon-xl{width:var(--spacing-3);height:var(--spacing-3);stroke-width:1.2px}nv-badge .close{padding:0;line-height:0;border:none;background:none;cursor:pointer;color:inherit;display:inline-flex;align-items:center;aspect-ratio:1/1;border-radius:var(--radius-rounded-full)}";
    const NvBadgeStyle0 = nvBadgeCss;

    const NvBadge = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.closeClicked = index.createEvent(this, "closeClicked");
            this.hiddenChanged = index.createEvent(this, "hiddenChanged");
            this.hiddenChangedComplete = index.createEvent(this, "hiddenChangedComplete");
            /****************************************************************************/
            //#region DEPRECATED
            /**
             * Whether the badge is dismissible.
             * @deprecated use dismissible instead.
             */
            this.dismissal = false;
            //#endregion DEPRECATED
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * The color of the badge. Use a string between 1 to 10
             */
            this.color = '1';
            /**
             * Main content of the badge.
             */
            this.label = null;
            /**
             * The lead icon of the badge.
             */
            this.leadIcon = null;
            /**
             * Whether the badge is dismissible.
             */
            this.dismissible = false;
            /**
             * Controls the visibility of the badge. Will animate with fade and collapse.
             */
            this.hidden = false; // eslint-disable-line @stencil-community/reserved-member-names
            /**
             * When true, the alert does not automatically close upon dismissing.
             * Useful for externally controlled component behavior.
             */
            this.preventAutoClose = false;
            //#endregion LIFECYCLE
            /****************************************************************************/
            //#region METHODS
            /**
             * Handles the close button click.
             * @param {MouseEvent} originalEvent - The original event.
             */
            this.handleClose = (originalEvent) => {
                if (!this.preventAutoClose) {
                    this.hidden = true;
                }
                this.closeClicked.emit(originalEvent);
            };
        }
        //#endregion EVENTS
        /****************************************************************************/
        //#region WATCHERS
        /**
         * Handles the dismissal prop change.
         * @param {boolean} dismissal - The new dismissal value.
         */
        handleDismissalChange(dismissal) {
            this.dismissible = dismissal;
        }
        /**
         * Handles the icon prop change.
         * @param {string} icon - The new icon value.
         */
        handleIconChange(icon) {
            this.leadIcon = icon;
        }
        /**
         * Handles the hidden prop change.
         * @param {boolean} hidden - The new hidden value.
         */
        async handleHiddenChange(hidden) {
            this.hiddenChanged.emit(hidden);
            if (this._isHidden === true)
                this._isHidden = hidden;
            const { fadeIn, fadeOut } = fade_animation2a077983.useFade(this.ref, { duration: 150 });
            const { collapse, expand } = timeline_animation1b88f052.useCollapse(this.ref, { duration: 150 });
            if (hidden === true)
                await timeline_animation1b88f052.timeline(fadeOut, collapse).start();
            if (hidden === false)
                await timeline_animation1b88f052.timeline(expand, fadeIn).start();
            this.hiddenChangedComplete.emit(hidden);
            if (this._isHidden === false)
                this._isHidden = hidden;
        }
        //#endregion WATCHERS
        /****************************************************************************/
        //#region LIFECYCLE
        /**
         * Component will load.
         */
        componentWillLoad() {
            if (this.dismissal) {
                this.dismissible = this.dismissal;
            }
            if (this.icon != null && this.icon != '') {
                this.leadIcon = this.icon;
            }
            if (this.hidden) {
                this._isHidden = true;
                const { setCollapsed } = timeline_animation1b88f052.useCollapse(this.ref);
                const { setFadeOut } = fade_animation2a077983.useFade(this.ref);
                setCollapsed();
                setFadeOut();
            }
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '8d97eed4a84f2f913e4f8cd64d08c806d9724f33', class: clsx297c1ffe.clsx(`badge-${this.color}`, {
                    'has-close': this.dismissible,
                    'with-gap': this.dismissible || this.label,
                    'visually-hidden': this._isHidden,
                }) }, index.h("slot", { key: '34c2c387727e6b68d37fe2b2ac68c82799356e3d', name: "leading-icon" }, this.leadIcon && index.h("nv-icon", { key: '0c23dd58e48fce39d7935549c6289f87f1fb66af', name: this.leadIcon, size: "sm" })), index.h("slot", { key: '7485f570aa3cf519b030bedfa8ccf6a6d37d2c1b' }, this.label && index.h("span", { key: 'eb7afa0eb52582c6d782d2383dfe2eeb41a9649b' }, this.label)), this.dismissible && (index.h("button", { key: 'bc07eed3e1328a8009cb2c8add026a7f8a5335da', onClick: this.handleClose, class: "close", type: "button" }, index.h("nv-icon", { key: 'ab0b2c6224f4b8b147e8158856acbf1ab987b392', name: "x", size: "sm" })))));
        }
        get ref() { return index.getElement(this); }
        static get watchers() { return {
            "dismissal": ["handleDismissalChange"],
            "icon": ["handleIconChange"],
            "hidden": ["handleHiddenChange"]
        }; }
    };
    NvBadge.style = NvBadgeStyle0;

    const nvFielddropdownitemcheckCss = "nv-fielddropdownitemcheck{cursor:pointer;display:flex;padding:var(--list-dropdown-item-padding-y) var(--list-dropdown-item-padding-x);border-radius:var(--list-dropdown-item-radius)}nv-fielddropdownitemcheck slot-fb,nv-fielddropdownitemcheck span{all:unset}nv-fielddropdownitemcheck:hover{background-color:var(--components-list-dropdown-item-background-hover)}";
    const NvFielddropdownitemcheckStyle0 = nvFielddropdownitemcheckCss;

    const NvFielddropdownitemcheck = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.itemChecked = index.createEvent(this, "itemChecked");
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Indicates whether the checkbox is selected.
             */
            this.checked = false;
            /**
             * Disables the item, preventing any user interaction.
             */
            this.disabled = false;
            /**
             * when the child <nv-fieldcheckbox> change its `checked` state,
             * update `this.checked` and emit `itemChecked`.
             * @param {CustomEvent<boolean>} event - The event emitted by the <nv-fieldcheckbox> component.
             */
            this.onFieldcheckboxChanged = (event) => {
                if (this.disabled)
                    return;
                // NvFieldcheckbox has emitted checkedChanged
                this.checked = event.detail; // get the new state
                this.itemChecked.emit({
                    value: this.value,
                    checked: this.checked,
                    group: this.group,
                });
            };
            /** Make sure the checkbox is checked when clicked anywhere in the item. */
            this.handleClick = () => {
                if (this.disabled)
                    return;
                if (this.el.querySelector('input').checked) {
                    this.checked = false;
                }
                else {
                    this.checked = true;
                }
            };
        }
        render() {
            return (index.h(index.Host, { key: '93a97fb36d69bd837b27cdbfa31adc5a7a71dab4', onClick: this.handleClick }, index.h("nv-fieldcheckbox", { key: '7afd9b55ce6911c327fae658304fa313fc908d45', checked: this.checked, name: this.label || this.value, label: this.label || this.value, "label-placement": "after", description: this.description, disabled: this.disabled, tabindex: "-1", role: "option", onCheckedChanged: this.onFieldcheckboxChanged })));
        }
        get el() { return index.getElement(this); }
    };
    NvFielddropdownitemcheck.style = NvFielddropdownitemcheckStyle0;

    exports.nv_badge = NvBadge;
    exports.nv_fielddropdownitemcheck = NvFielddropdownitemcheck;

}));
