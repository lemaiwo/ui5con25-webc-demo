sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/_commonjsHelpers-1789f0cf', 'be/wl/webc/demo/thirdparty/constants-98e2dcc2'], (function (exports, index, _commonjsHelpers1789f0cf, constants98e2dcc2) { 'use strict';

    var dayjs_min = {exports: {}};

    (function (module, exports) {
    !function(t,e){module.exports=e();}(_commonjsHelpers1789f0cf.commonjsGlobal,(function(){var t=1e3,e=6e4,n=36e5,r="millisecond",i="second",s="minute",u="hour",a="day",o="week",c="month",f="quarter",h="year",d="date",l="Invalid Date",$=/^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,y=/\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,M={name:"en",weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),ordinal:function(t){var e=["th","st","nd","rd"],n=t%100;return "["+t+(e[(n-20)%10]||e[n]||e[0])+"]"}},m=function(t,e,n){var r=String(t);return !r||r.length>=e?t:""+Array(e+1-r.length).join(n)+t},v={s:m,z:function(t){var e=-t.utcOffset(),n=Math.abs(e),r=Math.floor(n/60),i=n%60;return (e<=0?"+":"-")+m(r,2,"0")+":"+m(i,2,"0")},m:function t(e,n){if(e.date()<n.date())return -t(n,e);var r=12*(n.year()-e.year())+(n.month()-e.month()),i=e.clone().add(r,c),s=n-i<0,u=e.clone().add(r+(s?-1:1),c);return +(-(r+(n-i)/(s?i-u:u-i))||0)},a:function(t){return t<0?Math.ceil(t)||0:Math.floor(t)},p:function(t){return {M:c,y:h,w:o,d:a,D:d,h:u,m:s,s:i,ms:r,Q:f}[t]||String(t||"").toLowerCase().replace(/s$/,"")},u:function(t){return void 0===t}},g="en",D={};D[g]=M;var p="$isDayjsObject",S=function(t){return t instanceof _||!(!t||!t[p])},w=function t(e,n,r){var i;if(!e)return g;if("string"==typeof e){var s=e.toLowerCase();D[s]&&(i=s),n&&(D[s]=n,i=s);var u=e.split("-");if(!i&&u.length>1)return t(u[0])}else {var a=e.name;D[a]=e,i=a;}return !r&&i&&(g=i),i||!r&&g},O=function(t,e){if(S(t))return t.clone();var n="object"==typeof e?e:{};return n.date=t,n.args=arguments,new _(n)},b=v;b.l=w,b.i=S,b.w=function(t,e){return O(t,{locale:e.$L,utc:e.$u,x:e.$x,$offset:e.$offset})};var _=function(){function M(t){this.$L=w(t.locale,null,true),this.parse(t),this.$x=this.$x||t.x||{},this[p]=true;}var m=M.prototype;return m.parse=function(t){this.$d=function(t){var e=t.date,n=t.utc;if(null===e)return new Date(NaN);if(b.u(e))return new Date;if(e instanceof Date)return new Date(e);if("string"==typeof e&&!/Z$/i.test(e)){var r=e.match($);if(r){var i=r[2]-1||0,s=(r[7]||"0").substring(0,3);return n?new Date(Date.UTC(r[1],i,r[3]||1,r[4]||0,r[5]||0,r[6]||0,s)):new Date(r[1],i,r[3]||1,r[4]||0,r[5]||0,r[6]||0,s)}}return new Date(e)}(t),this.init();},m.init=function(){var t=this.$d;this.$y=t.getFullYear(),this.$M=t.getMonth(),this.$D=t.getDate(),this.$W=t.getDay(),this.$H=t.getHours(),this.$m=t.getMinutes(),this.$s=t.getSeconds(),this.$ms=t.getMilliseconds();},m.$utils=function(){return b},m.isValid=function(){return !(this.$d.toString()===l)},m.isSame=function(t,e){var n=O(t);return this.startOf(e)<=n&&n<=this.endOf(e)},m.isAfter=function(t,e){return O(t)<this.startOf(e)},m.isBefore=function(t,e){return this.endOf(e)<O(t)},m.$g=function(t,e,n){return b.u(t)?this[e]:this.set(n,t)},m.unix=function(){return Math.floor(this.valueOf()/1e3)},m.valueOf=function(){return this.$d.getTime()},m.startOf=function(t,e){var n=this,r=!!b.u(e)||e,f=b.p(t),l=function(t,e){var i=b.w(n.$u?Date.UTC(n.$y,e,t):new Date(n.$y,e,t),n);return r?i:i.endOf(a)},$=function(t,e){return b.w(n.toDate()[t].apply(n.toDate("s"),(r?[0,0,0,0]:[23,59,59,999]).slice(e)),n)},y=this.$W,M=this.$M,m=this.$D,v="set"+(this.$u?"UTC":"");switch(f){case h:return r?l(1,0):l(31,11);case c:return r?l(1,M):l(0,M+1);case o:var g=this.$locale().weekStart||0,D=(y<g?y+7:y)-g;return l(r?m-D:m+(6-D),M);case a:case d:return $(v+"Hours",0);case u:return $(v+"Minutes",1);case s:return $(v+"Seconds",2);case i:return $(v+"Milliseconds",3);default:return this.clone()}},m.endOf=function(t){return this.startOf(t,false)},m.$set=function(t,e){var n,o=b.p(t),f="set"+(this.$u?"UTC":""),l=(n={},n[a]=f+"Date",n[d]=f+"Date",n[c]=f+"Month",n[h]=f+"FullYear",n[u]=f+"Hours",n[s]=f+"Minutes",n[i]=f+"Seconds",n[r]=f+"Milliseconds",n)[o],$=o===a?this.$D+(e-this.$W):e;if(o===c||o===h){var y=this.clone().set(d,1);y.$d[l]($),y.init(),this.$d=y.set(d,Math.min(this.$D,y.daysInMonth())).$d;}else l&&this.$d[l]($);return this.init(),this},m.set=function(t,e){return this.clone().$set(t,e)},m.get=function(t){return this[b.p(t)]()},m.add=function(r,f){var d,l=this;r=Number(r);var $=b.p(f),y=function(t){var e=O(l);return b.w(e.date(e.date()+Math.round(t*r)),l)};if($===c)return this.set(c,this.$M+r);if($===h)return this.set(h,this.$y+r);if($===a)return y(1);if($===o)return y(7);var M=(d={},d[s]=e,d[u]=n,d[i]=t,d)[$]||1,m=this.$d.getTime()+r*M;return b.w(m,this)},m.subtract=function(t,e){return this.add(-1*t,e)},m.format=function(t){var e=this,n=this.$locale();if(!this.isValid())return n.invalidDate||l;var r=t||"YYYY-MM-DDTHH:mm:ssZ",i=b.z(this),s=this.$H,u=this.$m,a=this.$M,o=n.weekdays,c=n.months,f=n.meridiem,h=function(t,n,i,s){return t&&(t[n]||t(e,r))||i[n].slice(0,s)},d=function(t){return b.s(s%12||12,t,"0")},$=f||function(t,e,n){var r=t<12?"AM":"PM";return n?r.toLowerCase():r};return r.replace(y,(function(t,r){return r||function(t){switch(t){case "YY":return String(e.$y).slice(-2);case "YYYY":return b.s(e.$y,4,"0");case "M":return a+1;case "MM":return b.s(a+1,2,"0");case "MMM":return h(n.monthsShort,a,c,3);case "MMMM":return h(c,a);case "D":return e.$D;case "DD":return b.s(e.$D,2,"0");case "d":return String(e.$W);case "dd":return h(n.weekdaysMin,e.$W,o,2);case "ddd":return h(n.weekdaysShort,e.$W,o,3);case "dddd":return o[e.$W];case "H":return String(s);case "HH":return b.s(s,2,"0");case "h":return d(1);case "hh":return d(2);case "a":return $(s,u,true);case "A":return $(s,u,false);case "m":return String(u);case "mm":return b.s(u,2,"0");case "s":return String(e.$s);case "ss":return b.s(e.$s,2,"0");case "SSS":return b.s(e.$ms,3,"0");case "Z":return i}return null}(t)||i.replace(":","")}))},m.utcOffset=function(){return 15*-Math.round(this.$d.getTimezoneOffset()/15)},m.diff=function(r,d,l){var $,y=this,M=b.p(d),m=O(r),v=(m.utcOffset()-this.utcOffset())*e,g=this-m,D=function(){return b.m(y,m)};switch(M){case h:$=D()/12;break;case c:$=D();break;case f:$=D()/3;break;case o:$=(g-v)/6048e5;break;case a:$=(g-v)/864e5;break;case u:$=g/n;break;case s:$=g/e;break;case i:$=g/t;break;default:$=g;}return l?$:b.a($)},m.daysInMonth=function(){return this.endOf(c).$D},m.$locale=function(){return D[this.$L]},m.locale=function(t,e){if(!t)return this.$L;var n=this.clone(),r=w(t,e,true);return r&&(n.$L=r),n},m.clone=function(){return b.w(this.$d,this)},m.toDate=function(){return new Date(this.valueOf())},m.toJSON=function(){return this.isValid()?this.toISOString():null},m.toISOString=function(){return this.$d.toISOString()},m.toString=function(){return this.$d.toUTCString()},M}(),k=_.prototype;return O.prototype=k,[["$ms",r],["$s",i],["$m",s],["$H",u],["$W",a],["$M",c],["$y",h],["$D",d]].forEach((function(t){k[t[1]]=function(e){return this.$g(e,t[0],t[1])};})),O.extend=function(t,e){return t.$i||(t(e,_,O),t.$i=true),O},O.locale=w,O.isDayjs=S,O.unix=function(t){return O(1e3*t)},O.en=D[g],O.Ls=D,O.p={},O}));
    }(dayjs_min));

    const dayjs = dayjs_min.exports;

    var customParseFormat$1 = {exports: {}};

    (function (module, exports) {
    !function(e,t){module.exports=t();}(_commonjsHelpers1789f0cf.commonjsGlobal,(function(){var e={LTS:"h:mm:ss A",LT:"h:mm A",L:"MM/DD/YYYY",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY h:mm A",LLLL:"dddd, MMMM D, YYYY h:mm A"},t=/(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|Q|YYYY|YY?|ww?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g,n=/\d/,r=/\d\d/,i=/\d\d?/,o=/\d*[^-_:/,()\s\d]+/,s={},a=function(e){return (e=+e)+(e>68?1900:2e3)};var f=function(e){return function(t){this[e]=+t;}},h=[/[+-]\d\d:?(\d\d)?|Z/,function(e){(this.zone||(this.zone={})).offset=function(e){if(!e)return 0;if("Z"===e)return 0;var t=e.match(/([+-]|\d\d)/g),n=60*t[1]+(+t[2]||0);return 0===n?0:"+"===t[0]?-n:n}(e);}],u=function(e){var t=s[e];return t&&(t.indexOf?t:t.s.concat(t.f))},d=function(e,t){var n,r=s.meridiem;if(r){for(var i=1;i<=24;i+=1)if(e.indexOf(r(i,0,t))>-1){n=i>12;break}}else n=e===(t?"pm":"PM");return n},c={A:[o,function(e){this.afternoon=d(e,false);}],a:[o,function(e){this.afternoon=d(e,true);}],Q:[n,function(e){this.month=3*(e-1)+1;}],S:[n,function(e){this.milliseconds=100*+e;}],SS:[r,function(e){this.milliseconds=10*+e;}],SSS:[/\d{3}/,function(e){this.milliseconds=+e;}],s:[i,f("seconds")],ss:[i,f("seconds")],m:[i,f("minutes")],mm:[i,f("minutes")],H:[i,f("hours")],h:[i,f("hours")],HH:[i,f("hours")],hh:[i,f("hours")],D:[i,f("day")],DD:[r,f("day")],Do:[o,function(e){var t=s.ordinal,n=e.match(/\d+/);if(this.day=n[0],t)for(var r=1;r<=31;r+=1)t(r).replace(/\[|\]/g,"")===e&&(this.day=r);}],w:[i,f("week")],ww:[r,f("week")],M:[i,f("month")],MM:[r,f("month")],MMM:[o,function(e){var t=u("months"),n=(u("monthsShort")||t.map((function(e){return e.slice(0,3)}))).indexOf(e)+1;if(n<1)throw new Error;this.month=n%12||n;}],MMMM:[o,function(e){var t=u("months").indexOf(e)+1;if(t<1)throw new Error;this.month=t%12||t;}],Y:[/[+-]?\d+/,f("year")],YY:[r,function(e){this.year=a(e);}],YYYY:[/\d{4}/,f("year")],Z:h,ZZ:h};function l(n){var r,i;r=n,i=s&&s.formats;for(var o=(n=r.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g,(function(t,n,r){var o=r&&r.toUpperCase();return n||i[r]||e[r]||i[o].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g,(function(e,t,n){return t||n.slice(1)}))}))).match(t),a=o.length,f=0;f<a;f+=1){var h=o[f],u=c[h],d=u&&u[0],l=u&&u[1];o[f]=l?{regex:d,parser:l}:h.replace(/^\[|\]$/g,"");}return function(e){for(var t={},n=0,r=0;n<a;n+=1){var i=o[n];if("string"==typeof i)r+=i.length;else {var s=i.regex,f=i.parser,h=e.slice(r),u=s.exec(h)[0];f.call(t,u),e=e.replace(u,"");}}return function(e){var t=e.afternoon;if(void 0!==t){var n=e.hours;t?n<12&&(e.hours+=12):12===n&&(e.hours=0),delete e.afternoon;}}(t),t}}return function(e,t,n){n.p.customParseFormat=true,e&&e.parseTwoDigitYear&&(a=e.parseTwoDigitYear);var r=t.prototype,i=r.parse;r.parse=function(e){var t=e.date,r=e.utc,o=e.args;this.$u=r;var a=o[1];if("string"==typeof a){var f=true===o[2],h=true===o[3],u=f||h,d=o[2];h&&(d=o[2]),s=this.$locale(),!f&&d&&(s=n.Ls[d]),this.$d=function(e,t,n,r){try{if(["x","X"].indexOf(t)>-1)return new Date(("X"===t?1e3:1)*e);var i=l(t)(e),o=i.year,s=i.month,a=i.day,f=i.hours,h=i.minutes,u=i.seconds,d=i.milliseconds,c=i.zone,m=i.week,M=new Date,Y=a||(o||s?1:M.getDate()),p=o||M.getFullYear(),v=0;o&&!s||(v=s>0?s-1:M.getMonth());var D,w=f||0,g=h||0,y=u||0,L=d||0;return c?new Date(Date.UTC(p,v,Y,w,g,y,L+60*c.offset*1e3)):n?new Date(Date.UTC(p,v,Y,w,g,y,L)):(D=new Date(p,v,Y,w,g,y,L),m&&(D=r(D).week(m).toDate()),D)}catch(e){return new Date("")}}(t,a,r,n),this.init(),d&&true!==d&&(this.$L=this.locale(d).$L),u&&t!=this.format(a)&&(this.$d=new Date("")),s={};}else if(a instanceof Array)for(var c=a.length,m=1;m<=c;m+=1){o[1]=a[m-1];var M=n.apply(this,o);if(M.isValid()){this.$d=M.$d,this.$L=M.$L,this.init();break}m===c&&(this.$d=new Date(""));}else i.call(this,e);};}}));
    }(customParseFormat$1));

    const customParseFormat = customParseFormat$1.exports;

    var utc$1 = {exports: {}};

    (function (module, exports) {
    !function(t,i){module.exports=i();}(_commonjsHelpers1789f0cf.commonjsGlobal,(function(){var t="minute",i=/[+-]\d\d(?::?\d\d)?/g,e=/([+-]|\d\d)/g;return function(s,f,n){var u=f.prototype;n.utc=function(t){var i={date:t,utc:true,args:arguments};return new f(i)},u.utc=function(i){var e=n(this.toDate(),{locale:this.$L,utc:true});return i?e.add(this.utcOffset(),t):e},u.local=function(){return n(this.toDate(),{locale:this.$L,utc:false})};var o=u.parse;u.parse=function(t){t.utc&&(this.$u=true),this.$utils().u(t.$offset)||(this.$offset=t.$offset),o.call(this,t);};var r=u.init;u.init=function(){if(this.$u){var t=this.$d;this.$y=t.getUTCFullYear(),this.$M=t.getUTCMonth(),this.$D=t.getUTCDate(),this.$W=t.getUTCDay(),this.$H=t.getUTCHours(),this.$m=t.getUTCMinutes(),this.$s=t.getUTCSeconds(),this.$ms=t.getUTCMilliseconds();}else r.call(this);};var a=u.utcOffset;u.utcOffset=function(s,f){var n=this.$utils().u;if(n(s))return this.$u?0:n(this.$offset)?a.call(this):this.$offset;if("string"==typeof s&&(s=function(t){ void 0===t&&(t="");var s=t.match(i);if(!s)return null;var f=(""+s[0]).match(e)||["-",0,0],n=f[0],u=60*+f[1]+ +f[2];return 0===u?0:"+"===n?u:-u}(s),null===s))return this;var u=Math.abs(s)<=16?60*s:s,o=this;if(f)return o.$offset=u,o.$u=0===s,o;if(0!==s){var r=this.$u?this.toDate().getTimezoneOffset():-1*this.utcOffset();(o=this.local().add(u+r,t)).$offset=u,o.$x.$localOffset=r;}else o=this.utc();return o};var h=u.format;u.format=function(t){var i=t||(this.$u?"YYYY-MM-DDTHH:mm:ss[Z]":"");return h.call(this,i)},u.valueOf=function(){var t=this.$utils().u(this.$offset)?0:this.$offset+(this.$x.$localOffset||this.$d.getTimezoneOffset());return this.$d.valueOf()-6e4*t},u.isUTC=function(){return !!this.$u},u.toISOString=function(){return this.toDate().toISOString()},u.toString=function(){return this.toDate().toUTCString()};var l=u.toDate;u.toDate=function(t){return "s"===t&&this.$offset?n(this.format("YYYY-MM-DD HH:mm:ss:SSS")).toDate():l.call(this)};var c=u.diff;u.diff=function(t,i,e){if(t&&this.$u===t.$u)return c.call(this,t,i,e);var s=this.local(),f=n(t).local();return c.call(s,f,i,e)};}}));
    }(utc$1));

    const utc = utc$1.exports;

    var weekOfYear$1 = {exports: {}};

    (function (module, exports) {
    !function(e,t){module.exports=t();}(_commonjsHelpers1789f0cf.commonjsGlobal,(function(){var e="week",t="year";return function(i,n,r){var f=n.prototype;f.week=function(i){if(void 0===i&&(i=null),null!==i)return this.add(7*(i-this.week()),"day");var n=this.$locale().yearStart||1;if(11===this.month()&&this.date()>25){var f=r(this).startOf(t).add(1,t).date(n),s=r(this).endOf(e);if(f.isBefore(s))return 1}var a=r(this).startOf(t).date(n).startOf(e).subtract(1,"millisecond"),o=this.diff(a,e,true);return o<0?r(this).startOf("week").week():Math.ceil(o)},f.weeks=function(e){return void 0===e&&(e=null),this.week(e)};}}));
    }(weekOfYear$1));

    const weekOfYear = weekOfYear$1.exports;

    const nvCalendarCss = "nv-calendar{display:block}.datepicker-root{display:flex;justify-content:center;align-items:flex-start;width:auto}.datepicker-container{font-family:system-ui, sans-serif;display:flex;flex-direction:column;align-items:stretch;background:var(--components-calendar-background);border-radius:var(--calendar-radius);padding:var(--calendar-padding);box-shadow:0px var(--shadow-y-axis-md-1) var(--shadow-blur-md-1) var(--shadow-spread-md, 0) var(--shadow-color-opacity-0), 0px var(--shadow-y-axis-md-2) var(--shadow-blur-md-2) var(--shadow-spread-md, 0) var(--shadow-color-opacity-2);border:1px solid var(--components-calendar-border);width:auto;max-width:100%}.datepicker-container-single{max-width:300px}.datepicker-container-single .datepicker-wrapper:has(.shortcuts-placement-left),.datepicker-container-single .datepicker-wrapper:has(.shortcuts-placement-right){max-width:410px !important}.datepicker-container-single:has(.shortcuts-placement-left),.datepicker-container-single:has(.shortcuts-placement-right){max-width:410px !important}.datepicker-wrapper{display:flex;justify-content:center;align-items:flex-start;gap:var(--calendar-gap-x);width:auto;overflow-x:hidden}.datepicker-wrapper.single{justify-content:center}.calendar-container{display:flex;flex-direction:column;align-items:center;padding:var(--calendar-padding);width:auto;position:relative}.calendar-separator{width:1px;background:var(--components-calendar-border);height:auto;min-height:100%;margin:0 10px}.header{display:flex;justify-content:start;align-items:center;margin-bottom:var(--calendar-header-margin-bottom);width:100%}.header nv-iconbutton{width:var(--calendar-header-button-size);height:var(--calendar-header-button-size)}.nav-buttons{display:flex;gap:var(--spacing-0);margin-left:auto}.nav-left{order:-1}.date-controls{display:flex;gap:var(--spacing-1);align-items:center;min-height:34px;justify-content:center}.datepicker-container-single .date-controls{justify-content:flex-start}.datepicker-container:not(.datepicker-container-single) .date-controls{justify-content:start;flex-grow:1}.date-controls .month-select,.date-controls .year-input{background:transparent !important}.calendar-wrapper:nth-child(n+2) .datepicker-container{margin-left:42px}.calendar-grid{display:grid;grid-template-columns:auto 1fr;column-gap:var(--calendar-weeks-calendar-gap-x);position:relative}.calendar-grid.slide-left{animation:slideLeft 0.3s ease-out}.calendar-grid.slide-right{animation:slideRight 0.3s ease-out}.week-numbers{display:grid;grid-template-rows:var(--calendar-cell-size) repeat(6, var(--calendar-cell-size));background:var(--components-calendar-weeks-background);color:var(--components-calendar-weeks-text);border-radius:var(--calendar-weeks-radius);width:var(--calendar-weeks-size);row-gap:var(--calendar-grid-gap-y)}.week-numbers .clickable{cursor:pointer}.week-numbers .clickable:hover{background-color:var(--components-calendar-weeks-background-hover);color:var(--components-calendar-weeks-text-hover);border-radius:var(--calendar-radius)}.week-header,.week-number{display:grid;place-items:center;font-size:var(--calendar-cell-font-size)}.week-header{font-weight:700;color:var(--components-calendar-weeks-text)}.week-number{color:var(--components-calendar-cell-text)}.days-container{display:grid;grid-template-rows:auto 1fr;row-gap:var(--calendar-grid-gap-y)}.days-header{display:grid;grid-template-columns:repeat(7, var(--calendar-cell-size));height:var(--calendar-cell-size)}.day-header{display:grid;place-items:center;font-size:var(--calendar-cell-font-size);color:var(--components-calendar-cell-text)}.days-grid{display:grid;grid-template-columns:repeat(7, var(--calendar-cell-size));grid-template-rows:repeat(6, var(--calendar-cell-size));animation:fadeIn 0.2s ease-in;row-gap:var(--calendar-grid-gap-y);z-index:0}.day{display:grid;place-items:center;width:var(--calendar-cell-size);height:var(--calendar-cell-size);font-size:var(--calendar-cell-font-size);border-radius:var(--calendar-cell-radius);cursor:pointer;border:none;background:transparent;transition:all 0.2s ease;text-align:center;animation:scaleIn 0.2s ease-out}.day:hover:not(.disabled,.empty,.selected){background:var(--components-calendar-cell-background-hover);color:var(--components-calendar-cell-text-hover)}.day.selected,.day.selected:hover .day.is-today.selected,.day.is-today.selected:hover{background:var(--components-calendar-cell-background-selected);color:var(--components-calendar-cell-text-selected) !important}.day.disabled{opacity:var(--opacity-disabled);cursor:not-allowed}.day.outside-month{color:var(--components-calendar-cell-text);opacity:var(--opacity-disabled)}.day.outside-month.selected{opacity:1 !important;color:var(--components-calendar-cell-text-selected)}.day.outside-month.in-range{opacity:1 !important;background-color:var(--components-calendar-cell-background-in-range);color:var(--components-calendar-cell-text-in-range)}.day.in-range{background:var(--components-calendar-cell-background-in-range);color:var(--components-calendar-cell-text-in-range);border-radius:0;position:relative}.day.range-start,.day.range-start:focus,.day.range-start:hover,.day.range-end,.day.range-end:focus,.day.range-end:hover{background-color:var(--components-calendar-cell-background-selected) !important;color:var(--components-calendar-cell-text-selected) !important}.day.range-start,.day.range-end,.day.range-start.is-today,.day.range-end.is-today{background:var(--components-calendar-cell-background-selected);color:var(--components-calendar-cell-text-selected);position:relative;border-radius:var(--radius-rounded-full)}.day.range-start:hover,.day.range-end:hover,.day.range-start.is-today:hover,.day.range-end.is-today:hover{color:var(--components-calendar-cell-text-today)}.day.range-start:before,.day.range-end:before,.day.range-start.is-today:before,.day.range-end.is-today:before{content:\"\";position:absolute;bottom:0;left:0;right:0;top:0;z-index:-1;background-color:var(--components-calendar-cell-background-in-range);border-radius:var(--radius-rounded-full);width:auto;height:auto}.day.range-start:has(~.range-end):before,.day.range-start:has(+.in-range):before{border-top-right-radius:0;border-bottom-right-radius:0}.day.range-end:before{border-top-left-radius:0 !important;border-bottom-left-radius:0 !important}.day.outside-month.range-start,.day.outside-month.range-end{background:var(--components-calendar-cell-background-selected) !important;color:var(--components-calendar-cell-text-selected);opacity:1 !important}.day.is-today{font-weight:700;position:relative;color:var(--components-calendar-cell-text-today)}.day.is-today.range-start,.day.is-today.range-end{color:var(--components-calendar-cell-text-selected)}.day.is-today.range-start:hover,.day.is-today.range-end:hover{color:var(--components-calendar-cell-text-today)}.day.is-today::after{content:\"\";position:absolute;bottom:var(--spacing-1);left:50%;transform:translateX(-50%);width:var(--calendar-cell-dot-size);height:var(--calendar-cell-dot-size);background-color:currentColor;border-radius:50%}.day.is-today.selected::after{color:var(--components-calendar-cell-text-selected)}.day.is-today.selected::after::after{background-color:var(--components-calendar-cell-dot-selected)}.calendar-footer{display:flex;gap:var(--spacing-1);justify-content:flex-start;width:100%;flex-wrap:wrap}.footer-placement-left{justify-content:flex-start}.footer-placement-right{justify-content:flex-end}.footer-placement-center{justify-content:center}.datepicker-controls{display:flex;flex-direction:column;border-top:1px solid var(--components-calendar-border);padding:var(--calendar-controls-padding-top) var(--calendar-padding) var(--calendar-padding);gap:var(--calendar-grid-gap-y);margin-top:var(--calendar-controls-margin-top)}.datepicker-actions{display:flex;justify-content:flex-end;gap:var(--spacing-1);width:100%}.datepicker-actions slot-fb{display:contents !important}.calendar-footer+.datepicker-actions{margin-top:0}.shortcuts-placement-left,.shortcuts-placement-right{display:flex;flex-direction:column;gap:var(--spacing-1);margin-top:var(--spacing-4)}.shortcuts-placement-left{align-items:flex-end}.shortcuts-placement-right{align-items:flex-start}@keyframes slideLeft{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}@keyframes slideRight{from{opacity:0;transform:translateX(-20px)}to{opacity:1;transform:translateX(0)}}@keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}@keyframes scaleIn{from{opacity:0;transform:scale(0.9)}to{opacity:1;transform:scale(1)}}";
    const NvCalendarStyle0 = nvCalendarCss;

    // Extend dayjs with plugins
    dayjs.extend(customParseFormat);
    dayjs.extend(utc);
    dayjs.extend(weekOfYear);
    const NvCalendar = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.singleDateChange = index.createEvent(this, "singleDateChange");
            this.rangeDateChange = index.createEvent(this, "rangeDateChange");
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * First day of the week (0 = Sunday, 1 = Monday, etc.)
             * @default 0
             */
            this.firstDayOfWeek = 0;
            /**
             * Number of calendars to display
             * @default 1
             */
            this.numberOfCalendars = 1;
            /**
             * Selected date (ISO string format)
             * ex: "2025-03-15"
             */
            this.singleValue = '';
            /**
             * Selected date range
             * format: { start: ISO string, end: ISO string }
             * ex: { start: "2025-03-15", end: "2025-03-20" }
             */
            this.rangeValue = '';
            /**
             * Minimum date for selection (ISO string format, ex: "2025-01-01")
             */
            this.min = '';
            /**
             * Maximum date for selection (ISO string format, ex: "2025-12-31")
             */
            this.max = '';
            /** Disabled dates (ISO string array)
             * @default '[]'
             */
            this.disabledDates = '';
            /** Locale for date formatting
             * @default 'en-BE'
             */
            this.locale = 'en-BE';
            /** Date format (ex: 'YYYY-MM-DD', 'DD-MM-YYYY', etc.)
             * @default 'YYYY-MM-DD'
             * @note If the date format is in UTC mode, the date will be displayed in UTC time.
             * @note If the date format is not in UTC mode, the date will be displayed in the local time.
             */
            this.dateFormat = 'YYYY-MM-DD';
            /**
             * Footer placement
             * @default 'bottom'
             */
            this.shortcutsPlacement = 'bottom';
            /**
             * Selection type (single date or date range)
             * @default 'single'
             */
            this.selectionType = 'single';
            /**
             * Show action buttons
             * @default false
             */
            this.showActions = false;
            /**
             * Custom actions to display in the footer
             * JSON array of objects with the following properties:
             * - label: string
             * - onClick: function
             * @default '[]'
             */
            this.shortcuts = '[]';
            /** Cache for parsed disabled dates */
            this.parsedDisabledDates = [];
            /** Selected date */
            this.selectedDate = null;
            /** Start date */
            this.startDate = null;
            /** End date */
            this.endDate = null;
            /** List of formatted months for the selector */
            this.months = [];
            /**
             * Resets the current selection
             */
            this.resetSelection = () => {
                if (this.selectionType === 'single') {
                    this.selectedDate = null;
                    this.singleValue = '';
                    this.singleDateChange.emit('');
                }
                else {
                    this.startDate = null;
                    this.endDate = null;
                    this.rangeValue = '';
                    this.rangeDateChange.emit({ start: '', end: '' });
                }
            };
            /**
             * Confirms the current selection
             */
            this.confirmSelection = () => {
                if (this.selectionType === 'single' && this.selectedDate) {
                    const dateStr = this.formatDate(this.selectedDate);
                    this.singleDateChange.emit(dateStr);
                    this.singleValue = dateStr;
                    const event = new CustomEvent('closePopover', {
                        bubbles: true,
                        composed: true,
                    });
                    this.el.dispatchEvent(event);
                }
                else if (this.selectionType === 'range' &&
                    this.startDate &&
                    this.endDate) {
                    this.rangeDateChange.emit({
                        start: this.formatDate(this.startDate),
                        end: this.formatDate(this.endDate),
                    });
                    this.rangeValue = JSON.stringify({
                        start: this.formatDate(this.startDate),
                        end: this.formatDate(this.endDate),
                    });
                    const event = new CustomEvent('closePopover', {
                        bubbles: true,
                        composed: true,
                    });
                    this.el.dispatchEvent(event);
                }
            };
        }
        //#endregion EVENTS
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillLoad() {
            this.parseDisabledDates();
            if (this.selectionType === 'single' && this.singleValue) {
                this.selectedDate = this.parseDate(this.singleValue);
                this.currentDate = this.selectedDate;
            }
            else if (this.selectionType === 'range' && this.rangeValue) {
                try {
                    let parsed;
                    if (typeof this.rangeValue === 'string') {
                        parsed = JSON.parse(this.rangeValue);
                    }
                    else {
                        parsed = this.rangeValue;
                    }
                    if (parsed.start && parsed.end) {
                        this.startDate = this.parseDate(parsed.start);
                        this.endDate = this.parseDate(parsed.end);
                        this.currentDate = this.startDate;
                        if (this.startDate && this.endDate && this.startDate > this.endDate) {
                            console.warn(`Warning: startDate (${this.formatDate(this.startDate)}) is after endDate (${this.formatDate(this.endDate)})`);
                            // [this.startDate, this.endDate] = [this.endDate, this.startDate];
                            throw new Error('startDate cannot be after endDate');
                        }
                    }
                }
                catch (error) {
                    console.error('Invalid JSON for rangeValue:', error);
                }
            }
            else {
                this.currentDate = new Date();
            }
            this.initializeMonths();
        }
        // componentDidLoad() {
        //   if (this.rangeValue) {
        //     this.onRangeValueChange(this.rangeValue);
        //   }
        // }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region METHODS
        /**
         * Change the displayed month
         * @param {number} offset - Month offset (-1 for previous, 1 for next)
         */
        changeMonth(offset) {
            const newDate = new Date(this.currentDate);
            // Ensure we only move by one month at a time
            newDate.setUTCMonth(newDate.getUTCMonth() + offset);
            // Add the appropriate animation class
            const containers = this.el.querySelectorAll('.calendar-grid');
            containers.forEach(container => {
                // Remove existing animation classes
                container.classList.remove('slide-left', 'slide-right');
                // Add the new animation class
                const animationClass = offset > 0 ? 'slide-left' : 'slide-right';
                container.classList.add(animationClass);
                // Remove the class after the animation
                setTimeout(() => {
                    container.classList.remove(animationClass);
                }, 300); // 300ms corresponds to $slide-duration in the SCSS
            });
            this.currentDate = newDate;
        }
        /**
         * Handles date selection based on the mode
         * @param {Date} date - Selected date
         */
        handleDateSelection(date) {
            if (this.isDateDisabled(date)) {
                return;
            }
            if (this.selectionType === 'single') {
                this.handleSingleSelection(date);
            }
            else {
                this.handleRangeSelection(date);
            }
        }
        /**
         * Handles single date selection
         * @param {Date} date - Selected date
         */
        handleSingleSelection(date) {
            if (!date)
                return;
            const formattedDate = this.formatDate(date);
            this.selectedDate = date;
            this.singleDateChange.emit(formattedDate);
        }
        /**
         * Handles range date selection
         * @param {Date} date - Selected date
         */
        handleRangeSelection(date) {
            if (!this.startDate || (this.startDate && this.endDate)) {
                this.startDate = date;
                this.endDate = null;
            }
            else {
                this.endDate = date;
                if (this.startDate > this.endDate) {
                    [this.startDate, this.endDate] = [this.endDate, this.startDate];
                }
                this.rangeDateChange.emit({
                    start: this.formatDate(this.startDate),
                    end: this.formatDate(this.endDate),
                });
            }
        }
        /**
         * Calculates the ISO week number
         * @param {Date} date - Date to calculate
         * @returns {number} Week number
         */
        getWeekNumber(date) {
            const startOfYear = new Date(date.getFullYear(), 0, 1);
            const pastDaysOfYear = (date.getTime() - startOfYear.getTime()) / 86400000;
            return Math.ceil((pastDaysOfYear + startOfYear.getDay() + 1) / 7);
        }
        /**
         * Checks if a date is disabled.
         * Disabled if:
         * - The date is before min (if defined)
         * - The date is after max (if defined)
         * - The date is in the disabledDates array
         * @param {Date} date - Date to check
         * @returns {boolean} true if the date is disabled
         */
        isDateDisabled(date) {
            if (!date)
                return true;
            // Minimum bound check
            if (this.min) {
                const minDate = this.parseDate(this.min);
                if (minDate && date < minDate) {
                    return true;
                }
            }
            // Maximum bound check
            if (this.max) {
                const maxDate = this.parseDate(this.max);
                if (maxDate && date > maxDate) {
                    return true;
                }
            }
            // Check disabled dates
            return this.parsedDisabledDates.some(disabledDate => this.isSameDate(date, disabledDate));
        }
        /**
         * Checks if a date is in the selected range
         * @param {Date} date - Date to check
         * @returns {boolean} true if the date is in the range
         */
        isDateInRange(date) {
            if (!date || !this.startDate || !this.endDate)
                return false;
            const checkDate = this.parseDate(date);
            const startDate = this.parseDate(this.startDate);
            const endDate = this.parseDate(this.endDate);
            // Verify if startDate and endDate are valid
            if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
                return false;
            }
            // Verify that startDate is before endDate (additional security)
            if (startDate > endDate)
                return false;
            // Comparison based only on the date (year, month, day)
            return (this.isSameOrAfter(checkDate, startDate) &&
                this.isSameOrBefore(checkDate, endDate));
        }
        /**
         * Retrieves the localized day names
         * @returns {string[]} Array of short day names
         */
        getDayNames() {
            // If we have custom day names for this locale
            if (constants98e2dcc2.CUSTOM_DAY_NAMES[this.locale]) {
                const days = [...constants98e2dcc2.CUSTOM_DAY_NAMES[this.locale]];
                // Reorganize the days based on the first day of the week
                const firstDays = days.slice(0, this.firstDayOfWeek);
                const remainingDays = days.slice(this.firstDayOfWeek);
                return [...remainingDays, ...firstDays];
            }
            // Otherwise, use the default behavior
            const formatter = new Intl.DateTimeFormat(this.locale, {
                weekday: 'short',
            });
            const days = [...Array(7)].map((_, i) => formatter.format(new Date(2023, 0, i + 1)).toUpperCase());
            // Reorganize the days based on the first day of the week
            const firstDays = days.slice(0, this.firstDayOfWeek);
            const remainingDays = days.slice(this.firstDayOfWeek);
            return [...remainingDays, ...firstDays];
        }
        /**
         * Generates the days of the current month
         * @param {number} offset - Month offset (0 by default)
         * @param {number} totalCalendars - Number of calendars to display (1 by default)
         * @returns {Array<{ dayOfMonth: number | null, date: Date | null, isSelected: boolean, isDisabled: boolean }>} Array of formatted days
         */
        getDaysInMonth(offset = 0, totalCalendars = 1) {
            const year = this.currentDate.getUTCFullYear();
            const month = this.currentDate.getUTCMonth() + offset;
            const firstDay = new Date(Date.UTC(year, month, 1));
            const lastDay = new Date(Date.UTC(year, month + 1, 0));
            const days = [];
            // Correct calculation of offset for previous month days
            // Use getUTCDay to stay consistent with UTC timezone
            const dayOfWeekIndex = firstDay.getUTCDay(); // 0 = Sunday, 1 = Monday, etc.
            // Adjust based on firstDayOfWeek (if week starts on Monday, offset is different)
            const offsetDays = (dayOfWeekIndex - this.firstDayOfWeek + 7) % 7;
            // Add the days of the previous month for the first calendar
            if (offset === 0 && offsetDays > 0) {
                const prevMonthLastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
                for (let i = offsetDays; i > 0; i--) {
                    const date = new Date(Date.UTC(year, month - 1, prevMonthLastDay - i + 1));
                    days.push({
                        dayOfMonth: date.getUTCDate(),
                        date,
                        isCurrentMonth: false,
                        isDisabled: this.isDateDisabled(date),
                    });
                }
            }
            // Add the days of the current month
            for (let i = 1; i <= lastDay.getUTCDate(); i++) {
                const date = new Date(Date.UTC(year, month, i));
                days.push({
                    dayOfMonth: i,
                    date,
                    isCurrentMonth: true,
                    isDisabled: this.isDateDisabled(date),
                });
            }
            // Add the days of the next month only for the last calendar
            if (offset === totalCalendars - 1) {
                const nextMonthDaysNeeded = 7 - (days.length % 7 || 7);
                for (let i = 1; i <= nextMonthDaysNeeded; i++) {
                    const date = new Date(Date.UTC(year, month + 1, i));
                    days.push({
                        dayOfMonth: i,
                        date,
                        isCurrentMonth: false,
                        isDisabled: this.isDateDisabled(date),
                    });
                }
            }
            return days;
        }
        /** Initializes the list of formatted months according to the locale */
        initializeMonths() {
            // If we have custom month names for this locale
            if (constants98e2dcc2.CUSTOM_MONTH_NAMES[this.locale]) {
                this.months = constants98e2dcc2.CUSTOM_MONTH_NAMES[this.locale].map((label, value) => ({
                    value,
                    label,
                }));
                return;
            }
            // Otherwise, use the default behavior
            const formatter = new Intl.DateTimeFormat(this.locale, { month: 'short' });
            this.months = Array.from({ length: 12 }, (_, i) => ({
                value: i,
                label: formatter.format(new Date(2000, i, 1)).toUpperCase(),
            }));
        }
        /**
         * Retrieves the localized abbreviation for "week"
         * @returns {string} Localized abbreviation for "week"
         */
        getLocalizedWeekText() {
            return constants98e2dcc2.WEEK_ABBREVIATIONS[this.locale] || 'W';
        }
        /**
         * Handles month change in the selector
         * @param {Event} event - Month change event
         * @param {number} calendarOffset - Calendar offset (0 by default)
         */
        handleMonthChange(event, calendarOffset = 0) {
            const select = event.target;
            const selectedMonth = parseInt(select.value, 10);
            const currentMonth = this.currentDate.getUTCMonth();
            // Calculate the difference considering the calendar offset
            const monthDiff = selectedMonth - ((currentMonth + calendarOffset) % 12);
            const newDate = new Date(this.currentDate);
            newDate.setUTCMonth(newDate.getUTCMonth() + monthDiff);
            this.currentDate = newDate;
        }
        /**
         * Handles year change in the numeric entry
         * @param {Event} event - Year change event
         * @param {number} calendarOffset - Calendar offset (0 by default)
         */
        handleYearChange(event, calendarOffset = 0) {
            const input = event.target;
            const year = parseInt(input.value, 10);
            if (!isNaN(year) && year >= 1900 && year <= 2100) {
                const newDate = new Date(this.currentDate);
                newDate.setUTCFullYear(year);
                newDate.setUTCMonth(newDate.getUTCMonth() + calendarOffset);
                this.currentDate = newDate;
            }
        }
        /**
         * Handles week selection
         * @param {Date[]} weekDays - Selected week days
         * @param {number} calendarIndex - Calendar index from which the selection is made
         */
        handleWeekSelection(weekDays, calendarIndex) {
            if (this.selectionType !== 'range')
                return;
            const allDays = this.getDaysInMonth(calendarIndex, this.numberOfCalendars);
            const weekStart = weekDays[0];
            const weekEnd = weekDays[weekDays.length - 1];
            if (!weekStart || !weekEnd)
                return;
            const selectedWeekDays = allDays.filter(day => day.date && day.date >= weekStart && day.date <= weekEnd);
            const validDays = selectedWeekDays.filter(day => !this.isDateDisabled(day.date));
            if (validDays.length > 0) {
                this.startDate = validDays[0].date;
                this.endDate = validDays[validDays.length - 1].date;
                this.rangeDateChange.emit({
                    start: this.formatDate(this.startDate),
                    end: this.formatDate(this.endDate),
                });
            }
        }
        /**
         * Checks if a date corresponds to today
         * @param {Date} date - Date to check
         * @returns {boolean} true if the date is today
         */
        isToday(date) {
            const today = new Date();
            return (date.getDate() === today.getDate() &&
                date.getMonth() === today.getMonth() &&
                date.getFullYear() === today.getFullYear());
        }
        /**
         * Watches the changes of the number of calendars
         * @watch numberOfCalendars
         * @param {number} newValue - New number of calendars
         */
        validateNumberOfCalendars(newValue) {
            if (newValue < 1 || newValue > 4) {
                console.warn('numberOfCalendars must be between 1 and 4. Defaulting to 1.');
                this.numberOfCalendars = 1;
            }
        }
        /**
         * Watches the changes of the selected date range
         * @watch rangeValue
         * @param {Object} newValue - New rangeValue value
         * @param {string} newValue.start - Start date
         * @param {string} newValue.end - End date
         */
        onRangeValueChange(newValue) {
            if (newValue) {
                try {
                    const parsed = JSON.parse(newValue);
                    if (parsed.start && parsed.end) {
                        this.startDate = this.parseDate(parsed.start);
                        this.endDate = this.parseDate(parsed.end);
                        this.currentDate = this.parseDate(parsed.start);
                    }
                }
                catch (error) {
                    console.error('Invalid JSON for rangeValue:', error);
                }
            }
        }
        /**
         * Watches the changes of the disabled dates
         * @watch disabledDates
         * @description Watches the changes of the disabled dates
         */
        handleDisabledDatesChange() {
            this.parseDisabledDates();
        }
        /**
         * Watches the changes of the single value
         * @watch singleValue
         * @param {string} newValue - New single value
         * @param {string} oldValue - Old single value
         */
        onSingleValueChange(newValue, oldValue) {
            if (this.selectionType === 'single' && newValue !== oldValue && newValue) {
                const parsedDate = this.parseDate(newValue);
                if (parsedDate) {
                    this.selectedDate = parsedDate;
                    this.currentDate = parsedDate;
                }
            }
        }
        /**
         * Convert a date string/Date to a Date without timezone offset
         * @param {string | Date} dateInput - Date under string or Date object form
         * @returns {Date} Date in Date form without timezone offset
         */
        parseDate(dateInput) {
            if (dateInput instanceof Date)
                return dateInput;
            // Attempt to automatically detect ISO 8601 format (generated by toISOString())
            // The regex checks the standard ISO format: YYYY-MM-DDTHH:mm:ss.sssZ
            if (typeof dateInput === 'string' &&
                /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z$/.test(dateInput)) {
                try {
                    const parsedDate = new Date(dateInput);
                    if (!isNaN(parsedDate.getTime())) {
                        return parsedDate;
                    }
                }
                catch (error) {
                    // If it fails, continue with other methods
                    console.error('Error parsing ISO date:', error);
                }
            }
            // Handling Unix Seconds ("X") formats
            if (this.dateFormat === 'X') {
                const unixSeconds = Number(dateInput);
                if (isNaN(unixSeconds))
                    return null;
                return this.isUTCMode
                    ? dayjs.unix(unixSeconds).utc().toDate()
                    : dayjs.unix(unixSeconds).toDate();
            }
            // Handling Unix Milliseconds ("x") formats
            if (this.dateFormat === 'x') {
                const unixMilliseconds = Number(dateInput);
                if (isNaN(unixMilliseconds))
                    return null;
                return this.isUTCMode
                    ? dayjs(unixMilliseconds).utc().toDate()
                    : dayjs(unixMilliseconds).toDate();
            }
            // Handling C# Ticks format
            if (this.dateFormat === 'Ticks') {
                const ticks = Number(dateInput);
                if (isNaN(ticks))
                    return null;
                // Conversion of .NET ticks to milliseconds since Unix epoch
                const unixMilliseconds = (ticks - 621355968000000000) / 10000;
                return this.isUTCMode
                    ? dayjs(unixMilliseconds).utc().toDate()
                    : dayjs(unixMilliseconds).toDate();
            }
            // For all other formats, use customParseFormat in strict mode
            let parsed;
            if (this.isUTCMode) {
                parsed = dayjs.utc(dateInput, this.dateFormat, true);
            }
            else {
                parsed = dayjs(dateInput, this.dateFormat, true);
            }
            if (!parsed.isValid()) {
                console.error(`Parsing error:`, {
                    dateInput,
                    dateFormat: this.dateFormat,
                });
                return null;
            }
            return parsed.toDate();
        }
        /**
         * Checks if the date format is in UTC mode
         * @returns {boolean} true if the date format is in UTC mode
         */
        get isUTCMode() {
            return this.dateFormat.includes('Z');
        }
        /**
         * Checks if the date format is ISO 8601
         * @returns {boolean} true if the format is ISO 8601
         */
        get isISO8601Format() {
            return this.dateFormat === 'YYYY-MM-DD[T]HH:mm:ss[Z]';
        }
        /**
         * Formats a date to a string according to the format
         * @param {Date} date - Date to format
         * @returns {string} Formatted date
         */
        formatDate(date) {
            if (!date)
                return '';
            // Special case for ISO 8601
            if (this.isISO8601Format) {
                // For the ISO 8601 format, use directly toISOString() which is standard
                return date.toISOString();
            }
            // If the format is "Ticks", convert the time to C# ticks
            if (this.dateFormat === 'Ticks') {
                const ticks = date.getTime() * 10000 + 621355968000000000;
                return ticks.toString();
            }
            // If the format is "X" (Unix Seconds)
            if (this.dateFormat === 'X') {
                return dayjs(date).unix().toString();
            }
            // If the format is "x" (Unix Milliseconds)
            if (this.dateFormat === 'x') {
                return date.getTime().toString();
            }
            // Otherwise, format according to the mode (UTC or local)
            return this.isUTCMode
                ? dayjs(date).utc().format(this.dateFormat)
                : dayjs(date).format(this.dateFormat);
        }
        /**
         * Parse and cache the disabled dates
         * @description Parse and cache the disabled dates
         */
        parseDisabledDates() {
            if (!this.disabledDates) {
                this.parsedDisabledDates = [];
                return;
            }
            try {
                const disabledDatesArray = JSON.parse(this.disabledDates);
                this.parsedDisabledDates = disabledDatesArray
                    .map(date => this.parseDate(date))
                    .filter(date => date !== null);
            }
            catch (error) {
                console.error('Error parsing disabled dates:', error);
                this.parsedDisabledDates = [];
            }
        }
        /**
         * Checks if two dates are identical
         * @param {Date | null} date1 - First date
         * @param {Date | null} date2 - Second date
         * @returns {boolean} true if the dates are identical
         */
        isSameDate(date1, date2) {
            if (!date1 || !date2)
                return false;
            if (this.isUTCMode) {
                return (date1.getUTCFullYear() === date2.getUTCFullYear() &&
                    date1.getUTCMonth() === date2.getUTCMonth() &&
                    date1.getUTCDate() === date2.getUTCDate());
            }
            else {
                return (date1.getFullYear() === date2.getFullYear() &&
                    date1.getMonth() === date2.getMonth() &&
                    date1.getDate() === date2.getDate());
            }
        }
        /**
         * Checks if a date is identical or after another date
         * @param {Date} date - Date to check
         * @param {Date} compareDate - Reference date
         * @returns {boolean} true if `date` >= `compareDate`
         */
        isSameOrAfter(date, compareDate) {
            if (this.isUTCMode) {
                return (date.getUTCFullYear() > compareDate.getUTCFullYear() ||
                    (date.getUTCFullYear() === compareDate.getUTCFullYear() &&
                        date.getUTCMonth() > compareDate.getUTCMonth()) ||
                    (date.getUTCFullYear() === compareDate.getUTCFullYear() &&
                        date.getUTCMonth() === compareDate.getUTCMonth() &&
                        date.getUTCDate() >= compareDate.getUTCDate()));
            }
            else {
                return (date.getFullYear() > compareDate.getFullYear() ||
                    (date.getFullYear() === compareDate.getFullYear() &&
                        date.getMonth() > compareDate.getMonth()) ||
                    (date.getFullYear() === compareDate.getFullYear() &&
                        date.getMonth() === compareDate.getMonth() &&
                        date.getDate() >= compareDate.getDate()));
            }
        }
        /**
         * Checks if a date is identical or before another date
         * @param {Date} date - Date to check
         * @param {Date} compareDate - Reference date
         * @returns {boolean} true if `date` <= `compareDate`
         */
        isSameOrBefore(date, compareDate) {
            if (this.isUTCMode) {
                return (date.getUTCFullYear() < compareDate.getUTCFullYear() ||
                    (date.getUTCFullYear() === compareDate.getUTCFullYear() &&
                        date.getUTCMonth() < compareDate.getUTCMonth()) ||
                    (date.getUTCFullYear() === compareDate.getUTCFullYear() &&
                        date.getUTCMonth() === compareDate.getUTCMonth() &&
                        date.getUTCDate() <= compareDate.getUTCDate()));
            }
            else {
                return (date.getFullYear() < compareDate.getFullYear() ||
                    (date.getFullYear() === compareDate.getFullYear() &&
                        date.getMonth() < compareDate.getMonth()) ||
                    (date.getFullYear() === compareDate.getFullYear() &&
                        date.getMonth() === compareDate.getMonth() &&
                        date.getDate() <= compareDate.getDate()));
            }
        }
        /**
         * Applies a shortcut selection
         * @param {Object} shortcut - Shortcut to apply
         * @param {string | Date} shortcut.singleValue - Selected date value
         * @param {Object} shortcut.rangeValue - Start and end date values
         * @param {string | Date} shortcut.rangeValue.start - Start date value
         * @param {string | Date} shortcut.rangeValue.end - End date value
         * @param {string} shortcut.label - Label
         */
        applyShortcut(shortcut) {
            this.selectedDate = null;
            this.startDate = null;
            this.endDate = null;
            if (shortcut.singleValue) {
                const newDate = this.parseDate(shortcut.singleValue);
                this.selectedDate = newDate;
                this.singleDateChange.emit(this.formatDate(newDate));
                this.singleValue = this.formatDate(newDate);
                if (!this.showActions) {
                    const event = new CustomEvent('closePopover', {
                        bubbles: true,
                        composed: true,
                    });
                    this.el.dispatchEvent(event);
                }
                this.forceCalendarUpdate(newDate);
            }
            else {
                const start = this.parseDate(shortcut.rangeValue.start);
                const end = this.parseDate(shortcut.rangeValue.end);
                this.startDate = start;
                this.endDate = end;
                this.rangeDateChange.emit({
                    start: this.formatDate(start),
                    end: this.formatDate(end),
                });
                this.rangeValue = JSON.stringify({
                    start: this.formatDate(start),
                    end: this.formatDate(end),
                });
                if (!this.showActions) {
                    const event = new CustomEvent('closePopover', {
                        bubbles: true,
                        composed: true,
                    });
                    this.el.dispatchEvent(event);
                }
                this.forceCalendarUpdate(end);
            }
        }
        /**
         * Method to force the complete calendar update (and fix the persistent hover problem)
         * @param {Date} newDate - Date to force
         */
        forceCalendarUpdate(newDate) {
            this.currentDate = new Date(newDate);
            this.currentDate = new Date(this.currentDate); // Force a re-render
            // Reset visually the hover/touch effect
            requestAnimationFrame(() => {
                const days = document.querySelectorAll('.day');
                days.forEach(el => {
                    el.classList.remove('hover', 'active', 'touched');
                    el.style.pointerEvents = 'none';
                });
                // Add specific touch handling (for mobile)
                document.body.addEventListener('touchstart', this.clearTouchState, {
                    passive: true,
                });
                // Reset the touch state after 50ms
                setTimeout(() => {
                    days.forEach(el => {
                        el.style.pointerEvents = '';
                    });
                }, 50);
            });
        }
        /**
         * Function to reset the touch effect (Mobile fix)
         */
        clearTouchState() {
            document.querySelectorAll('.day').forEach(el => {
                el.classList.remove('touched');
            });
            // Remove the listener after the first interaction
            document.body.removeEventListener('touchstart', this.clearTouchState);
        }
        /**
         * Handles month change with an offset
         * @param {number} direction - Direction (-1 for previous, 1 for next)
         * @returns {Function} Change month handler
         */
        getChangeMonthHandler(direction) {
            return () => this.changeMonth(direction);
        }
        /**
         * Handles month change from an event (ex: dropdown)
         * @param {number} offset - Month offset (0 by default)
         * @returns {Function} Change month handler
         */
        getHandleMonthChange(offset) {
            return (event) => this.handleMonthChange(event, offset);
        }
        /**
         * Handles year change from an event (ex: dropdown)
         * @param {number} offset - Year offset (0 by default)
         * @returns {Function} Change year handler
         */
        getHandleYearChange(offset) {
            return (event) => this.handleYearChange(event, offset);
        }
        /**
         * Handles day click
         * @param {Date} date - Date to handle
         * @param {boolean} isDisabled - Whether the date is disabled
         * @returns {Function} Day click handler
         */
        getDayClickHandler(date, isDisabled) {
            return isDisabled ? undefined : () => this.handleDateSelection(date);
        }
        /**
         * Handles shortcut selection
         * @param {Object} shortcut - Shortcut to handle
         * @param {string | Date} shortcut.singleValue - Selected date value
         * @param {Object} shortcut.rangeValue - Start and end date values
         * @param {string | Date} shortcut.rangeValue.start - Start date value
         * @param {string | Date} shortcut.rangeValue.end - End date value
         * @param {string} shortcut.label - Label
         * @returns {Function} Shortcut selection handler
         */
        getShortcutHandler(shortcut) {
            return () => this.applyShortcut(shortcut);
        }
        /**
         * Handles week selection
         * @param {Date[]} dates - Dates to handle
         * @param {number} index - Calendar index
         * @returns {Function} Week selection handler
         */
        getWeekSelectionHandler(dates, index) {
            return () => {
                if (this.selectionType === 'range') {
                    this.handleWeekSelection(dates, index);
                }
            };
        }
        parsedShortcuts() {
            try {
                return this.shortcuts ? JSON.parse(this.shortcuts) : [];
            }
            catch (error) {
                console.error('Invalid JSON for shortcuts:', error);
                return [];
            }
        }
        /**
         * Checks if shortcuts are visible
         * @returns {boolean} true if shortcuts are visible
         */
        get hasShortcuts() {
            return (this.shortcutsPlacement === 'bottom' && this.parsedShortcuts().length > 0);
        }
        /**
         * Checks if actions are visible
         * @returns {boolean} true if actions are visible
         */
        get hasActions() {
            return this.showActions;
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region RENDER
        /**
         * Renders the header
         * @param {number} offset - Month offset
         * @param {number} index - Calendar index
         * @returns {JSX.Element} Header
         * @description Renders the header of the calendar
         */
        renderHeader(offset, index$1) {
            return (index.h("div", { class: "header" }, this.numberOfCalendars > 1 && index$1 === 0 && (index.h("nv-iconbutton", { class: "nav-left", emphasis: "lower", name: "chevron-left", onClick: this.getChangeMonthHandler(-1) })), index.h("div", { class: "date-controls" }, index.h("select", { class: "month-select mr-4", onChange: this.getHandleMonthChange(offset) }, this.months.map(month => (index.h("option", { key: month.value, value: month.value, selected: month.value === (this.currentDate.getUTCMonth() + offset) % 12 }, month.label)))), index.h("input", { type: "number", class: "year-input", min: "1950", max: "2100", value: this.currentDate.getUTCFullYear() +
                    Math.floor((this.currentDate.getUTCMonth() + offset) / 12), onChange: this.getHandleYearChange(offset) })), this.numberOfCalendars === 1 && (index.h("div", { class: "nav-buttons" }, index.h("nv-iconbutton", { emphasis: "lower", name: "chevron-left", onClick: this.getChangeMonthHandler(-1) }), index.h("nv-iconbutton", { emphasis: "lower", name: "chevron-right", onClick: this.getChangeMonthHandler(1) }))), this.numberOfCalendars > 1 && index$1 === this.numberOfCalendars - 1 && (index.h("nv-iconbutton", { emphasis: "lower", name: "chevron-right", onClick: this.getChangeMonthHandler(1), class: "nav-right" }))));
        }
        /**
         * Renders the week numbers
         * @param {Array<{date: Date}>} weeks - Weeks to render
         * @param {number} index - Calendar index
         * @returns {JSX.Element} Week numbers
         * @description Renders the week numbers of the calendar
         */
        renderWeekNumbers(
        /** Weeks to render */
        weeks, 
        /** Calendar index */
        index$1) {
            return (index.h("div", { class: "week-numbers" }, index.h("div", { class: "week-header" }, this.getLocalizedWeekText()), weeks.map((week, weekIndex) => {
                var _a;
                const dates = week.map(d => d.date);
                return (index.h("div", { class: `week-number ${this.selectionType === 'range' ? 'clickable' : ''}`, onClick: this.getWeekSelectionHandler(dates, index$1), key: `week-${weekIndex}` }, this.getWeekNumber(((_a = week.find(d => d.date)) === null || _a === void 0 ? void 0 : _a.date) || new Date())));
            })));
        }
        renderDaysGrid(
        /** Days to render */
        days) {
            return (index.h("div", { class: "days-grid" }, days.map(day => {
                const date = day.date;
                if (!date)
                    return null;
                const isSelected = this.selectionType === 'single' &&
                    this.isSameDate(date, this.selectedDate);
                const isInRange = this.isDateInRange(date);
                const isStart = this.isSameDate(date, this.startDate);
                const isEnd = this.isSameDate(date, this.endDate);
                const isToday = this.isToday(date);
                const isOutsideMonth = !day.isCurrentMonth;
                const dayClasses = [
                    'day',
                    isSelected ? 'selected' : '',
                    isStart ? 'range-start' : '',
                    isEnd ? 'range-end' : '',
                    isInRange ? 'in-range' : '',
                    day.isDisabled ? 'disabled' : '',
                    isOutsideMonth ? 'outside-month' : '',
                    isToday ? 'is-today' : '',
                ];
                return (index.h("div", { class: dayClasses.filter(Boolean).join(' '), onClick: this.getDayClickHandler(date, day.isDisabled), "aria-disabled": day.isDisabled, key: `day-${date.toISOString()}` }, day.dayOfMonth));
            })));
        }
        /**
         * Renders the calendar
         * @param {number} index - Calendar index
         * @param {number} offset - Month offset
         * @returns {JSX.Element} Calendar
         * @description Renders the calendar of the calendar
         */
        renderCalendar(
        /** Calendar index */
        index$1, 
        /** Month offset */
        offset) {
            const days = this.getDaysInMonth(offset, this.numberOfCalendars);
            const weeks = [];
            for (let i = 0; i < days.length; i += 7) {
                weeks.push(days.slice(i, i + 7));
            }
            return (index.h("div", { class: "calendar-wrapper" }, index.h("div", { class: "calendar-container", key: `calendar-${index$1}` }, this.renderHeader(offset, index$1), index.h("div", { class: "calendar-grid" }, this.showWeekNumbers && this.renderWeekNumbers(weeks, index$1), index.h("div", { class: "days-container" }, index.h("div", { class: "days-header" }, this.getDayNames().map(day => (index.h("div", { class: "day-header" }, day)))), this.renderDaysGrid(days)))), index$1 < this.numberOfCalendars - 1 && (index.h("div", { class: "calendar-separator" }))));
        }
        /**
         * Renders the shortcuts
         * @returns {JSX.Element} Shortcuts
         * @description Renders the shortcuts of the calendar
         */
        renderShortcuts() {
            if (!this.parsedShortcuts().length) {
                return null;
            }
            return (index.h("div", { class: `shortcuts-container shortcuts-placement-${this.shortcutsPlacement}` }, this.parsedShortcuts().map(shortcut => (index.h("nv-button", { emphasis: "lower", size: "xs", "aria-label": shortcut.label, onClick: this.getShortcutHandler(shortcut) }, shortcut.label)))));
        }
        /**
         * Renders the actions
         * @returns {JSX.Element} Actions
         * @description Renders the actions of the calendar
         * @slot actions - Child content of the component.
         */
        renderActions() {
            return (index.h("div", { class: "datepicker-actions" }, index.h("slot", { name: "actions" }, index.h("nv-button", { emphasis: "low", size: "xs", onClick: this.resetSelection }, "Cancel"), index.h("nv-button", { size: "xs", onClick: this.confirmSelection }, "OK"))));
        }
        /**
         * Renders the datepicker
         * @returns {JSX.Element} Datepicker
         * @description Renders the datepicker of the calendar
         * @slot default - Child content of the component.
         */
        render() {
            return (index.h(index.Host, { key: '89300da9f694aa926855452414e7e036f75f2de6' }, index.h("div", { key: '467ef9fc9d6523eec3712bf779d49fdf50c55617', class: "datepicker-root" }, index.h("div", { key: '990f2cb18dcad96cab0f8dfb62e6c57049475440', class: `datepicker-container ${this.numberOfCalendars === 1 ? 'datepicker-container-single' : ''}` }, index.h("div", { key: 'c0dedf1007cbc6a87bd591925c9994474c876afc', class: `datepicker-wrapper ${this.numberOfCalendars === 1 ? 'single' : ''}` }, this.shortcutsPlacement === 'left' && this.renderShortcuts(), Array.from({ length: this.numberOfCalendars }, (_, index) => this.renderCalendar(index, index)), this.shortcutsPlacement === 'right' && this.renderShortcuts()), (this.hasShortcuts || this.hasActions) && (index.h("div", { key: 'ef81eaf952fbe569be7e1d3ee6cb59de0e137fe4', class: "datepicker-controls" }, this.hasShortcuts && this.renderShortcuts(), this.hasActions && this.renderActions())))), index.h("slot", { key: 'e1281217950b5cb02952a69b081d4fcce5863b4d' })));
        }
        get el() { return index.getElement(this); }
        static get watchers() { return {
            "numberOfCalendars": ["validateNumberOfCalendars"],
            "rangeValue": ["onRangeValueChange"],
            "disabledDates": ["handleDisabledDatesChange"],
            "singleValue": ["onSingleValueChange"]
        }; }
    };
    NvCalendar.style = NvCalendarStyle0;

    exports.nv_calendar = NvCalendar;

}));
