sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/v4-a79185f4'], (function (exports, index, v4A79185f4) { 'use strict';

    const nvFieldtextCss = "nv-fieldtext{--nv-field-border-default:var(--components-form-field-border-default);--nv-field-border-hover:var(--components-form-field-border-hover);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--components-form-field-border-default);--nv-field-border-readonly:var(--components-form-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-brand);--nv-field-background:var(--components-form-field-background-default);display:flex;flex-direction:column;align-items:flex-start;gap:var(--form-gap-y);box-sizing:border-box}nv-fieldtext[readonly]:not([readonly=false]){--nv-field-border-default:var(--components-form-field-border-readonly);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-background:var(--components-form-field-background-readonly)}nv-fieldtext[error]:not([error=false]){--nv-field-border-default:var(--components-form-field-border-error);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--nv-field-border-default);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-destructive)}nv-fieldtext[success]:not([success=false]){--nv-field-border-default:var(--components-form-field-border-success);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--nv-field-border-default);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-success)}nv-fieldtext[required]:not([required=false]) label::after{content:\"*\";color:var(--components-form-text-required);font-weight:700}nv-fieldtext>label{display:flex;align-items:center;gap:var(--form-label-gap);align-self:stretch;color:var(--components-form-text-label-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-label-font-size);font-style:normal;font-weight:500;line-height:var(--form-label-line-height)}nv-fieldtext>.input-wrapper{display:flex;flex-wrap:wrap;gap:var(--form-gap-x);align-items:stretch;align-self:stretch}nv-fieldtext>.input-wrapper .input-container{display:flex;flex-grow:1;justify-content:center;align-items:center;align-self:stretch;border-radius:var(--form-field-radius);border-width:1px;border-style:solid;border-color:var(--nv-field-border-default);opacity:var(--components-form-opacity-default, 1);background:var(--nv-field-background);transition:all 150ms ease-out}nv-fieldtext>.input-wrapper .input-container:hover{border-color:var(--nv-field-border-hover)}nv-fieldtext>.input-wrapper .input-container:focus-within,nv-fieldtext>.input-wrapper .input-container:focus-within:hover,nv-fieldtext>.input-wrapper .input-container:focus,nv-fieldtext>.input-wrapper .input-container:focus:hover{border-color:var(--nv-field-border-focus);box-shadow:0px 0px 0px var(--focus-field-stroke) var(--nv-field-focus-box-shadow)}nv-fieldtext>.input-wrapper .input-container:has(input:read-only){opacity:0.5;background-color:var(--components-form-field-background-readonly);border-color:var(--nv-field-border-readonly)}nv-fieldtext>.input-wrapper .input-container:has(input:disabled){opacity:0.5;background-color:var(--components-form-field-background-disabled);border-color:var(--nv-field-border-disabled)}nv-fieldtext>.input-wrapper .input-container input{display:flex;align-items:center;flex:1 0 0;overflow:hidden;background-color:transparent;color:var(--components-form-field-content-text);padding:var(--form-field-padding-y) var(--form-field-padding-x);font-size:var(--form-field-font-size);font-style:normal;font-weight:500;line-height:var(--form-field-line-height)}nv-fieldtext>.input-wrapper .input-container input:focus{outline:none}nv-fieldtext>.input-wrapper .input-container input::placeholder{overflow:hidden;color:var(--components-form-field-content-placeholder);text-overflow:ellipsis;font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-field-font-size);font-style:normal;font-weight:400;line-height:var(--form-field-line-height)}nv-fieldtext>.input-wrapper .input-container nv-icon.validation{color:var(--nv-field-border-default);margin-right:var(--form-gap-x)}nv-fieldtext>.description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;line-height:var(--form-description-line-height)}nv-fieldtext>.error-description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;line-height:var(--form-description-line-height);color:var(--components-form-text-description-error)}";
    const NvFieldtextStyle0 = nvFieldtextCss;

    const NvFieldtext = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.valueChanged = index.createEvent(this, "valueChanged");
            //#endregion DEPRECATED
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Sets the ID for the input element and the for attribute of the associated
             * label. If no ID is provided, a random one will be automatically generated
             * to ensure unique identification, facilitating proper label association and
             * accessibility.
             */
            this.inputId = v4A79185f4.v4();
            /**
             * The type prop lets you specify what kind of information the input field
             * should accept. Choose 'text' for general words or sentences, 'tel' for
             * phone numbers, or 'email' for email addresses. This makes sure users get
             * the right keyboard and validation for what they need to enter.
             */
            this.type = 'text';
            /**
             * The disabled prop lets you turn off the input field so that users can’t
             * type in it. When disabled, the field is grayed out and won’t respond to
             * clicks or touches.
             */
            this.disabled = false;
            /**
             * Display the input field’s content without allowing users to change it.
             * Users can still click on it, select, and copy the text, but they won’t be
             * able to type or delete anything.
             */
            this.readonly = false;
            /**
             * Marks the input field as required, ensuring that the user must fill it out
             * before submitting the form.
             */
            this.required = false;
            /**
             * Alters the input field’s appearance to indicate an error, helping users
             * identify fields that need correction.
             * @validator error
             */
            this.error = false;
            /**
             * Changes the input field’s appearance to indicate successful input or
             * validation.
             */
            this.success = false;
            /**
             * When used with the email input type, this prop enables the field to accept
             * multiple email addresses. Users can enter several addresses, separating
             * each one with a comma, allowing the form to handle multiple recipients.
             */
            this.multiple = false;
            /**
             * Applies focus to the input field as soon as the component is mounted. This
             * is equivalent to setting the native autofocus attribute on an <input>
             * element.
             */
            this.autofocus = false;
            //#endregion EVENTS
            /****************************************************************************/
            //#region METHODS
            /**
             * Handles the input event on the input element.
             * Emits the inputChanged event with the new value.
             * @param {Event} event - Event object of the input event.
             */
            this.handleInput = (event) => {
                const input = event.target;
                this.value = input.value;
                this.valueChanged.emit(input.value);
            };
            /**
             * Handles focus when the input container is clicked.
             */
            this.handleInputContainerClick = () => {
                this.inputElement.focus();
            };
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillRender() {
            if (this.textInputType) {
                this.type = this.textInputType;
            }
            if (this.message) {
                this.description = this.message;
            }
            if (this.validation) {
                this.errorDescription = this.validation;
                this.error = true;
            }
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: 'e4891525becd4b0757ec380d45d9694ebc6c3318' }, (this.label || this.el.querySelector('[slot="label"]')) && (index.h("label", { key: '1157e609be8150d014e9190dcf53f74bcee20119', htmlFor: this.inputId }, index.h("slot", { key: '888fb12e994f6f4f47bc2be496cd74aeedb628c0', name: "label" }, this.label))), index.h("div", { key: '0555b12dbbe5fa81f5af464d3b48c35b243aec32', class: "input-wrapper" }, index.h("slot", { key: '5210a9b903c560775453741d8815286dbe8bbb53', name: "before-input" }), index.h("div", { key: '7bc11232dfa46706982bf3645054a7a1f67832f9', class: "input-container", onClick: this.handleInputContainerClick }, index.h("slot", { key: '87abc6976b432a3dc51246c97564108f9baccff8', name: "leading-input" }), index.h("input", { key: 'b0c3e30bc5363f6b49ea1361005e125826184016', id: this.inputId, ref: e => (this.inputElement = e), placeholder: this.placeholder, name: this.name, type: this.type, disabled: this.disabled, readOnly: this.readonly, required: this.required, maxlength: this.maxlength, minlength: this.minlength, pattern: this.pattern, autofocus: this.autofocus, autocomplete: this.autocomplete, multiple: this.multiple, value: this.value, onInput: this.handleInput }), this.error && (index.h("nv-icon", { key: '5e359bc40906bbf2c63eb7d196dd8294b15dd672', name: "alert-circle", class: "validation", size: "md" })), this.success && (index.h("nv-icon", { key: '4812b31e512bf388fa84f9d35a949de5f9b86d59', name: "circle-check", class: "validation", size: "md" }))), index.h("slot", { key: '06922c63f02470be6c74ee6ba4bf93baabd03e57', name: "after-input" })), (this.description ||
                this.el.querySelector('[slot="description"]')) && (index.h("div", { key: '960bcb53a55aed3e1b8cd1b193ad26f5c6b151fd', class: "description" }, index.h("slot", { key: '07c09b8543e9b91928821a100869943de94a65a7', name: "description" }, this.description))), (this.errorDescription ||
                this.el.querySelector('[slot="error-description"]')) && (index.h("div", { key: '456d00a47f01f70938d99faa774da1a9e51b036d', hidden: !this.error, class: "error-description" }, index.h("slot", { key: '590aef8c37efd2fa472c9b7b92fd82d29c4e6d39', name: "error-description" }, this.errorDescription)))));
        }
        static get formAssociated() { return true; }
        get el() { return index.getElement(this); }
    };
    NvFieldtext.style = NvFieldtextStyle0;

    exports.nv_fieldtext = NvFieldtext;

}));
