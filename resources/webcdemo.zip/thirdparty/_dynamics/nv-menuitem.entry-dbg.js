sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2'], (function (exports, index) { 'use strict';

    const nvMenuitemCss = "nv-menuitem{display:flex;align-items:center;max-width:300px;width:100vw;font-size:var(--menu-contextual-item-font-size);font-weight:var(--menu-contextual-item-font-weight);color:var(--components-menu-contextual-item-content);border-radius:var(--menu-contextual-item-radius);gap:var(--menu-contextual-item-gap-x);padding:var(--menu-contextual-item-padding-y) var(--menu-contextual-item-padding-x);transition:background-color 150ms ease-out;cursor:pointer}nv-menuitem:hover,nv-menuitem:focus,nv-menuitem:focus-within{background-color:var(--components-menu-contextual-item-background-hover);color:var(--components-menu-contextual-item-content-hover)}nv-menuitem *{pointer-events:none}nv-menuitem kbd{color:var(--components-menu-contextual-item-shortcut)}nv-menuitem [data-scope=text]{margin-right:auto}nv-menuitem[disabled]:not([disabled=false]){cursor:unset;background-color:unset;color:var(--components-menu-contextual-item-content-disabled)}";
    const NvMenuitemStyle0 = nvMenuitemCss;

    const NvMenuitem = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.menuitemSelected = index.createEvent(this, "menuitemSelected");
            /**
             * Disables the item, preventing user interaction.
             */
            this.disabled = false;
            /**
             * If the menu item has a submenu, the a caret icon will be displayed.
             */
            this.hasSubmenu = false;
        }
        handleMenuItemSelect(event) {
            // If the element is disabled, stop propagation
            if (this.disabled) {
                event.stopPropagation();
                return;
            }
            this.menuitemSelected.emit({
                id: this.el.id,
                name: this.name,
                hasSubmenu: this.hasSubmenu,
            });
        }
        handleClick(event) {
            this.handleMenuItemSelect(event);
        }
        handleKeyDown(event) {
            if (event.key === 'Enter' || event.key === ' ') {
                const activeElement = document.activeElement;
                if (activeElement &&
                    activeElement.tagName === 'NV-MENUITEM' &&
                    !activeElement.hasAttribute('has-submenu')) {
                    event.preventDefault();
                    this.el.click();
                }
            }
        }
        //#endregion EVENTS
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: 'd736bc00759cb97fe52d2d6dc091667057a5585c', role: "menuitem", tabindex: this.disabled ? '-1' : '0' }, this.icon && index.h("nv-icon", { key: 'cf29c75feedcb61d16d33433f834751c821a4256', name: this.icon }), index.h("slot", { key: '0ebe8b2faac9981023c224e3c5cd4f131e088c0e' }), this.label && index.h("span", { key: 'd2659aceb0ecc1cad794ae16d15432379677012c', "data-scope": "text" }, this.label), this.shortcut && !this.hasSubmenu && index.h("kbd", { key: '7d7772b6efda6faccafc425772c905d4aabd2ef5' }, this.shortcut), this.hasSubmenu && index.h("nv-icon", { key: 'c756d3ceffc907fa0c37338595a7fd09f8238a7b', name: "chevron-right" })));
        }
        get el() { return index.getElement(this); }
    };
    NvMenuitem.style = NvMenuitemStyle0;

    exports.nv_menuitem = NvMenuitem;

}));
