sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/constants-98e2dcc2'], (function (exports, index, constants98e2dcc2) { 'use strict';

    const nvDialogfooterCss = "nv-dialogfooter{display:flex;padding:var(--dialog-footer-padding-top) var(--dialog-footer-padding-x) var(--dialog-footer-padding-bottom) var(--dialog-footer-padding-x);justify-content:flex-end;align-items:flex-end;gap:var(--dialog-footer-gap-y);align-self:stretch}";
    const NvDialogfooterStyle0 = nvDialogfooterCss;

    const NvDialogfooter = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.dialogCanceled = index.createEvent(this, "dialogCanceled");
            this.dialogPrimaryClicked = index.createEvent(this, "dialogPrimaryClicked");
            if (hostRef.$hostElement$["s-ei"]) {
                this.internals = hostRef.$hostElement$["s-ei"];
            }
            else {
                this.internals = hostRef.$hostElement$.attachInternals();
                hostRef.$hostElement$["s-ei"] = this.internals;
            }
            this.hasSlot = false;
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Disables the primary button, preventing user interaction.
             */
            this.disabled = false;
            /**
             * Controls the visibility of the cancel button. When true, the cancel button is
             * hidden.
             */
            this.undismissable = false;
            /**
             * Sets the leading icon for the primary button.
             */
            this.leadingIcon = '';
            /**
             * Sets the trailing icon for the primary button.
             */
            this.trailingIcon = '';
            /**
             * Sets the danger state for the primary button.
             */
            this.danger = false;
            /**
             * Sets the label for the cancel button.
             */
            this.cancelLabel = 'Cancel';
            /**
             * Sets the label for the primary button.
             */
            this.primaryLabel = 'Primary';
            /**
             * Sets the type of the primary button.
             */
            this.primaryButtonType = constants98e2dcc2.ButtonType.Button;
            //#endregion EVENTS
            /****************************************************************************/
            //#region METHODS
            /**
             * Handles the primary action when the primary button is clicked.
             * @param {Event} event - The click event.
             */
            this.handlePrimary = (event) => {
                event.stopPropagation();
                this.dialogPrimaryClicked.emit();
            };
            /**
             * Handles the cancel action when the cancel button is clicked. This will close the dialog.
             * @param {Event} event - The click event.
             */
            this.handleCancel = (event) => {
                event.stopPropagation();
                this.dialogCanceled.emit();
            };
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillLoad() {
            // Check if there are any child elements that don't have a slot attribute
            this.hasSlot = Array.from(this.el.childNodes).some(node => {
                return (node.nodeType === Node.ELEMENT_NODE &&
                    !node.hasAttribute('slot'));
            });
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '5756a0cc697188c3fdee2930b1c6ae7922af71cc' }, !this.hasSlot ? (index.h(index.Fragment, null, !this.undismissable && (index.h("nv-button", { onClick: this.handleCancel, emphasis: "low", size: "sm" }, this.cancelLabel)), index.h("nv-button", { onClick: this.handlePrimary, disabled: this.disabled, danger: this.danger, size: "sm", emphasis: "high", form: this.form, type: this.primaryButtonType }, this.leadingIcon && (index.h("nv-icon", { slot: "leading-icon", name: this.leadingIcon, size: "sm" })), this.primaryLabel, this.trailingIcon && (index.h("nv-icon", { slot: "trailing-icon", name: this.trailingIcon, size: "sm" }))))) : (index.h("slot", null))));
        }
        static get formAssociated() { return true; }
        get el() { return index.getElement(this); }
    };
    NvDialogfooter.style = NvDialogfooterStyle0;

    const nvDialogheaderCss = "nv-dialogheader{padding:var(--dialog-header-padding-top) var(--dialog-header-padding-x) var(--dialog-header-padding-bottom) var(--dialog-header-padding-x);justify-content:space-between;align-items:flex-start;align-self:stretch}nv-dialogheader .heading{color:var(--color-content-high-text);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--font-size-lg);font-style:normal;font-weight:500;line-height:var(--leading-px-6);letter-spacing:var(--letter-spacing-heading-xs)}nv-dialogheader .subheading{color:var(--color-content-low-text);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--font-size-sm);font-style:normal;font-weight:400;line-height:var(--line-height-sm);}";
    const NvDialogheaderStyle0 = nvDialogheaderCss;

    const NvDialogheader = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.hasSlot = false;
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Sets the heading text for the dialog.
             */
            this.heading = 'Dialog Title';
        }
        //#endregion PROPERTIES
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillLoad() {
            // Check if there are any child elements that don't have a slot attribute
            this.hasSlot = Array.from(this.el.childNodes).some(node => {
                return (node.nodeType === Node.ELEMENT_NODE &&
                    !node.hasAttribute('slot'));
            });
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '850e2408cb7a35903be3bc51fbee000fc58f4a76' }, !this.hasSlot ? (index.h(index.Fragment, null, index.h("div", { class: "heading" }, this.heading), index.h("div", { class: "subheading" }, this.subheading))) : (index.h("slot", null))));
        }
        get el() { return index.getElement(this); }
    };
    NvDialogheader.style = NvDialogheaderStyle0;

    exports.nv_dialogfooter = NvDialogfooter;
    exports.nv_dialogheader = NvDialogheader;

}));
