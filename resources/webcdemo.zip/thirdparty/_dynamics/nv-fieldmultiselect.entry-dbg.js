sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/v4-a79185f4'], (function (exports, index, v4A79185f4) { 'use strict';

    const nvFieldmultiselectCss = "nv-fieldmultiselect{--nv-field-border-default:var(--components-form-field-border-default);--nv-field-border-hover:var(--components-form-field-border-hover);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--components-form-field-border-default);--nv-field-border-readonly:var(--components-form-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-brand);--nv-field-background:var(--components-form-field-background-default);display:flex;flex-direction:column;align-items:flex-start;gap:var(--form-gap-y);box-sizing:border-box}nv-fieldmultiselect[readonly]:not([readonly=false]){--nv-field-border-default:var(--components-form-field-border-readonly);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-background:var(--components-form-field-background-readonly)}nv-fieldmultiselect[error]:not([error=false]){--nv-field-border-default:var(--components-form-field-border-error);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--nv-field-border-default);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-destructive)}nv-fieldmultiselect[required]:not([required=false])>label::after{content:\"*\";color:var(--components-form-text-required);font-weight:700}nv-fieldmultiselect label{display:flex;align-items:center;gap:var(--form-label-gap);align-self:stretch;color:var(--components-form-text-label-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-label-font-size);font-style:normal;font-weight:500;line-height:var(--form-label-line-height)}nv-fieldmultiselect nv-popover{width:100%;display:block}nv-fieldmultiselect nv-popover [data-scope=popover]{width:100%;padding:var(--list-dropdown-padding);border-radius:var(--list-dropdown-radius);background-color:var(--components-list-dropdown-background);border:1px solid var(--components-list-dropdown-border)}nv-fieldmultiselect nv-popover [slot=content]{gap:var(--list-dropdown-gap-y);display:flex;flex-direction:column}nv-fieldmultiselect nv-popover hr{color:var(--components-list-dropdown-separator)}nv-fieldmultiselect .input-wrapper-multiselect{display:flex;flex-wrap:wrap;gap:var(--form-gap-x);align-items:stretch;align-self:stretch;width:100%}nv-fieldmultiselect .input-container-multiselect{display:flex;flex-grow:1;justify-content:center;align-items:center;align-self:stretch;border-radius:var(--form-field-radius);border-width:1px;border-style:solid;border-color:var(--nv-field-border-default);opacity:var(--components-form-opacity-default, 1);background:var(--nv-field-background);transition:all 150ms ease-out;position:relative;width:100%;min-height:40px;}nv-fieldmultiselect .input-container-multiselect:hover{border-color:var(--nv-field-border-hover)}nv-fieldmultiselect .input-container-multiselect:focus-within,nv-fieldmultiselect .input-container-multiselect:focus-within:hover,nv-fieldmultiselect .input-container-multiselect:focus,nv-fieldmultiselect .input-container-multiselect:focus:hover{border-color:var(--nv-field-border-focus);box-shadow:0px 0px 0px var(--focus-field-stroke) var(--nv-field-focus-box-shadow)}nv-fieldmultiselect .input-container-multiselect:has(input:read-only){opacity:0.5;background-color:var(--components-form-field-background-readonly);border-color:var(--nv-field-border-readonly)}nv-fieldmultiselect .input-container-multiselect:has(input:disabled){opacity:0.5;background-color:var(--components-form-field-background-disabled);border-color:var(--nv-field-border-disabled)}nv-fieldmultiselect .input-container-multiselect>nv-badge{margin-left:var(--form-field-padding-x)}nv-fieldmultiselect .input-container-multiselect input,nv-fieldmultiselect .input-container-multiselect p.non-filterable-text{display:flex;align-items:center;flex:1 0 0;overflow:hidden;background-color:transparent;color:var(--components-form-field-content-text);padding:var(--form-field-padding-y) var(--form-field-padding-x);font-size:var(--form-field-font-size);font-style:normal;font-weight:500;line-height:var(--form-field-line-height);width:100%;flex-grow:1;margin:0;min-height:100%;box-sizing:border-box}nv-fieldmultiselect .input-container-multiselect input:focus,nv-fieldmultiselect .input-container-multiselect p.non-filterable-text:focus{outline:none}nv-fieldmultiselect .input-container-multiselect input::placeholder,nv-fieldmultiselect .input-container-multiselect p.non-filterable-text::placeholder{overflow:hidden;color:var(--components-form-field-content-placeholder);text-overflow:ellipsis;font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-field-font-size);font-style:normal;font-weight:400;line-height:var(--form-field-line-height)}nv-fieldmultiselect .input-container-multiselect>nv-iconbutton{border:0px;border-radius:0px}nv-fieldmultiselect .input-container-multiselect>nv-iconbutton:focus-visible{border-radius:var(--button-md-border-radius);outline-offset:-3px}nv-fieldmultiselect .input-container-multiselect nv-icon.validation{color:var(--nv-field-border-default)}nv-fieldmultiselect .non-filterable-text{display:block;border-radius:var(--form-field-radius);background-color:var(--nv-field-background);color:var(--components-form-field-content-text);font-size:var(--form-field-font-size);font-weight:500;line-height:var(--form-field-line-height);box-sizing:border-box;cursor:pointer;height:100%;min-height:40px}nv-fieldmultiselect .non-filterable-text span{display:inline-block;width:100%;overflow:hidden;text-overflow:ellipsis}nv-fieldmultiselect .description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;line-height:var(--form-description-line-height)}nv-fieldmultiselect .error-description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;line-height:var(--form-description-line-height);color:var(--components-form-text-description-error)}.no-results-message{text-align:center;padding:10px;color:var(--components-form-text-description-error)}.multiselect-divider{display:block;width:100%;height:1px;background-color:var(--components-list-dropdown-separator);margin:var(--list-dropdown-item-padding-y) 0;border:0}";
    const NvFieldmultiselectStyle0 = nvFieldmultiselectCss;

    const NvFieldmultiselect = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.valueChanged = index.createEvent(this, "valueChanged");
            this.multiselectChange = index.createEvent(this, "multiselectChange");
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Sets the ID for the input element and the for attribute of the associated
             * label. If no ID is provided, a random one will be automatically generated
             * to ensure unique identification, facilitating proper label association and
             * accessibility.
             */
            this.inputId = v4A79185f4.v4();
            /**
             * Defines the maximum height of the multiselect list when open.
             */
            this.maxHeight = '200px';
            /**
             * Text for the badge showing the number of selected items.
             */
            this.badgeLabel = '';
            /**
             * The text to display when no items match the filter.
             */
            this.emptyResult = 'No results found';
            /**
             * Marks the input field as required.
             */
            this.required = false;
            /**
             * Alters the input field's appearance to indicate an error, helping users
             * identify fields that need correction.
             * @validator error
             */
            this.error = false;
            /**
             * Display the input field's content without allowing users to change it.
             */
            this.readonly = false;
            /**
             * Disables the input field.
             */
            this.disabled = false;
            /**
             * The autocomplete prop for faster input filling.
             */
            this.autocomplete = 'off';
            /**
             * Enables or disables the filtering feature for the multiselect items.
             */
            this.filterable = false;
            /**
             * State of the multiselect popover.
             */
            this.open = false;
            /**
             * List of selected values in the multiselect.
             */
            this.selectedValues = [];
            /**
             * Sorted options for display.
             */
            this.sortedOptions = [];
            /**
             * The text entered by the user for filtering multiselect items.
             */
            this.filterText = '';
            /**
             * Delay in milliseconds before the search is triggered when typing in the filter input.
             * @default 300
             */
            this.debounceDelay = 300;
            this.isHandlingEscape = false;
            /**
             * Applies focus to the input field as soon as the component is mounted. This
             * is equivalent to setting the native autofocus attribute on an <input>
             * element.
             */
            this.autofocus = false;
            /**
             * Handle badge close for options mode.
             */
            this.handleBadgeCloseOptions = () => {
                this.selectedValues = [];
                this.multiselectChange.emit(this.selectedValues);
                // Uncheck all elements
                const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitemcheck'));
                items.forEach(item => {
                    item.checked = false;
                    item.style.display = '';
                });
                // Reorder options without the divider since there are no selected elements
                this.options = this.options.filter(option => !option.isDivider);
                // Reorder options without the divider since there are no selected elements
                this.reorderOptionsContent();
            };
            /**
             * Handle badge close for slots mode.
             */
            this.handleBadgeCloseSlots = () => {
                this.selectedValues = [];
                this.multiselectChange.emit(this.selectedValues);
                // Uncheck all elements
                const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitemcheck'));
                items.forEach(item => {
                    item.checked = false;
                    item.style.display = '';
                });
                // Reorder slot content
                this.reorderSlotContent();
            };
            /**
             * Handle popover close
             */
            this.handlePopoverClose = () => {
                // If we are handling Escape, ignore this event
                if (this.isHandlingEscape) {
                    return;
                }
                this.filterText = '';
                // Reset filter if needed
                if (this.filterable) {
                    this.resetFilter();
                }
            };
            /**
             * Handle input blur for options mode.
             */
            this.handleInputBlurOptions = () => {
                setTimeout(() => {
                    if (!this.el.contains(document.activeElement)) {
                        // Close the popover without affecting the divider
                        this.open = false;
                        // Reset filter if needed
                        if (this.filterable) {
                            this.filterText = '';
                            this.resetFilter();
                        }
                    }
                }, 150);
            };
            /**
             * Handle click on the input container for options mode.
             * @param {MouseEvent} event - The click event.
             */
            this.handleInputContainerClickOptions = (event) => {
                if (this.disabled || this.readonly) {
                    return;
                }
                const target = event.target;
                if (target.tagName === 'P' || target.tagName === 'SPAN') {
                    this.open = true;
                    const inputContainer = this.el.querySelector('.input-container');
                    if (inputContainer) {
                        inputContainer.classList.add('focus-within');
                        const removeFocusWithin = () => {
                            inputContainer.classList.remove('focus-within');
                        };
                        this.popoverElement.addEventListener('hide', removeFocusWithin);
                    }
                }
            };
            /**
             * Handle click on the input container for slots mode.
             * @param {MouseEvent} event - The click event.
             */
            this.handleInputContainerClickSlots = (event) => {
                if (this.disabled || this.readonly) {
                    return;
                }
                const target = event.target;
                if (target.tagName === 'P' || target.tagName === 'SPAN') {
                    this.open = true;
                    const inputContainer = this.el.querySelector('.input-container');
                    if (inputContainer) {
                        inputContainer.classList.add('focus-within');
                        const removeFocusWithin = () => {
                            inputContainer.classList.remove('focus-within');
                        };
                        this.popoverElement.addEventListener('hide', removeFocusWithin);
                    }
                }
            };
            /**
             * Handle input change for options mode.
             * @param {Event} event - The input event.
             */
            this.handleInputOptions = (event) => {
                if (!this.filterable)
                    return;
                if (this.disabled || this.readonly) {
                    return;
                }
                const input = event.target;
                this.value = input.value;
                this.valueChanged.emit(this.value);
                // Clear any existing timer
                if (this.debounceTimer) {
                    window.clearTimeout(this.debounceTimer);
                }
                // Set a new timer for filtering
                this.debounceTimer = window.setTimeout(() => {
                    this.filterText = input.value.toLowerCase();
                    this.filterItemsOption();
                }, this.debounceDelay);
            };
            /**
             * Handle input change for slots mode
             * @param {Event} event - The input event.
             */
            this.handleInputSlots = (event) => {
                if (!this.filterable)
                    return;
                if (this.disabled || this.readonly)
                    return;
                const input = event.target;
                this.value = input.value;
                this.valueChanged.emit(this.value);
                // Clear any existing timer
                if (this.debounceTimer) {
                    window.clearTimeout(this.debounceTimer);
                }
                // Set a new timer for filtering
                this.debounceTimer = window.setTimeout(() => {
                    this.filterText = input.value.toLowerCase();
                    this.filterSlotsItems();
                }, this.debounceDelay);
            };
            /**
             * Handle input focus for options mode.
             */
            this.handleInputFocusOptions = () => {
                if (this.disabled || this.readonly) {
                    return;
                }
                this.open = true;
            };
            /**
             * Handle input focus for slots mode.
             */
            this.handleInputFocusSlots = () => {
                if (this.disabled || this.readonly) {
                    return;
                }
                this.open = true;
            };
            /**
             * Handle input blur for slots mode.
             */
            this.handleInputBlurSlots = () => {
                setTimeout(() => {
                    if (!this.el.contains(document.activeElement)) {
                        // Close the popover without affecting the divider
                        this.open = false;
                        // Reset filter if needed
                        if (this.filterable) {
                            this.filterText = '';
                            this.resetFilter();
                        }
                    }
                }, 150);
            };
            /**
             * Toggle the multiselect popover for options mode.
             */
            this.togglePopoverOptions = () => {
                if (this.disabled || this.readonly) {
                    return;
                }
                this.open = !this.open;
            };
            /**
             * Toggle the multiselect popover for slots mode.
             */
            this.togglePopoverSlots = () => {
                if (this.disabled || this.readonly) {
                    return;
                }
                this.open = !this.open;
            };
            //#endregion METHODS
            /****************************************************************************/
            //#region RENDER
            /**
             * Renders the component in options mode
             * @returns {any} The JSX for options mode
             */
            this.renderOptionsMode = () => {
                return (index.h(index.Host, null, (this.label || this.el.querySelector('[slot="label"]')) && (index.h("label", { htmlFor: this.inputId }, index.h("slot", { name: "label" }, this.label))), index.h("nv-popover", { ref: el => (this.popoverElement = el), triggerMode: "controlled", placement: "bottom-start", open: this.open }, index.h("div", { class: "input-wrapper-multiselect", slot: "trigger" }, index.h("slot", { name: "before-input" }), index.h("div", { class: "input-container-multiselect" }, index.h("slot", { name: "leading-input" }), this.selectedValues.length > 0 && (index.h("nv-badge", { slot: "leading-input", "prevent-auto-close": true, color: "10", dismissible: this.selectedValues.length > 0, label: `${this.selectedValues.length} ${this.badgeLabel}`, "aria-label": `Clear all ${this.selectedValues.length} ${this.badgeLabel} items`, onCloseClicked: this.handleBadgeCloseOptions })), this.filterable || this.disabled || this.readonly ? (index.h("input", { type: "text", id: this.inputId, ref: e => (this.inputElement = e), autofocus: this.autofocus, autocomplete: this.autocomplete, placeholder: this.placeholder, name: this.name, value: this.value, required: this.required, disabled: this.disabled, readOnly: this.readonly, onInput: this.handleInputOptions, onFocus: this.handleInputFocusOptions, onBlur: this.handleInputBlurOptions, onKeyDown: this.handleKeyDown })) : (index.h("p", { id: this.inputId, class: "non-filterable-text", onClick: this.handleInputContainerClickOptions, tabIndex: 0, onKeyDown: this.handleKeyDown, onFocus: this.handleInputFocusOptions, role: "combobox", "aria-expanded": this.open }, index.h("span", null, this.value || this.placeholder))), this.error && (index.h("nv-icon", { name: "alert-circle", class: "validation", size: "md" })), index.h("nv-iconbutton", { "data-scope": "toggle-dropdown", name: this.open ? 'chevron-top' : 'chevron-down', size: "md", emphasis: "lower", "aria-label": this.open ? 'Hide dropdown' : 'Show dropdown', "aria-pressed": this.open.toString(), onClick: this.togglePopoverOptions })), index.h("slot", { name: "after-input" })), index.h("div", { slot: "content", role: "listbox", "aria-multiselectable": "true", style: { 'max-height': this.maxHeight, 'overflow-y': 'auto' } }, index.h("ul", { role: "content" }, this.options.map(option => (index.h("nv-fielddropdownitemcheck", { label: option.label, description: option.description, value: option.value, checked: this.selectedValues.includes(option.value), disabled: option.disabled }))), index.h("hr", { class: "multiselect-divider", style: { display: 'none' } })))), this.renderDescriptions()));
            };
            /**
             * Renders the component in slots mode
             * @returns {any} The JSX for slots mode
             */
            this.renderSlotsMode = () => {
                return (index.h(index.Host, null, (this.label || this.el.querySelector('[slot="label"]')) && (index.h("label", { htmlFor: this.inputId }, index.h("slot", { name: "label" }, this.label))), index.h("nv-popover", { ref: el => (this.popoverElement = el), triggerMode: "controlled", placement: "bottom-start", open: this.open }, index.h("div", { class: "input-wrapper-multiselect", slot: "trigger" }, index.h("slot", { name: "before-input" }), index.h("div", { class: "input-container-multiselect", onClick: this.handleInputContainerClickSlots }, index.h("slot", { name: "leading-input" }), this.selectedValues.length > 0 && (index.h("nv-badge", { slot: "leading-input", "prevent-auto-close": true, color: "10", dismissible: this.selectedValues.length > 0, label: `${this.selectedValues.length} ${this.badgeLabel}`, "aria-label": `Clear all ${this.selectedValues.length} ${this.badgeLabel} items`, onCloseClicked: this.handleBadgeCloseSlots })), this.filterable || this.disabled || this.readonly ? (index.h("input", { id: this.inputId, ref: e => (this.inputElement = e), autocomplete: this.autocomplete, placeholder: this.placeholder, name: this.name, value: this.value, required: this.required, disabled: this.disabled, readOnly: this.readonly, onInput: this.handleInputSlots, onFocus: this.handleInputFocusSlots, onBlur: this.handleInputBlurSlots, onKeyDown: this.handleKeyDown })) : (index.h("p", { id: this.inputId, class: "non-filterable-text", onClick: this.handleInputContainerClickSlots, tabIndex: 0, onKeyDown: this.handleKeyDown, onFocus: this.handleInputFocusSlots, role: "combobox", "aria-expanded": this.open }, index.h("span", null, this.value || this.placeholder))), this.error && (index.h("nv-icon", { name: "alert-circle", class: "validation", size: "md" })), index.h("nv-iconbutton", { "data-scope": "toggle-dropdown", name: this.open ? 'chevron-top' : 'chevron-down', size: "md", emphasis: "lower", "aria-label": this.open ? 'Hide dropdown' : 'Show dropdown', "aria-pressed": this.open.toString(), onClick: this.togglePopoverSlots })), index.h("slot", { name: "after-input" })), index.h("div", { slot: "content", role: "listbox", "aria-multiselectable": "true", style: { 'max-height': this.maxHeight, 'overflow-y': 'auto' } }, index.h("slot", { name: "content" }))), this.renderDescriptions()));
            };
        }
        //#endregion PROPERTIES
        /****************************************************************************/
        //#region LIFECYCLE
        /**
         * Subscribe to click outside event.
         */
        connectedCallback() {
            document.addEventListener('click', this.handleClickOutside.bind(this));
        }
        /**
         * Set the mode state and handle options change.
         */
        componentWillLoad() {
            var _a;
            // Don't call handleOptionsChange if we are in slots mode
            if (this.options) {
                this.handleOptionsChange(this.options);
            }
            // Specific initialization for slots mode
            if (!this.options) {
                Promise.resolve().then(() => {
                    const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitemcheck'));
                    // Initialize selectedValues with checked items
                    this.selectedValues = items
                        .filter(item => item.hasAttribute('checked'))
                        .map(item => item.getAttribute('value') || '');
                    // Force a reorder after initialization
                    requestAnimationFrame(() => {
                        this.reorderSlotContent();
                    });
                });
            }
            // Initialize the sorted options array with the parsed options for initial rendering
            if (this.options) {
                this.sortedOptions = [...((_a = this.options) !== null && _a !== void 0 ? _a : [])];
            }
            // Apply filtering if the multiselect is filterable and there is a value
            if (this.filterable && this.value) {
                this.filterText = String(this.value).toLocaleLowerCase();
                this.filterItems();
            }
            else {
                // Reset visibility state of all dropdown items
                this.resetFilter();
            }
        }
        /**
         * Force reorder if options mode in componentDidLoad because of the initial render not trigger @watch
         */
        componentDidLoad() {
            if (this.options) {
                this.handleOptionsChange(this.options);
            }
        }
        /**
         * Unsubscribe from click outside event.
         */
        disconnectedCallback() {
            document.removeEventListener('click', this.handleClickOutside.bind(this));
        }
        /**
         * Emitted when the input loses focus.
         * @param {CustomEvent<boolean>} event - The event object containing the focus state.
         */
        handleOpenChanged(event) {
            // Update the open state of popover
            this.open = event.detail;
            if (this.open) {
                // Filter items only if there is filter text
                if (this.filterText) {
                    this.filterItems();
                }
            }
            else {
                this.handlePopoverClose();
            }
            if (this.options) {
                this.reorderOptionsContent();
            }
            else {
                this.reorderSlotContent();
            }
        }
        /**
         * Listen for the `itemChecked` event emitted by child items.
         * @param {CustomEvent} event - The event object containing the selected value and its checked state.
         */
        handleItemChecked(event) {
            if (this.disabled || this.readonly) {
                return;
            }
            const { value, checked } = event.detail;
            if (value !== undefined && value !== null) {
                const newSelectedValues = [...this.selectedValues];
                const valueIndex = newSelectedValues.indexOf(value);
                if (checked && valueIndex === -1) {
                    newSelectedValues.push(value);
                }
                else if (!checked && valueIndex > -1) {
                    newSelectedValues.splice(valueIndex, 1);
                }
                // Update the state and emit the event only if the selection has changed
                if (JSON.stringify(this.selectedValues) !==
                    JSON.stringify(newSelectedValues)) {
                    this.selectedValues = newSelectedValues;
                    // Use requestAnimationFrame to ensure the state is updated before emitting the event
                    requestAnimationFrame(() => {
                        this.multiselectChange.emit(this.selectedValues);
                    });
                }
            }
            else {
                console.warn('Received itemChecked event with undefined or null value'); // Warning log
            }
        }
        handleOptionsChange(newValue) {
            if (!newValue)
                return;
            this.selectedValues = newValue
                .filter(option => option.checked)
                .map(option => option.value);
            this.reorderOptionsContent();
        }
        /**
         * Emitted when the value changes.
         */
        watchValueHandler() {
            // Handle value change and update the corresponding multiselect item if it exists
            this.setInitialSelection();
        }
        // Add a listener for the slot content
        handleSlotChange(event) {
            // Check: we only want to reorder if it's the "content" slot
            const slot = event.target;
            if (slot && slot.name === 'content') {
                // To give other platforms (VueJS, React, etc.) time to insert all their items,
                // we place the reorder in a requestAnimationFrame
                requestAnimationFrame(() => {
                    this.reorderSlotContent();
                });
            }
        }
        //#endregion EVENTS
        /****************************************************************************/
        //#region METHODS
        /**
         * Retrieves the current filter text entered by the user.
         * @returns {string} The filter text.
         */
        async getFilterText() {
            return this.filterText;
        }
        /**
         * Set the initial selection based on the current value and update the inputElement value.
         */
        setInitialSelection() {
            var _a;
            const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitem'));
            const selectedItem = items.find(item => {
                var _a;
                return item.getAttribute('label') === this.value ||
                    item.getAttribute('value') === this.value ||
                    ((_a = item.textContent) === null || _a === void 0 ? void 0 : _a.trim()) === this.value;
            });
            // Remove 'selected' from all items first to reset the state
            items.forEach(item => {
                item.removeAttribute('selected');
                item.classList.remove('selected');
            });
            if (selectedItem) {
                // Add the `selected` attribute and `selected` class for visual styling
                selectedItem.setAttribute('selected', 'true');
                selectedItem.classList.add('selected');
                // Update the value and inputElement value to reflect the pre-selected item
                this.value =
                    selectedItem.getAttribute('label') ||
                        selectedItem.getAttribute('value') ||
                        ((_a = selectedItem.textContent) === null || _a === void 0 ? void 0 : _a.trim()) ||
                        '';
                if (this.inputElement) {
                    this.inputElement.value = this.value;
                }
            }
        }
        /**
         * Reset the filter and make all items visible.
         */
        async resetFilter() {
            const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitemcheck'));
            // Reset visibility state of all dropdown items
            items.forEach(item => {
                item.style.display = '';
            });
            // Clean up filter-related UI elements
            const ul = this.el.querySelector('ul');
            if (ul) {
                const emptyMessage = ul.querySelector('[data-empty]');
                if (emptyMessage)
                    emptyMessage.remove();
                // Reorder with divider if needed
                const selectedItems = items.filter(item => this.selectedValues.includes(item.getAttribute('value') || ''));
                const unselectedItems = items.filter(item => !this.selectedValues.includes(item.getAttribute('value') || ''));
                if (selectedItems.length > 0) {
                    this.manageDivider(ul, selectedItems, unselectedItems);
                }
            }
        }
        /**
         * Returns the list of selected values.
         * @returns {string[]} The selected values.
         */
        async getSelectedValues() {
            return this.selectedValues;
        }
        /**
         * Reorder the content of the slot.
         */
        reorderSlotContent() {
            if (this.options)
                return;
            const ul = this.el.querySelector('ul');
            if (!ul)
                return;
            // Remove all existing <hr class="multiselect-divider">
            ul.querySelectorAll('hr.multiselect-divider').forEach(divider => divider.remove());
            // Retrieve all items (not hidden)
            const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitemcheck')).filter(item => item.style.display !== 'none');
            // If you possibly have a "No results" message:
            const hasEmptyMessage = ul.querySelector('[data-empty]');
            if (hasEmptyMessage) {
                // if there is a "No results found" message, do not reorder
                return;
            }
            // Separate checked vs unchecked
            const selectedItems = items.filter(item => this.selectedValues.includes(item.getAttribute('value') || ''));
            const unselectedItems = items.filter(item => !this.selectedValues.includes(item.getAttribute('value') || ''));
            // Reinsert CHECKED items FIRST
            // appendChild() moves the element without recreating it
            // this is not trigger a re-rendering of the component in the platforms
            selectedItems.forEach(item => {
                ul.appendChild(item); // <-- The <li> (or <nv-fielddropdownitemcheck>) is just "moved" to the end of the list
            });
            // Add a divider if needed
            if (selectedItems.length > 0 && unselectedItems.length > 0) {
                const divider = document.createElement('hr');
                divider.className = 'multiselect-divider';
                ul.appendChild(divider);
            }
            // Reinsert UNCHECKED items at the end
            unselectedItems.forEach(item => {
                ul.appendChild(item);
            });
        }
        /**
         * Reorder the content for options mode with async handling
         */
        reorderOptionsContent() {
            const ul = this.el.querySelector('ul[role="content"]');
            if (!ul)
                return;
            const items = Array.from(ul.querySelectorAll('nv-fielddropdownitemcheck')).filter(item => item.style.display !== 'none');
            const selectedItems = items.filter(item => this.selectedValues.includes(item.getAttribute('value') || ''));
            const unselectedItems = items.filter(item => !this.selectedValues.includes(item.getAttribute('value') || ''));
            // Reorder the elements
            selectedItems.forEach(item => ul.appendChild(item));
            unselectedItems.forEach(item => ul.appendChild(item));
            // Manage the divider after the reordering
            this.manageDivider(ul, selectedItems, unselectedItems);
        }
        /**
         * Filter multiselect items based on the text entered by the user.
         */
        filterItems() {
            const ul = this.el.querySelector('ul');
            if (!ul)
                return;
            // Remove existing empty message if any
            const existingEmptyMessage = ul.querySelector('[data-empty]');
            if (existingEmptyMessage) {
                existingEmptyMessage.remove();
            }
            if (!this.filterText.trim()) {
                if (this.options && this.options.length > 0) {
                    // Reset options display
                    const items = Array.from(ul.querySelectorAll('nv-fielddropdownitemcheck'));
                    items.forEach(item => {
                        item.style.display = '';
                    });
                }
                else {
                    // Reset slot items display
                    const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitemcheck'));
                    items.forEach(item => {
                        item.style.display = '';
                    });
                }
                // Reorder with divider
                const items = Array.from(ul.querySelectorAll('nv-fielddropdownitemcheck'));
                const selectedItems = items.filter(item => this.selectedValues.includes(item.getAttribute('value') || ''));
                const unselectedItems = items.filter(item => !this.selectedValues.includes(item.getAttribute('value') || ''));
                this.manageDivider(ul, selectedItems, unselectedItems);
                return;
            }
            const normalizedFilter = this.normalizeText(this.filterText);
            let hasVisibleItems = false;
            if (this.options && this.options.length > 0) {
                // Filter options mode
                const items = Array.from(ul.querySelectorAll('nv-fielddropdownitemcheck'));
                items.forEach(item => {
                    const option = this.options.find(opt => opt.value === item.getAttribute('value'));
                    if (option && !option.isDivider) {
                        const matchesFilter = this.normalizeText(option.label).includes(normalizedFilter) ||
                            this.normalizeText(option.value).includes(normalizedFilter);
                        item.style.display = matchesFilter ? '' : 'none';
                        if (matchesFilter)
                            hasVisibleItems = true;
                    }
                });
                // Manage the divider with the visible items
                const visibleItems = items.filter(item => item.style.display !== 'none');
                const visibleSelected = visibleItems.filter(item => this.selectedValues.includes(item.getAttribute('value') || ''));
                const visibleUnselected = visibleItems.filter(item => !this.selectedValues.includes(item.getAttribute('value') || ''));
                this.manageDivider(ul, visibleSelected, visibleUnselected);
            }
            else {
                // Filter slot items mode
                const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitemcheck'));
                items.forEach(item => {
                    const label = item.getAttribute('label') || '';
                    const value = item.getAttribute('value') || '';
                    const textContent = item.textContent || '';
                    const matchesFilter = this.normalizeText(label).includes(normalizedFilter) ||
                        this.normalizeText(value).includes(normalizedFilter) ||
                        this.normalizeText(textContent).includes(normalizedFilter);
                    item.style.display = matchesFilter ? '' : 'none';
                    if (matchesFilter)
                        hasVisibleItems = true;
                });
            }
            // Add empty message if no items match the filter
            if (!hasVisibleItems) {
                const emptyMessage = document.createElement('li');
                emptyMessage.setAttribute('data-empty', 'true');
                emptyMessage.textContent = this.emptyResult;
                emptyMessage.classList.add('no-results-message');
                ul.appendChild(emptyMessage);
            }
            this.reorderSlotContent();
        }
        /**
         * Filter multiselect items in options mode.
         */
        filterItemsOption() {
            const ul = this.el.querySelector('ul');
            if (!ul)
                return;
            const normalizedFilter = this.normalizeText(this.filterText);
            let hasVisibleItems = false;
            const items = Array.from(ul.querySelectorAll('nv-fielddropdownitemcheck'));
            // Reset items if the filter text is empty
            if (!this.filterText.trim()) {
                // Remove the empty message if it exists
                this.removeEmptyMessageOption(ul);
                items.forEach(item => (item.style.display = ''));
                this.reorderOptionsContent(); // Reorder after reset
                return;
            }
            // Filter the items
            items.forEach(item => {
                const label = item.getAttribute('label') || '';
                const value = item.getAttribute('value') || '';
                const matchesFilter = this.normalizeText(label).includes(normalizedFilter) ||
                    this.normalizeText(value).includes(normalizedFilter);
                item.style.display = matchesFilter ? '' : 'none';
                if (matchesFilter)
                    hasVisibleItems = true;
            });
            // Manage the divider with the visible items
            const visibleItems = items.filter(item => item.style.display !== 'none');
            const visibleSelected = visibleItems.filter(item => this.selectedValues.includes(item.getAttribute('value') || ''));
            const visibleUnselected = visibleItems.filter(item => !this.selectedValues.includes(item.getAttribute('value') || ''));
            this.manageDivider(ul, visibleSelected, visibleUnselected);
            // Add or remove the empty message based on the case
            if (!hasVisibleItems) {
                this.addEmptyMessageOption(ul);
            }
            else {
                this.removeEmptyMessageOption(ul);
            }
        }
        /**
         * Filter multiselect items in slots mode
         */
        filterSlotsItems() {
            if (this.options)
                return;
            const ul = this.el.querySelector('ul');
            if (!ul)
                return;
            // Remove existing empty message if any
            const existingEmptyMessage = ul.querySelector('[data-empty]');
            if (existingEmptyMessage) {
                existingEmptyMessage.remove();
            }
            // If filter text is empty, reset all items visibility
            if (!this.filterText.trim()) {
                this.resetFilter();
                return;
            }
            const normalizedFilter = this.normalizeText(this.filterText);
            let hasVisibleItems = false;
            // Get all items and preserve them in the DOM
            const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitemcheck'));
            // Instead of removing/reordering, just hide/show items
            items.forEach(item => {
                var _a;
                const label = item.getAttribute('label') || '';
                const value = item.getAttribute('value') || '';
                const textContent = ((_a = item.textContent) === null || _a === void 0 ? void 0 : _a.trim()) || '';
                const matchesFilter = this.normalizeText(label).includes(normalizedFilter) ||
                    this.normalizeText(value).includes(normalizedFilter) ||
                    this.normalizeText(textContent).includes(normalizedFilter);
                item.style.display = matchesFilter ? '' : 'none';
                if (matchesFilter)
                    hasVisibleItems = true;
            });
            // Get visible items after filtering
            const visibleItems = items.filter(item => item.style.display !== 'none');
            const visibleSelectedItems = visibleItems.filter(item => this.selectedValues.includes(item.getAttribute('value') || ''));
            this.manageDivider(ul, visibleSelectedItems, visibleItems.filter(item => !this.selectedValues.includes(item.getAttribute('value') || '')));
            // Add empty message if no items match the filter
            if (!hasVisibleItems) {
                const emptyMessage = document.createElement('li');
                emptyMessage.setAttribute('data-empty', 'true');
                emptyMessage.textContent = this.emptyResult;
                emptyMessage.classList.add('no-results-message');
                ul.appendChild(emptyMessage);
            }
        }
        /**
         * Normalizes text by removing accents and converting to lowercase
         * @param {string} text - The text to normalize
         * @returns {string} The normalized text
         *
         * @example
         * normalizeText("Café Latte") => "cafe latte"
         *
         * @description
         * This function performs text normalization in three steps:
         * 1. Decomposes characters into their base form and combining characters (NFD)
         * 2. Removes all diacritical marks (accents, umlauts, etc.)
         * 3. Converts to lowercase and trims whitespace
         *
         * @see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/normalize} - MDN documentation on String.normalize()
         * @see {@link https://en.wikipedia.org/wiki/Unicode_equivalence#Normal_forms} - More info about Unicode normalization forms
         */
        normalizeText(text) {
            return text
                .normalize('NFD') // Decompose characters into base + combining characters (e.g., é => e + ´)
                .replace(/[\u0300-\u036f]/g, '') // Remove all diacritical marks (Unicode range for combining characters)
                .toLowerCase() // Convert to lowercase
                .trim(); // Remove leading and trailing whitespace
        }
        handleClickOutside(event) {
            if (this.el.contains(event.target) ||
                (this.inputElement && this.inputElement.contains(event.target))) {
                return;
            }
            this.open = false;
        }
        /**
         * Handle keyboard events & arrow key navigation.
         * If the multiselect is not open, opens it and focuses on the first item if the list is not filterable.
         * If the multiselect is open, handles arrow key navigation and closes it if the focus is outside the component.
         * @param {KeyboardEvent} event - The keyboard event.
         */
        async handleKeyDown(event) {
            if (!this.open) {
                if (event.key === 'ArrowDown') {
                    this.open = true;
                    // Focus on the first item if the list is not filterable
                    if (!this.filterable) {
                        requestAnimationFrame(() => {
                            this.focusFirstItem();
                        });
                    }
                    event.preventDefault();
                    return;
                }
                return;
            }
            const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitemcheck:not([style*="display: none"])'));
            if (items.length === 0) {
                console.warn('No visible items found to navigate');
                return;
            }
            let currentIndex = items.findIndex(item => item.classList.contains('highlighted'));
            if (event.key === 'ArrowDown') {
                event.preventDefault();
                currentIndex =
                    currentIndex === -1 ? 0 : (currentIndex + 1) % items.length;
                this.updateHighlightedItem(items, currentIndex);
            }
            else if (event.key === 'ArrowUp') {
                event.preventDefault();
                currentIndex =
                    currentIndex === -1
                        ? items.length - 1
                        : (currentIndex - 1 + items.length) % items.length;
                this.updateHighlightedItem(items, currentIndex);
            }
            else if (event.key === 'Enter' && currentIndex >= 0) {
                event.preventDefault();
                const selectedItem = items[currentIndex];
                // Toggle the checked state
                const isCurrentlyChecked = selectedItem.hasAttribute('checked');
                selectedItem.checked = !isCurrentlyChecked;
                // Trigger a click event to ensure proper event handling
                selectedItem.dispatchEvent(new MouseEvent('click', {
                    view: window,
                    bubbles: true,
                    cancelable: true,
                }));
            }
            else if (event.key === 'Escape') {
                event.preventDefault();
                event.stopPropagation(); // Prevent the event from propagating to the popover
                // Do the reorder and wait a bit before closing
                const handleEscape = async () => {
                    this.isHandlingEscape = true; // Disable the hide listener
                    if (this.options) {
                        this.reorderOptionsContent();
                    }
                    else {
                        this.reorderSlotContent();
                    }
                    // Wait for the reorder to be applied
                    await new Promise(resolve => setTimeout(resolve, 100));
                    // Reactivate the hide listener after a short delay
                    setTimeout(() => {
                        this.isHandlingEscape = false;
                        this.open = false;
                    }, 150);
                    if (this.inputElement) {
                        this.inputElement.blur();
                    }
                };
                await handleEscape();
            }
        }
        /**
         * Updates the highlighted item in the dropdown list.
         *
         * @param {(HTMLNvFielddropdownitemElement | HTMLNvFielddropdownitemcheckElement)[]} items - The items to update.
         * @param {number} index - The index of the item to highlight.
         */
        updateHighlightedItem(items, index) {
            items.forEach((item, i) => {
                if (i === index) {
                    item.classList.add('highlighted');
                    item.setAttribute('tabindex', '0');
                    item.scrollIntoView({ block: 'nearest' });
                    // Focus on the nv-fieldcheckbox inside
                    const checkbox = item.querySelector('nv-fieldcheckbox');
                    if (checkbox) {
                        checkbox.focus();
                    }
                }
                else {
                    item.classList.remove('highlighted');
                    item.setAttribute('tabindex', '-1');
                }
            });
        }
        /**
         * Focus on the first item in the dropdown list.
         */
        focusFirstItem() {
            const firstItem = this.el.querySelector('nv-fielddropdownitemcheck:not([style*="display: none"])');
            if (firstItem) {
                firstItem.setAttribute('tabindex', '0');
                firstItem.classList.add('highlighted');
                firstItem.scrollIntoView({ block: 'nearest' });
                // Focus on the nv-fieldcheckbox inside
                const checkbox = firstItem.querySelector('nv-fieldcheckbox');
                if (checkbox) {
                    checkbox.focus();
                }
            }
            else {
                console.warn('No visible first item found to focus');
            }
        }
        addEmptyMessageOption(ul) {
            const existingMessage = ul.querySelector('[data-empty]');
            if (existingMessage)
                return;
            const emptyMessage = document.createElement('li');
            emptyMessage.setAttribute('data-empty', 'true');
            emptyMessage.textContent = this.emptyResult;
            emptyMessage.classList.add('no-results-message');
            ul.appendChild(emptyMessage);
        }
        removeEmptyMessageOption(ul) {
            const existingMessage = ul.querySelector('[data-empty]');
            if (existingMessage)
                existingMessage.remove();
        }
        manageDivider(ul, selectedItems, unselectedItems) {
            let divider = ul.querySelector('hr.multiselect-divider');
            if (!divider) {
                divider = document.createElement('hr');
                divider.className = 'multiselect-divider';
                ul.appendChild(divider);
            }
            const shouldShowDivider = selectedItems.length > 0 && unselectedItems.length > 0;
            if (shouldShowDivider) {
                // Place the divider after the last selected item
                const lastSelectedItem = selectedItems[selectedItems.length - 1];
                lastSelectedItem.after(divider);
                divider.style.display = '';
            }
            else {
                divider.style.display = 'none';
            }
        }
        /**
         * Renders description and error description sections
         * @returns {any} The JSX for descriptions
         */
        renderDescriptions() {
            return [
                (this.description || this.el.querySelector('[slot="description"]')) && (index.h("div", { class: "description" }, index.h("slot", { name: "description" }, this.description))),
                (this.errorDescription ||
                    this.el.querySelector('[slot="error-description"]')) && (index.h("div", { hidden: !this.error, class: "error-description" }, index.h("slot", { name: "error-description" }, this.errorDescription))),
            ];
        }
        /**
         * Main render method that decides which mode to render
         * @returns {any} The JSX for the component
         */
        render() {
            return this.options ? this.renderOptionsMode() : this.renderSlotsMode();
        }
        static get formAssociated() { return true; }
        get el() { return index.getElement(this); }
        static get watchers() { return {
            "options": ["handleOptionsChange"],
            "value": ["watchValueHandler"]
        }; }
    };
    NvFieldmultiselect.style = NvFieldmultiselectStyle0;

    exports.nv_fieldmultiselect = NvFieldmultiselect;

}));
