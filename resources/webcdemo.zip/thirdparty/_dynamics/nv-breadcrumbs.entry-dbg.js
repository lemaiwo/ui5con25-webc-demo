sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2'], (function (exports, index) { 'use strict';

    const nvBreadcrumbsCss = "nv-breadcrumbs{display:block}nv-breadcrumbs>ol{display:flex;flex-wrap:wrap;align-items:center;gap:var(--breadcrumb-padding-y)}nv-breadcrumbs nv-breadcrumb:last-child [data-scope=separator],nv-breadcrumbs nv-breadcrumb:last-child [slot=separator]{display:none}";
    const NvBreadcrumbsStyle0 = nvBreadcrumbsCss;

    const NvBreadcrumbs = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
        }
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '19ad2bb41f4254a98a571cbadb50ba5ed7d29f62', role: "navigation", "aria-label": "breadcrumbs" }, index.h("ol", { key: '11b77f0f11c6b1dc2ce5ab3f4f7b23e8ec728b61' }, index.h("slot", { key: 'c0c683f93c6874aa5f84fb735d13c1b5eabcd951' }))));
        }
    };
    NvBreadcrumbs.style = NvBreadcrumbsStyle0;

    exports.nv_breadcrumbs = NvBreadcrumbs;

}));
