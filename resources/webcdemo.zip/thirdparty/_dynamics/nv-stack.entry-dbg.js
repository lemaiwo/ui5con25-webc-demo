sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/clsx-297c1ffe'], (function (exports, index, clsx297c1ffe) { 'use strict';

    const nvStackCss = "nv-stack{display:flex;align-items:center;justify-content:flex-start;flex-direction:row}nv-stack nv-col{display:flex}nv-stack:not(nv-row){flex-wrap:nowrap}nv-stack>.nv-stack-item-flex{flex-shrink:1;flex-grow:1}nv-stack>.nv-stack-item-lead{margin-right:auto}nv-stack>.nv-stack-item-lead+*{margin-left:0}nv-stack>.nv-stack-item-center{margin-right:auto;margin-left:auto}nv-stack>.nv-stack-item-tail{margin-left:auto}nv-stack>.nv-stack-nowrap{white-space:nowrap}nv-stack.nv-stack-vertical{align-items:stretch;flex-direction:column}nv-stack.nv-stack-vertical>.nv-stack-item-lead{margin-right:0;margin-bottom:auto}nv-stack.nv-stack-vertical>.nv-stack-item-lead+*{margin-top:0}nv-stack.nv-stack-vertical>.nv-stack-item-tail{margin-left:0;margin-top:auto}nv-stack.nv-stack-vertical>.nv-stack-item-center{margin:auto 0}nv-stack.nv-stack-flex>*{flex-shrink:1;flex-grow:1}nv-stack.nv-stack-fill>*{height:100%}nv-stack.nv-stack-fill.nv-stack-vertical>*{height:auto;width:100%}";
    const NvStackStyle0 = nvStackCss;

    const NvStack = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Gutter refers to the space that exists between children components inside
             * the stack container.
             */
            this.gutter = 2;
        }
        //#endregion PROPERTIES
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '02e184fbc9e9ddd4b02b107baf093047fa3697b0', class: clsx297c1ffe.clsx(this.fill && 'nv-stack-fill', this.flex && 'nv-stack-flex', this.full && 'w-full', this.gutter && !this.vertical && `gap-x-${this.gutter}`, this.gutter && this.vertical && `gap-y-${this.gutter}`, this.vertical && 'nv-stack-vertical') }, index.h("slot", { key: '1a501fcc419f97f2714be822120072b49590e5ea' })));
        }
    };
    NvStack.style = NvStackStyle0;

    exports.nv_stack = NvStack;

}));
