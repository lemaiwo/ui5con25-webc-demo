sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/v4-a79185f4'], (function (exports, index, v4A79185f4) { 'use strict';

    const nvFieldpasswordCss = "nv-fieldpassword{--nv-field-border-default:var(--components-form-field-border-default);--nv-field-border-hover:var(--components-form-field-border-hover);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--components-form-field-border-default);--nv-field-border-readonly:var(--components-form-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-brand);--nv-field-background:var(--components-form-field-background-default);display:flex;flex-direction:column;align-items:flex-start;gap:var(--form-gap-y);box-sizing:border-box}nv-fieldpassword[readonly]:not([readonly=false]){--nv-field-border-default:var(--components-form-field-border-readonly);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-background:var(--components-form-field-background-readonly)}nv-fieldpassword[error]:not([error=false]){--nv-field-border-default:var(--components-form-field-border-error);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--nv-field-border-default);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-destructive)}nv-fieldpassword[success]:not([success=false]){--nv-field-border-default:var(--components-form-field-border-success);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--nv-field-border-default);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-success)}nv-fieldpassword[required]:not([required=false]) label::after{content:\"*\";color:var(--components-form-text-required);font-weight:700}nv-fieldpassword label{display:flex;align-items:center;gap:var(--form-label-gap);align-self:stretch;color:var(--components-form-text-label-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-label-font-size);font-style:normal;font-weight:500;line-height:var(--form-label-line-height)}nv-fieldpassword .input-wrapper{display:flex;flex-wrap:wrap;gap:var(--form-gap-x);align-items:stretch;align-self:stretch}nv-fieldpassword .input-wrapper .input-container{display:flex;flex-grow:1;justify-content:center;align-items:center;align-self:stretch;border-radius:var(--form-field-radius);border-width:1px;border-style:solid;border-color:var(--nv-field-border-default);opacity:var(--components-form-opacity-default, 1);background:var(--nv-field-background);transition:all 150ms ease-out;position:relative}nv-fieldpassword .input-wrapper .input-container:hover{border-color:var(--nv-field-border-hover)}nv-fieldpassword .input-wrapper .input-container:focus-within,nv-fieldpassword .input-wrapper .input-container:focus-within:hover,nv-fieldpassword .input-wrapper .input-container:focus,nv-fieldpassword .input-wrapper .input-container:focus:hover{border-color:var(--nv-field-border-focus);box-shadow:0px 0px 0px var(--focus-field-stroke) var(--nv-field-focus-box-shadow)}nv-fieldpassword .input-wrapper .input-container:has(input:read-only){opacity:0.5;background-color:var(--components-form-field-background-readonly);border-color:var(--nv-field-border-readonly)}nv-fieldpassword .input-wrapper .input-container:has(input:disabled){opacity:0.5;background-color:var(--components-form-field-background-disabled);border-color:var(--nv-field-border-disabled)}nv-fieldpassword .input-wrapper .input-container input{display:flex;align-items:center;flex:1 0 0;overflow:hidden;background-color:transparent;color:var(--components-form-field-content-text);padding:var(--form-field-padding-y) var(--form-field-padding-x);font-size:var(--form-field-font-size);font-style:normal;font-weight:500;line-height:var(--form-field-line-height)}nv-fieldpassword .input-wrapper .input-container input:focus{outline:none}nv-fieldpassword .input-wrapper .input-container input::placeholder{overflow:hidden;color:var(--components-form-field-content-placeholder);text-overflow:ellipsis;font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-field-font-size);font-style:normal;font-weight:400;line-height:var(--form-field-line-height)}nv-fieldpassword .input-wrapper .input-container>nv-iconbutton{border:0px;border-radius:0px}nv-fieldpassword .input-wrapper .input-container>nv-iconbutton:focus-visible{border-radius:var(--button-md-border-radius);outline-offset:-3px}nv-fieldpassword .input-wrapper .input-container nv-icon.validation{color:var(--nv-field-border-default)}nv-fieldpassword .description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;line-height:var(--form-description-line-height)}nv-fieldpassword .error-description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;line-height:var(--form-description-line-height);color:var(--components-form-text-description-error)}";
    const NvFieldpasswordStyle0 = nvFieldpasswordCss;

    const NvFieldpassword = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.valueChanged = index.createEvent(this, "valueChanged");
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Sets the ID for the input element and the for attribute of the associated
             * label. If no ID is provided, a random one will be automatically generated
             * to ensure unique identification, facilitating proper label association and
             * accessibility.
             */
            this.inputId = v4A79185f4.v4();
            /**
             * The disabled prop lets you turn off the input field so that users can’t
             * type in it. When disabled, the field is grayed out and won’t respond to#
             * clicks or touches.
             */
            this.disabled = false;
            /**
             * Display the input field’s content without allowing users to change it.
             * Users can still click on it, select, and copy the text, but they won’t be
             * able to type or delete anything.
             */
            this.readonly = false;
            /**
             * Marks the input field as required, ensuring that the user must fill it out
             * before submitting the form.
             */
            this.required = false;
            /**
             * Alters the input field’s appearance to indicate an error, helping users
             * identify fields that need correction.
             * @validator error
             */
            this.error = false;
            /**
             * Changes the input field’s appearance to indicate successful input or
             * validation.
             */
            this.success = false;
            /**
             * Defines the type of the input.
             * @default 'text'
             */
            this.mode = 'text';
            /**
             * The autocomplete prop helps users fill out the input field faster by
             * suggesting entries they’ve used before, like their email or address.
             * You can turn it on to make forms more convenient or off to ensure users
             * always type in fresh data.
             */
            this.autocomplete = 'off';
            /**
             * Hide the button to show/hide the password.
             */
            this.hidePasswordIcon = false;
            /**
             * Show/hide the password programmatically.
             */
            this.showPassword = false;
            /**
             * Applies focus to the input field as soon as the component is mounted. This
             * is equivalent to setting the native autofocus attribute on an <input>
             * element.
             */
            this.autofocus = false;
            //#endregion EVENTS
            /****************************************************************************/
            //#region METHODS
            this.handleInputContainerClick = () => {
                this.inputElement.focus();
            };
            this.togglePasswordVisibility = () => {
                this.showPasswordState = !this.showPasswordState;
            };
            this.handleInput = (event) => {
                const input = event.target;
                this.value = input.value; // Update the input value without worrying about the space
                this.valueChanged.emit(input.value);
            };
        }
        handleShowPasswordChange(newValue) {
            this.showPasswordState = newValue;
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillLoad() {
            this.showPasswordState = this.showPassword;
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '4a6de90f24bd6607293d616d60f6d742c46b04a9' }, (this.label || this.el.querySelector('[slot="label"]')) && (index.h("label", { key: '715f5935de3aa0f0f7b6aa9aa72c409a3875a849', htmlFor: this.inputId }, index.h("slot", { key: 'da11187833b12acfae578024bb67d717efbafaa1', name: "label" }, this.label))), index.h("div", { key: 'a669823e6c5aea5b4e0aacf0bfc1c8f7dbe67bab', class: "input-wrapper" }, index.h("slot", { key: '98b2b6eaaa867228a667bec2920c640ff0b829c7', name: "before-input" }), index.h("div", { key: 'fc896f9018563e80ea0f2aa1e2eb7992fd4a854c', class: "input-container", onClick: this.handleInputContainerClick }, index.h("slot", { key: '715814e77d1ba40463253d12751129f2c0d05407', name: "leading-input" }), index.h("input", { key: '8101af836f80da56ac9e2b859ab9fd5b6d254b91', id: this.inputId, ref: e => (this.inputElement = e), autofocus: this.autofocus, autocomplete: this.autocomplete, placeholder: this.placeholder, name: this.name, type: this.showPasswordState ? 'text' : 'password', inputMode: this.mode, value: this.value, required: this.required, maxlength: this.maxlength, minlength: this.minlength, pattern: this.pattern, disabled: this.disabled, readOnly: this.readonly, onInput: this.handleInput }), (this.success || this.error) && (index.h("nv-icon", { key: 'fdf5caa936a43961bd3f00f5d50635124b57ff0b', name: this.success ? 'circle-check' : 'alert-circle', class: "validation", size: "md" })), !this.hidePasswordIcon && (index.h("nv-iconbutton", { key: '9b9e70d855fca2ea1ff2769609af05fc7d3fd1c2', name: this.showPasswordState ? 'eye' : 'eye-off', size: "md", emphasis: "lower", onClick: this.togglePasswordVisibility, "aria-label": this.showPasswordState ? 'Hide password' : 'Show password', "aria-pressed": this.showPasswordState.toString() }))), index.h("slot", { key: '4458e83104562509b53b05faf3a316a5502b76b7', name: "after-input" })), (this.description ||
                this.el.querySelector('[slot="description"]')) && (index.h("div", { key: '91dcddd8a80abccaaffda9cd583759bebf376456', class: "description" }, index.h("slot", { key: 'fe6da6eb725b3866faf138e848f89152f0f24a00', name: "description" }, this.description))), (this.errorDescription ||
                this.el.querySelector('[slot="error-description"]')) && (index.h("div", { key: 'bfe57a6b0f199c3b371a2036a7b8787f40f639a4', hidden: !this.error, class: "error-description" }, index.h("slot", { key: '529e34f2197c64ac768df11251bb285fec1f2cd5', name: "error-description" }, this.errorDescription)))));
        }
        static get formAssociated() { return true; }
        get el() { return index.getElement(this); }
        static get watchers() { return {
            "showPassword": ["handleShowPasswordChange"]
        }; }
    };
    NvFieldpassword.style = NvFieldpasswordStyle0;

    exports.nv_fieldpassword = NvFieldpassword;

}));
