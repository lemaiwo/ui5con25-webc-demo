sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/v4-a79185f4'], (function (exports, index, v4A79185f4) { 'use strict';

    const nvFielddropdownCss = "nv-fielddropdown{--nv-field-border-default:var(--components-form-field-border-default);--nv-field-border-hover:var(--components-form-field-border-hover);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--components-form-field-border-default);--nv-field-border-readonly:var(--components-form-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-brand);--nv-field-background:var(--components-form-field-background-default);display:flex;flex-direction:column;align-items:flex-start;gap:var(--form-gap-y);box-sizing:border-box}nv-fielddropdown[readonly]:not([readonly=false]){--nv-field-border-default:var(--components-form-field-border-readonly);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-background:var(--components-form-field-background-readonly)}nv-fielddropdown[error]:not([error=false]){--nv-field-border-default:var(--components-form-field-border-error);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--nv-field-border-default);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-destructive)}nv-fielddropdown[required]:not([required=false]) label::after{content:\"*\";color:var(--components-form-text-required);font-weight:700}nv-fielddropdown[hidden]:not([hidden=false]) label{display:none}nv-fielddropdown label{display:flex;align-items:center;gap:var(--form-label-gap);align-self:stretch;color:var(--components-form-text-label-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-label-font-size);font-style:normal;font-weight:500;line-height:var(--form-label-line-height)}nv-fielddropdown nv-popover{width:100%;display:block}nv-fielddropdown nv-popover [data-scope=popover]{width:100%;padding:var(--list-dropdown-padding);border-radius:var(--list-dropdown-radius);background-color:var(--components-list-dropdown-background);border:1px solid var(--components-list-dropdown-border)}nv-fielddropdown nv-popover [slot=content]{gap:var(--list-dropdown-gap-y);display:flex;flex-direction:column}nv-fielddropdown nv-popover hr{color:var(--components-list-dropdown-separator)}nv-fielddropdown .input-wrapper{display:flex;flex-wrap:wrap;gap:var(--form-gap-x);align-items:stretch;align-self:stretch;width:100%}nv-fielddropdown .input-container{display:flex;flex-grow:1;justify-content:center;align-items:center;align-self:stretch;border-radius:var(--form-field-radius);border-width:1px;border-style:solid;border-color:var(--nv-field-border-default);opacity:var(--components-form-opacity-default, 1);background:var(--nv-field-background);transition:all 150ms ease-out;position:relative;width:100%;min-height:40px}nv-fielddropdown .input-container:hover{border-color:var(--nv-field-border-hover)}nv-fielddropdown .input-container:focus-within,nv-fielddropdown .input-container:focus-within:hover,nv-fielddropdown .input-container:focus,nv-fielddropdown .input-container:focus:hover{border-color:var(--nv-field-border-focus);box-shadow:0px 0px 0px var(--focus-field-stroke) var(--nv-field-focus-box-shadow)}nv-fielddropdown .input-container:has(input:read-only){opacity:0.5;background-color:var(--components-form-field-background-readonly);border-color:var(--nv-field-border-readonly)}nv-fielddropdown .input-container:has(input:disabled){opacity:0.5;background-color:var(--components-form-field-background-disabled);border-color:var(--nv-field-border-disabled)}nv-fielddropdown .input-container input[type=search]::-webkit-search-decoration,nv-fielddropdown .input-container input[type=search]::-webkit-search-cancel-button,nv-fielddropdown .input-container input[type=search]::-webkit-search-results-button,nv-fielddropdown .input-container input[type=search]::-webkit-search-results-decoration{-webkit-appearance:none}nv-fielddropdown .input-container input,nv-fielddropdown .input-container p.non-filterable-text{display:flex;align-items:center;flex:1 0 0;overflow:hidden;background-color:transparent;color:var(--components-form-field-content-text);padding:var(--form-field-padding-y) var(--form-field-padding-x);font-size:var(--form-field-font-size);font-style:normal;font-weight:500;line-height:var(--form-field-line-height)}nv-fielddropdown .input-container input:focus,nv-fielddropdown .input-container p.non-filterable-text:focus{outline:none}nv-fielddropdown .input-container input::placeholder,nv-fielddropdown .input-container p.non-filterable-text::placeholder{overflow:hidden;color:var(--components-form-field-content-placeholder);text-overflow:ellipsis;font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-field-font-size);font-style:normal;font-weight:400;line-height:var(--form-field-line-height)}nv-fielddropdown .input-container>nv-iconbutton{border:0px;border-radius:0px}nv-fielddropdown .input-container>nv-iconbutton:focus-visible{border-radius:var(--button-md-border-radius);outline-offset:-3px}nv-fielddropdown .input-container nv-icon.validation{color:var(--nv-field-border-default)}nv-fielddropdown .non-filterable-text{display:block;border-radius:var(--form-field-radius);background-color:var(--nv-field-background);color:var(--components-form-field-content-text);font-size:var(--form-field-font-size);font-weight:500;line-height:var(--form-field-line-height);box-sizing:border-box;cursor:pointer;height:100%;min-height:40px}nv-fielddropdown .non-filterable-text span{display:inline-block;width:100%;overflow:hidden;text-overflow:ellipsis}nv-fielddropdown .description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;line-height:var(--form-description-line-height)}nv-fielddropdown .error-description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;line-height:var(--form-description-line-height);color:var(--components-form-text-description-error)}";
    const NvFielddropdownStyle0 = nvFielddropdownCss;

    const NvFielddropdown = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.valueChanged = index.createEvent(this, "valueChanged");
            this.dropdownItemSelected = index.createEvent(this, "dropdownItemSelected");
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Sets the ID for the input element and the for attribute of the associated
             * label. If no ID is provided, a random one will be automatically generated
             * to ensure unique identification, facilitating proper label association and
             * accessibility.
             */
            this.inputId = v4A79185f4.v4();
            /**
             * State of the dropdown popover.
             */
            this.open = false;
            /**
             * The autocomplete prop helps users fill out the input field faster by
             * suggesting entries they've used before, like their email or address.
             * You can turn it on to make forms more convenient or off to ensure users
             * always type in fresh data.
             */
            this.autocomplete = 'off';
            /**
             * Marks the input field as required, ensuring that the user must fill it out
             * before submitting the form.
             */
            this.required = false;
            /**
             * Alters the input field's appearance to indicate an error, helping users
             * identify fields that need correction.
             * @validator error
             */
            this.error = false;
            /**
             * Display the input field's content without allowing users to change it.
             * Users can still click on it, select, and copy the text, but they won't be
             * able to type or delete anything.
             */
            this.readonly = false;
            /**
             * The disabled prop lets you turn off the input field so that users can't
             * type in it. When disabled, the field is grayed out and won't respond to
             * clicks or touches.
             */
            this.disabled = false;
            /**
             * The text to display when no items match the filter.
             */
            this.emptyResult = 'No results found';
            /**
             * Enables or disables the filtering feature for the dropdown items.
             */
            this.filterable = false;
            /**
             * Applies focus to the input field as soon as the component is mounted. This
             * is equivalent to setting the native autofocus attribute on an <input>
             * element.
             */
            this.autofocus = false;
            //#endregion PROPERTIES
            /****************************************************************************/
            //#region STATE
            /** The text entered by the user for filtering dropdown items. */
            this.filterText = '';
            this.selectedValues = new Set();
            this.handleInputContainerClick = (event) => {
                if (this.disabled || this.readonly) {
                    return;
                }
                const target = event.target;
                if (target.tagName === 'P' || target.tagName === 'SPAN') {
                    this.open = true;
                    // Simulate focus to trigger "focus-within" style
                    const inputContainer = this.el.querySelector('.input-container');
                    if (inputContainer) {
                        inputContainer.classList.add('focus-within');
                        // Remove the "focus-within" class after a delay or when the popover is closed
                        const removeFocusWithin = () => {
                            inputContainer.classList.remove('focus-within');
                        };
                        // Or remove the class when the popover is closed
                        this.popoverElement.addEventListener('hide', removeFocusWithin);
                    }
                }
            };
            this.handleInput = (event) => {
                if (!this.filterable)
                    return;
                if (this.disabled || this.readonly) {
                    return;
                }
                const input = event.target;
                this.open = true;
                this.filterText = input.value.toLowerCase();
                this.filterItems();
            };
            this.handleInputFocus = () => {
                if (this.disabled || this.readonly)
                    return;
                this.open = true;
            };
            this.togglePopover = () => {
                if (this.disabled || this.readonly)
                    return;
                this.open = !this.open;
            };
            this.getSelectedLabel = () => {
                var _a, _b, _c, _d, _e, _f;
                if (!this.value)
                    return '';
                if (((_a = this.options) === null || _a === void 0 ? void 0 : _a.length) > 1) {
                    const matchingItem = this.options.find(option => option.value === this.value);
                    return (_c = (_b = matchingItem === null || matchingItem === void 0 ? void 0 : matchingItem.label) !== null && _b !== void 0 ? _b : matchingItem === null || matchingItem === void 0 ? void 0 : matchingItem.value) !== null && _c !== void 0 ? _c : this.value;
                }
                const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitem'));
                const matchingItem = items.find(item => item.value === this.value);
                const selectedLabel = matchingItem
                    ? (_f = (_d = matchingItem.label) !== null && _d !== void 0 ? _d : (_e = matchingItem.textContent) === null || _e === void 0 ? void 0 : _e.trim()) !== null && _f !== void 0 ? _f : matchingItem.value
                    : '';
                return selectedLabel;
            };
            this.clearFilter = () => {
                if (!this.filterable)
                    return;
                this.filterText = '';
                this.inputElement.value = this.getSelectedLabel();
                this.inputElement.focus();
                this.filterItems();
            };
        }
        handleDropdownItemSelected(event) {
            if (this.disabled || this.readonly)
                return;
            const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitem'));
            items.forEach(item => {
                if (item !== event.target) {
                    item.removeAttribute('selected');
                }
                else {
                    item.setAttribute('selected', 'true');
                }
            });
            this.clearFilter();
            this.value = event.detail.value;
            this.open = false;
        }
        handleOpenChanged(event) {
            this.open = event.detail; // Update `open` based on the popover state
        }
        watchValueHandler(newValue) {
            this.valueChanged.emit(newValue);
        }
        handleOptionsChange(newValue) {
            var _a;
            if (!newValue)
                return;
            if (!this.value) {
                const defaultValue = newValue.find(option => option.selected);
                this.value = (_a = defaultValue === null || defaultValue === void 0 ? void 0 : defaultValue.value) !== null && _a !== void 0 ? _a : '';
                this.updateSelectedItem(this.value);
            }
        }
        handleBlur(event) {
            const target = event.relatedTarget;
            if (!(target instanceof Node) || !this.el.contains(target)) {
                this.open = false;
                if (this.inputElement) {
                    this.filterText = '';
                    this.inputElement.value = this.getSelectedLabel();
                    setTimeout(() => {
                        this.filterItems();
                    }, 200);
                }
            }
        }
        handleKeyDown(event) {
            if (!this.el)
                return;
            if (!this.open) {
                if (event.key === 'ArrowDown') {
                    this.open = true;
                    event.preventDefault();
                    return;
                }
                return;
            }
            const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitem:not([disabled]):not([hidden])'));
            let currentIndex = items.findIndex(item => item.classList.contains('highlighted'));
            if (event.key === 'ArrowDown') {
                event.preventDefault();
                currentIndex = (currentIndex + 1) % items.length;
                this.updateHighlightedItem(items, currentIndex);
            }
            else if (event.key === 'ArrowUp') {
                event.preventDefault();
                currentIndex = (currentIndex - 1 + items.length) % items.length;
                this.updateHighlightedItem(items, currentIndex);
            }
            else if (event.key === 'Escape') {
                event.preventDefault();
                this.open = false;
            }
        }
        //#endregion EVENTS
        /****************************************************************************/
        //#region METHODS
        /**
         * Retrieves the current filter text entered by the user.
         * @returns {string} The filter text.
         */
        async getFilterText() {
            return this.filterText;
        }
        /**
         * Filter dropdown items based on the text entered by the user.
         * If no items are found, display a message indicating no results.
         */
        filterItems() {
            var _a;
            const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitem'));
            // Remove the "no results found" item if it exists
            const existingEmptyItem = this.el.querySelector('nv-fielddropdownitem[data-empty]');
            if (existingEmptyItem) {
                existingEmptyItem.remove();
            }
            let hasVisibleItems = false;
            // Iterate over all items and adjust their visibility
            items.forEach(item => {
                var _a, _b;
                const textContent = ((_a = item.textContent) === null || _a === void 0 ? void 0 : _a.toLowerCase()) || ''; // Get the textual content of the slot
                const value = ((_b = item.value) === null || _b === void 0 ? void 0 : _b.toLowerCase()) || ''; // Get the value of the `value` attribute
                // Check if the filtered text is present either in the value or in the textual content
                const shouldShow = value.includes(this.filterText) ||
                    textContent.includes(this.filterText);
                if (shouldShow)
                    item.removeAttribute('hidden');
                else
                    item.setAttribute('hidden', '');
                if (shouldShow) {
                    hasVisibleItems = true;
                }
            });
            // If no items are visible, add the "no results found" item
            if (!hasVisibleItems) {
                const emptyItem = document.createElement('nv-fielddropdownitem');
                emptyItem.setAttribute('data-empty', 'true');
                emptyItem.setAttribute('disabled', 'true');
                emptyItem.textContent = this.emptyResult;
                (_a = this.el.querySelector('ul[slot="content"]')) === null || _a === void 0 ? void 0 : _a.appendChild(emptyItem);
            }
        }
        /** Reset the filter and make all items visible. */
        resetFilter() {
            const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitem'));
            items.forEach(item => {
                item.style.display = '';
            });
        }
        updateHighlightedItem(items, index) {
            items.forEach((item, i) => {
                if (i === index) {
                    item.classList.add('highlighted');
                    item.focus();
                    item.scrollIntoView({ block: 'nearest' });
                }
                else {
                    item.classList.remove('highlighted');
                }
            });
        }
        updateSelectedItem(value) {
            if (!value)
                return;
            const items = Array.from(this.el.querySelectorAll('nv-fielddropdownitem'));
            const matchingItem = items.find(item => {
                var _a;
                const itemLabel = item.getAttribute('label');
                const itemValue = item.getAttribute('value');
                const itemText = (_a = item.textContent) === null || _a === void 0 ? void 0 : _a.trim();
                return itemLabel === value || itemValue === value || itemText === value;
            });
            items.forEach(item => {
                if (item === matchingItem) {
                    item.setAttribute('selected', '');
                }
                else {
                    item.removeAttribute('selected');
                }
            });
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillLoad() {
            this.resetFilter();
            if (this.filterable && this.filterText) {
                this.filterItems();
            }
            if (this.options) {
                this.handleOptionsChange(this.options);
            }
        }
        componentDidLoad() {
            if (this.value) {
                this.updateSelectedItem(this.value);
            }
            if (this.inputElement) {
                this.inputElement.value = this.getSelectedLabel();
            }
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDER
        render() {
            var _a;
            return (index.h(index.Host, { key: '6c23d4cfd361e1f40a2181db66692eb0d6326bfe', role: "combobox", "aria-expanded": this.open.toString(), "aria-haspopup": "listbox", "aria-label": this.label }, (this.label || this.el.querySelector('[slot="label"]')) && (index.h("label", { key: 'db9a30ece9e669c70b18193b3cc7d14967a5e071', htmlFor: this.inputId }, index.h("slot", { key: 'b7a721b25b82646d34ce141526775f24a9849f4b', name: "label" }, this.label))), index.h("nv-popover", { key: '724756cb69b4b6ef8837e6f7f53a65eb42a43b5e', ref: el => (this.popoverElement = el), triggerMode: "controlled", placement: "bottom-start", open: this.open }, index.h("div", { key: '0092cd2b78234ec2e0cdc70433246a2985b7e57f', class: "input-wrapper", slot: "trigger" }, index.h("slot", { key: '519c1a407c8309861673b9eadb723edb0c70ae68', name: "before-input" }), index.h("div", { key: 'd88af43846337d9bfd6aeb4f28ab2dc7e56de4e8', class: "input-container", onClick: this.handleInputContainerClick }, index.h("slot", { key: '8e91459d89acbf7a1cde5e75c520b11b109e810d', name: "leading-input" }), this.filterable || this.disabled || this.readonly ? (index.h("input", { "data-scope": "focusable", id: this.inputId, type: "search", ref: e => (this.inputElement = e), autofocus: this.autofocus, autocomplete: this.autocomplete, placeholder: this.placeholder, name: this.name, value: this.getSelectedLabel(), required: this.required, disabled: this.disabled, readOnly: this.readonly, onInput: this.handleInput, onFocus: this.handleInputFocus, onClick: this.handleInputFocus, onKeyDown: this.handleKeyDown })) : (index.h("p", { "data-scope": "focusable", id: this.inputId, class: "non-filterable-text", onClick: this.handleInputContainerClick, tabIndex: this.disabled ? -1 : 0, onKeyDown: this.handleKeyDown, onFocus: this.handleInputFocus }, this.getSelectedLabel() || this.value || this.placeholder)), this.filterable && this.filterText && this.open && (index.h("nv-iconbutton", { key: '55efb1100997af6b9b4ee41c489a9e628d36b749', name: "x", size: "md", emphasis: "lower", class: "clear-button", onClick: this.clearFilter, "aria-label": "Clear input" })), this.error && (index.h("nv-icon", { key: '69cfcac7b21d0e9faf9bad7f306bab187a761758', name: "alert-circle", class: "validation", size: "md" })), index.h("nv-iconbutton", { key: '5b773edca6a5028eb8cedb42632a9c5b6e8b3d36', "data-scope": "toggle-dropdown", name: this.open ? 'chevron-top' : 'chevron-down', size: "md", emphasis: "lower", "aria-label": this.open ? 'Hide dropdown' : 'Show dropdown', "aria-pressed": this.open.toString(), onClick: this.togglePopover, tabIndex: this.disabled ? -1 : 0 })), index.h("slot", { key: 'c225279e1ec938e2fbe672ce02e8d2a79cb7ff1e', name: "after-input" })), index.h("div", { key: '94905d2f6a0b7faae17540139c0bd2458e4c98ae', slot: "content" }, ((_a = this.options) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (index.h("ul", null, this.options.map(option => (index.h("nv-fielddropdownitem", { label: option.label, value: option.value, disabled: option.disabled, selected: option.value === this.value }))))) : (index.h("slot", { name: "content" })))), (this.description ||
                this.el.querySelector('[slot="description"]')) && (index.h("div", { key: '5d0b74de616aefa056d17cb70fab0d36ab9b41c3', class: "description" }, index.h("slot", { key: 'bab9d8222164d2227c6024ac2bd5675142ccb964', name: "description" }, this.description))), (this.errorDescription ||
                this.el.querySelector('[slot="error-description"]')) && (index.h("div", { key: '58596e0c753e8bb90f9d21432607427b0a029d64', hidden: !this.error, class: "error-description" }, index.h("slot", { key: '6062d632aee6e825cd2d17a22180cb24d66e2864', name: "error-description" }, this.errorDescription)))));
        }
        static get formAssociated() { return true; }
        get el() { return index.getElement(this); }
        static get watchers() { return {
            "value": ["watchValueHandler"],
            "options": ["handleOptionsChange"]
        }; }
    };
    NvFielddropdown.style = NvFielddropdownStyle0;

    exports.nv_fielddropdown = NvFielddropdown;

}));
