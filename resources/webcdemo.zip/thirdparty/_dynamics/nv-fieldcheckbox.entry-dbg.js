sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/clsx-297c1ffe', 'be/wl/webc/demo/thirdparty/v4-a79185f4'], (function (exports, index, clsx297c1ffe, v4A79185f4) { 'use strict';

    const nvFieldcheckboxCss = "nv-fieldcheckbox{--nv-fieldcheckbox-border-default:var(\n    --components-form-field-border-default\n  );--nv-fieldcheckbox-border-hover:var(--components-form-field-border-hover);--nv-fieldcheckbox-border-focus:var(--components-form-field-border-default);--nv-fieldcheckbox-background-default:var(\n    --components-form-field-background-default\n  );--nv-fieldcheckbox-background-checked:var(\n    --components-form-field-background-checked\n  );--nv-fieldcheckbox-background-disabled:var(\n    --components-form-field-background-disabled\n  );--nv-fieldcheckbox-focus-box-shadow:var(--color-focus-brand);--nv-fieldcheckbox-color-checked:var(\n    --components-form-shape-foreground-default\n  );--nv-fieldcheckbox-color-disabled:var(\n    --components-form-shape-foreground-disabled\n  );--nv-fieldcheckbox-outline-color:var(--color-focus-brand);display:inline-flex;align-items:flex-start;gap:var(--form-gap-x);position:relative}nv-fieldcheckbox:not([disabled],[readonly]) input,nv-fieldcheckbox:not([disabled],[readonly]) label{cursor:pointer}nv-fieldcheckbox.error>.input-container{--nv-fieldcheckbox-border-default:var(--components-form-field-border-error);--nv-fieldcheckbox-border-hover:var(--nv-fieldcheckbox-border-default);--nv-fieldcheckbox-border-focus:var(--components-form-field-border-error);--nv-fieldcheckbox-focus-box-shadow:var(--color-focus-destructive);--nv-fieldcheckbox-color-disabled:var(\n    --components-form-shape-foreground-disabled-error\n  );--nv-fieldcheckbox-background-checked:var(\n    --components-form-field-background-error\n  );--nv-fieldcheckbox-outline-color:var(--color-focus-destructive)}nv-fieldcheckbox.label-placement-before{flex-direction:row-reverse}nv-fieldcheckbox[disabled]:not([disabled=false]){opacity:0.5}nv-fieldcheckbox>.input-container{position:relative;color:var(--nv-fieldcheckbox-color-checked)}nv-fieldcheckbox>.input-container input[type=checkbox][readonly]{opacity:0.5}nv-fieldcheckbox>.input-container:has(input[type=checkbox]:disabled:not([readonly])){color:var(--nv-fieldcheckbox-color-disabled)}nv-fieldcheckbox>.input-container input[type=checkbox]{appearance:none;position:relative;display:flex;width:var(--form-checkbox-size);height:var(--form-checkbox-size);flex-direction:column;align-items:flex-start;border-radius:var(--form-checkbox-radius);border-width:var(--form-checkbox-border-width);border-style:solid;border-color:var(--nv-fieldcheckbox-border-default);background:var(--nv-fieldcheckbox-background-default)}nv-fieldcheckbox>.input-container input[type=checkbox]:hover{border-color:var(--nv-fieldcheckbox-border-hover)}nv-fieldcheckbox>.input-container input[type=checkbox]:focus{border-color:var(--nv-fieldcheckbox-border-focus)}nv-fieldcheckbox>.input-container input[type=checkbox]:focus,nv-fieldcheckbox>.input-container input[type=checkbox]:focus-within{outline:none}nv-fieldcheckbox>.input-container input[type=checkbox]:focus-visible,nv-fieldcheckbox>.input-container input[type=checkbox]:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--nv-fieldcheckbox-outline-color);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-fieldcheckbox>.input-container input[type=checkbox]:checked,nv-fieldcheckbox>.input-container input[type=checkbox]:indeterminate{background:var(--nv-fieldcheckbox-background-checked);border-color:var(--nv-fieldcheckbox-background-checked)}nv-fieldcheckbox>.input-container input[type=checkbox]:disabled:not([readonly]){background:var(--nv-fieldcheckbox-background-disabled);border-color:var(--nv-fieldcheckbox-border-default)}nv-fieldcheckbox>.input-container input[type=checkbox][readonly]{opacity:0.5}nv-fieldcheckbox>.input-container .icon{pointer-events:none;position:absolute;top:0;left:0;width:100%;height:100%;display:flex;justify-content:center;align-items:center}nv-fieldcheckbox>.input-container .icon svg{width:var(--form-checkbox-icon-size);height:var(--form-checkbox-icon-size);fill:none;stroke:currentcolor;stroke-width:var(--form-checkbox-icon-stroke);flex-shrink:0}nv-fieldcheckbox>.text-container{display:flex;flex-direction:column;align-items:flex-start;flex:1 0 0}nv-fieldcheckbox>.text-container label{align-self:stretch;color:var(--components-form-text-label-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-label-font-size);font-style:normal;font-weight:var(--form-label-font-weight);line-height:var(--form-label-line-height)}nv-fieldcheckbox>.text-container label.visually-hidden{position:absolute;padding:0;border:0;overflow:hidden;white-space:nowrap;width:1px;height:1px;margin:-1px;clip:rect(0, 0, 0, 0)}nv-fieldcheckbox>.text-container .description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;font-weight:var(--form-description-font-weight);line-height:var(--form-description-line-height)}nv-fieldcheckbox>.text-container .error-description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;font-weight:var(--form-description-font-weight);line-height:var(--form-description-line-height);color:var(--components-form-text-description-error)}";
    const NvFieldcheckboxStyle0 = nvFieldcheckboxCss;

    const NvFieldcheckbox = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.checkedChanged = index.createEvent(this, "checkedChanged");
            /**
             * When true, the label will be placed before the checkbox.
             * @deprecated Use `labelPlacement = end` instead.
             * */
            this.labelBefore = false;
            //#endregion DEPRECATED
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Sets the ID for the radio button’s input element and the for attribute of
             * the associated label. If no ID is provided, a random one will be
             * automatically generated to ensure unique identification, facilitating
             * proper label association and accessibility.
             */
            this.inputId = v4A79185f4.v4();
            /**
             * Hides the label visually while still keeping it available for screen
             * readers.
             */
            this.hideLabel = false;
            /**
             * Signals that there is an error associated with the checkbox, which can
             * trigger visual cues.
             * @validator error
             */
            this.error = false;
            /**
             * Indicates whether the checkbox is checked or not.
             */
            this.checked = false;
            /**
             * Indicates whether the checkbox is in an indeterminate state, typically used
             * for hierarchical checkboxes.
             */
            this.indeterminate = false;
            /**
             * Disables the checkbox, preventing user interaction.
             */
            this.disabled = false;
            /**
             * Sets the checkbox to read-only, preventing user changes but still allowing
             * focus and selection of text.
             */
            this.readonly = false;
            /**
             * Marks the checkbox as required, indicating that it must be checked for
             * form submission.
             */
            this.required = false;
            /**
             * Applies focus to the input field as soon as the component is mounted. This
             * is equivalent to setting the native autofocus attribute on an <input>
             * element.
             */
            this.autofocus = false;
        }
        //#endregion EVENTS
        /****************************************************************************/
        //#region LISTENERS
        /**
         * Listens for the change event on the checkbox input element and updates the
         * checked state.
         * @param {Event} event - The change event.
         */
        handleChange(event) {
            const target = event.target;
            if (target.type === 'checkbox' && target.id === this.inputId) {
                if (this.readonly || this.disabled) {
                    event.preventDefault();
                    return;
                }
                if (this.indeterminate) {
                    this.indeterminate = false;
                }
                this.checked = target.checked;
            }
        }
        //#endregion LISTENERS
        /****************************************************************************/
        //#region WATCHERS
        /**
         * Watches for changes to the checked state and emits the new value.
         * @param {boolean} checked - The new value of the checked state.
         */
        onCheckedChanged(checked) {
            this.checkedChanged.emit(checked);
        }
        //#endregion WATCHERS
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillRender() {
            if (this.message) {
                this.description = this.message;
            }
            if (this.labelBefore) {
                this.labelPlacement = 'before';
            }
            if (this.validation) {
                this.errorDescription = this.validation;
                this.error = true;
            }
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '98f9dfdadab534193e7076f929c9820a231fecba', class: clsx297c1ffe.clsx(this.labelPlacement === 'before' && 'label-placement-before', this.error && 'error') }, index.h("div", { key: '5a4d02d46b7c8c8930c24f794452180d58604ffe', class: "input-container" }, index.h("input", { key: 'f7a4002a5fb9800ed4036638773ac42c49d4ae0f', type: "checkbox", id: this.inputId, name: this.name, autofocus: this.autofocus, autocomplete: "off", value: this.value, checked: Boolean(this.checked), disabled: this.disabled || this.readonly, readonly: this.readonly && !this.required, required: this.required, indeterminate: this.indeterminate, ref: el => {
                    if (el) {
                        el.indeterminate = this.indeterminate;
                    }
                } }), index.h("span", { key: '56a2547ecf96ef3f7f28054592471323497cb94f', class: "icon" }, this.checked && !this.indeterminate && (index.h("slot", { key: 'af4e10bd52b42850c8348e0aed8c90a7e700d64a', name: "checked-icon" }, index.h("svg", { key: '105847f526c391566cef42fa35d94fbaba0e8984', xmlns: "http://www.w3.org/2000/svg", width: "14", height: "14", viewBox: "0 0 14 14", fill: "none" }, index.h("path", { key: '41e221d5f3eab7a4cc88d4ed9454f198d69ec815', d: "M11.6667 3.5L5.25004 9.91667L2.33337 7", "stroke-linecap": "round", "stroke-linejoin": "round" })))), this.indeterminate && (index.h("slot", { key: '3a1f5ffdc34a1ecdc1bb7f1b5347e1f12f5f690d', name: "indeterminate-icon" }, index.h("svg", { key: '1b68c27172d5b6b9ba2419d278c0ac0299d7a4b7', class: "indeterminate-svg", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 14 14", fill: "none" }, index.h("path", { key: '7b2f4e5fe1d961fad290aade639b9807446f34ba', d: "M2.9165 7H11.0832", "stroke-linecap": "round", "stroke-linejoin": "round" })))))), index.h("div", { key: 'd472d7d8901ff7de37fe370bf5d637fc8ae6069d', class: "text-container" }, (this.label || this.el.querySelector('[slot="label"]')) && (index.h("label", { key: 'c8dbda4d6f9cb757476c9a96934599171f6ea7ae', htmlFor: this.inputId, class: clsx297c1ffe.clsx(this.hideLabel && 'visually-hidden') }, index.h("slot", { key: '3c0ec17aeb856457b63981fd0e21ead69ca3af0f', name: "label" }, this.label))), (this.description ||
                this.el.querySelector('[slot="description"]')) && (index.h("div", { key: 'dff6c3a69496324cabcf25ae7639c98a7d908769', class: "description" }, index.h("slot", { key: '498c8216c9a0a537f1aa2a542b3caa688b76e55d', name: "description" }, this.description))), (this.errorDescription ||
                this.el.querySelector('[slot="error-description"]')) && (index.h("div", { key: '6c584da0ad93e7f0ad62610d760c36d77b1a6fc6', hidden: !this.error, class: "error-description" }, index.h("slot", { key: '93df382e666707cdde3133daae7aa66914215149', name: "error-description" }, this.errorDescription))))));
        }
        static get formAssociated() { return true; }
        get el() { return index.getElement(this); }
        static get watchers() { return {
            "checked": ["onCheckedChanged"]
        }; }
    };
    NvFieldcheckbox.style = NvFieldcheckboxStyle0;

    exports.nv_fieldcheckbox = NvFieldcheckbox;

}));
