sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/clsx-297c1ffe', 'be/wl/webc/demo/thirdparty/v4-a79185f4'], (function (exports, index, clsx297c1ffe, v4A79185f4) { 'use strict';

    const nvToggleCss = "nv-toggle{display:inline-flex;align-items:flex-start;gap:var(--form-gap-x);position:relative}nv-toggle:not([disabled],[readonly]) input,nv-toggle:not([disabled],[readonly]) label{cursor:pointer}nv-toggle.label-placement-before{flex-direction:row-reverse}nv-toggle[disabled]{opacity:0.5}nv-toggle label{align-self:stretch;color:var(--components-form-text-label-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-label-font-size);font-style:normal;font-weight:500;line-height:var(--form-label-line-height)}nv-toggle label.visually-hidden{position:absolute;padding:0;border:0;overflow:hidden;white-space:nowrap;width:1px;height:1px;margin:-1px;clip:rect(0, 0, 0, 0)}nv-toggle .input-container{position:relative;color:var(--components-form-shape-foreground-default)}nv-toggle .input-container:has(input[type=checkbox]:disabled:not([readonly])){color:var(--components-form-shape-foreground-disabled)}nv-toggle .input-container input[type=checkbox]{appearance:none;position:relative;display:flex;width:var(--form-toggle-width);height:var(--form-toggle-height);flex-direction:column;align-items:flex-start;border-radius:var(--form-toggle-radius);border-width:var(--form-toggle-border-width);border-style:solid;border-color:var(--components-form-field-border-default);background:var(--components-form-field-background-default)}nv-toggle .input-container input[type=checkbox]::after{content:\"\";display:block;width:var(--form-toggle-switch-dot-default);height:var(--form-toggle-switch-dot-default);background-color:var(--components-form-shape-foreground-switch-dot);border-radius:var(--radius-rounded-full);position:absolute;top:50%;left:25%;transform:translate(-50%, -50%)}nv-toggle .input-container input[type=checkbox]:hover{border-color:var(--components-form-field-border-hover)}nv-toggle .input-container input[type=checkbox]:focus{border-color:var(--components-form-field-border-default)}nv-toggle .input-container input[type=checkbox]:focus,nv-toggle .input-container input[type=checkbox]:focus-within{outline:none}nv-toggle .input-container input[type=checkbox]:focus-visible,nv-toggle .input-container input[type=checkbox]:has(:focus-visible){outline:calc(var(--focus-outline-stroke) * 1) solid var(--color-focus-brand);outline-offset:calc(var(--focus-outline-offset) * 1)}nv-toggle .input-container input[type=checkbox]:checked{background:var(--components-form-field-background-checked);border-color:var(--components-form-field-background-checked)}nv-toggle .input-container input[type=checkbox]:checked::after{content:\"\";display:block;width:var(--form-toggle-switch-dot-default);height:var(--form-toggle-switch-dot-default);background-color:var(--components-form-shape-foreground-default);border-radius:var(--radius-rounded-full);position:absolute;top:50%;left:75%;transform:translate(-50%, -50%)}nv-toggle .input-container input[type=checkbox]:checked:focus{background:var(--components-form-field-background-checked);border-color:var(--components-form-field-border-focus)}nv-toggle .input-container input[type=checkbox]:disabled:not([readonly]){box-shadow:unset;background:var(--components-form-field-background-disabled);border-color:var(--components-form-field-border-default)}nv-toggle .input-container input[type=checkbox]:disabled:not([readonly]):checked::after{background-color:var(--components-form-shape-foreground-disabled)}nv-toggle .description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;font-weight:450;line-height:var(--form-description-line-height)}nv-toggle .text-container{display:flex;flex-direction:column;align-items:flex-start;flex:1 0 0}";
    const NvToggleStyle0 = nvToggleCss;

    const NvToggle = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.checkedChanged = index.createEvent(this, "checkedChanged");
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Sets the ID for the radio button’s input element and the for attribute of
             * the associated label. If no ID is provided, a random one will be
             * automatically generated to ensure unique identification, facilitating
             * proper label association and accessibility.
             */
            this.inputId = v4A79185f4.v4();
            /**
             * Hides the label visually while still keeping it available for screen
             * readers.
             */
            this.hideLabel = false;
            /** Indicates whether the toggle is checked or not. */
            this.checked = false;
            /** Disables the toggle, preventing user interaction. */
            this.disabled = false;
            /**
             * Sets the toggle to read-only, preventing user changes but still allowing
             * focus and selection of text.
             */
            this.readonly = false;
        }
        //#endregion EVENTS
        /****************************************************************************/
        //#region WATCHERS
        /**
         * Watches for changes to the checked state and emits the new value.
         * @param {boolean} checked - The new value of the checked state.
         */
        onCheckedChanged(checked) {
            this.checkedChanged.emit(checked);
        }
        /**
         * Listens for the change event on the toggle input element and updates the checked state.
         * the checked state of the host elements.
         * @param {Event} event - The change event.
         */
        handleChange(event) {
            const target = event.target;
            if (target.type === 'checkbox' && target.id === this.inputId) {
                if (this.readonly || this.disabled) {
                    event.preventDefault();
                    return;
                }
                this.checked = target.checked;
            }
        }
        //#endregion WATCHERS
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: 'e80390a43bab3d55373f6b05db1516210f90c3b5', class: clsx297c1ffe.clsx(this.labelPlacement === 'before' && 'label-placement-before') }, index.h("div", { key: '66156f05cc18bb63a8625cdff72d9c177e4cf86b', class: "input-container" }, index.h("input", { key: 'db0c2c078c23431605befb8dd972a29bfdefb16f', type: "checkbox", id: this.inputId, name: this.name, autocomplete: "off", value: this.value, checked: Boolean(this.checked), disabled: this.disabled || this.readonly, readonly: this.readonly })), index.h("div", { key: '576df464b48fa11bf8a46bede5f1d822db569636', class: "text-container" }, (this.label || this.el.querySelector('[slot="label"]')) && (index.h("label", { key: 'f529b009876a5de5061747f78372a66ccfdcac61', htmlFor: this.inputId, class: clsx297c1ffe.clsx(this.hideLabel && 'visually-hidden') }, index.h("slot", { key: '3ace029242d920b783fe0038f8721b416f54633f', name: "label" }, this.label))), (this.description ||
                this.el.querySelector('[slot="description"]')) && (index.h("div", { key: '2eeb41266ee52ef40c1600750084fda0fac8dc6f', class: "description" }, index.h("slot", { key: '605541594fcc7f3192766a5395c5a81f42de7728', name: "description" }, this.description))))));
        }
        static get formAssociated() { return true; }
        get el() { return index.getElement(this); }
        static get watchers() { return {
            "checked": ["onCheckedChanged"]
        }; }
    };
    NvToggle.style = NvToggleStyle0;

    exports.nv_toggle = NvToggle;

}));
