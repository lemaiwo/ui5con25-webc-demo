sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2'], (function (exports, index) { 'use strict';

    const nvRowCss = "nv-row{display:flex;flex-wrap:wrap;margin-right:calc(var(--spacing-4) * -1);margin-left:calc(var(--spacing-4) * -1);row-gap:var(--spacing-4)}";
    const NvRowStyle0 = nvRowCss;

    const NvRow = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
        }
        /****************************************************************************/
        //#region RENDER
        render() {
            return (index.h(index.Host, { key: '7daaa109808165553e69707c72550f284e087011' }, index.h("slot", { key: 'a00fd8c81352b485d8508f9bd68af4dd81d959e1' })));
        }
    };
    NvRow.style = NvRowStyle0;

    exports.nv_row = NvRow;

}));
