sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2', 'be/wl/webc/demo/thirdparty/v4-a79185f4'], (function (exports, index, v4A79185f4) { 'use strict';

    const nvFieldselectCss = "nv-fieldselect{--nv-field-border-default:var(--components-form-field-border-default);--nv-field-border-hover:var(--components-form-field-border-hover);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--components-form-field-border-default);--nv-field-border-readonly:var(--components-form-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-brand);--nv-field-background:var(--components-form-field-background-default);display:flex;flex-direction:column;align-items:flex-start;gap:var(--form-gap-y);box-sizing:border-box}nv-fieldselect[readonly]:not([readonly=false]){--nv-field-border-default:var(--components-form-field-border-readonly);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-background:var(--components-form-field-background-readonly)}nv-fieldselect[display-value]:not([display-value=false]){--nv-field-border-default:var(--components-form-field-border-readonly);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--components-form-field-border-focus);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-background:var(--components-form-field-background-readonly)}nv-fieldselect[error]:not([error=false]){--nv-field-border-default:var(--components-form-field-border-error);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--nv-field-border-default);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-destructive)}nv-fieldselect[success]:not([success=false]){--nv-field-border-default:var(--components-form-field-border-success);--nv-field-border-hover:var(--nv-field-border-default);--nv-field-border-focus:var(--nv-field-border-default);--nv-field-border-disabled:var(--nv-field-border-default);--nv-field-border-readonly:var(--nv-field-border-default);--nv-field-focus-box-shadow:var(--color-focus-success)}nv-fieldselect[required]:not([required=false]) label::after{content:\"*\";color:var(--components-form-text-required);font-weight:700}nv-fieldselect[multiple]:not([multiple=false]) .select-wrapper>.select-container>.select-icons{top:var(--form-field-padding-y);right:var(--form-field-padding-x)}nv-fieldselect[multiple]:not([multiple=false]) .select-wrapper>.select-container>select{height:100%;box-sizing:border-box}nv-fieldselect label{display:flex;align-items:center;gap:var(--form-label-gap);align-self:stretch;color:var(--components-form-text-label-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-label-font-size);font-style:normal;font-weight:500;line-height:var(--form-label-line-height)}nv-fieldselect .select-wrapper{display:flex;flex-wrap:wrap;align-items:stretch;align-self:stretch}nv-fieldselect .select-wrapper .select-container{position:relative;display:flex;flex-grow:1;justify-content:center;align-items:center;align-self:stretch;border-radius:var(--form-field-radius);border-width:1px;border-style:solid;border-color:var(--nv-field-border-default);opacity:var(--components-form-opacity-default);background:var(--nv-field-background);transition:all 150ms ease-out}nv-fieldselect .select-wrapper .select-container:hover{border-color:var(--nv-field-border-hover)}nv-fieldselect .select-wrapper .select-container:focus-within{border-color:var(--nv-field-border-focus);box-shadow:0 0 0 var(--focus-field-stroke) var(--nv-field-focus-box-shadow)}nv-fieldselect .select-wrapper .select-container:has(select:disabled){opacity:0.5;background-color:var(--components-form-field-background-disabled);border-color:var(--nv-field-border-disabled)}nv-fieldselect .select-wrapper .select-container>.select-icons{position:absolute;right:0;top:0;pointer-events:none}nv-fieldselect .select-wrapper .select-container>.select-icons>nv-iconbutton{border:0px;border-radius:0px}nv-fieldselect .select-wrapper .select-container>.select-icons>nv-iconbutton:focus-visible{border-radius:var(--button-md-border-radius);outline-offset:-3px}nv-fieldselect .select-wrapper .select-container input{display:flex;align-items:center;flex:1 0 0;overflow:hidden;background-color:transparent;color:var(--components-form-field-content-text);padding:var(--form-field-padding-y) var(--form-field-padding-x);font-size:var(--form-field-font-size);font-style:normal;font-weight:500;line-height:var(--form-field-line-height)}nv-fieldselect .select-wrapper .select-container input:focus{outline:none}nv-fieldselect .select-wrapper .select-container input::placeholder{overflow:hidden;color:var(--components-form-field-content-placeholder);text-overflow:ellipsis;font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-field-font-size);font-style:normal;font-weight:400;line-height:var(--form-field-line-height)}nv-fieldselect .select-wrapper .select-container input:read-only{opacity:0.5;background-color:var(--components-form-field-background-readonly, rgba(0, 0, 0, 0.1));border-color:var(--nv-field-border-readonly)}nv-fieldselect .select-wrapper .select-container select{display:flex;align-items:center;flex:1 0 0;overflow:hidden;background-color:transparent;color:var(--components-form-field-content-text);text-overflow:ellipsis;font-size:var(--form-field-font-size);font-style:normal;font-weight:500;height:var(--form-field-line-height);padding:var(--form-field-padding-y) var(--form-field-padding-x);box-sizing:content-box;-webkit-appearance:none;-moz-appearance:none;cursor:pointer}nv-fieldselect .select-wrapper .select-container select:focus{outline:none}nv-fieldselect .select-wrapper .select-container select::placeholder{overflow:hidden;color:var(--components-form-field-content-placeholder);text-overflow:ellipsis;font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-field-font-size);font-style:normal;font-weight:400;line-height:var(--form-field-line-height)}nv-fieldselect .select-wrapper .select-container select option{font-size:var(--form-field-font-size, 16px);font-style:normal;font-weight:500;line-height:var(--form-field-line-height, 24px)}nv-fieldselect .select-wrapper .select-container select.hidden{display:none}nv-fieldselect .select-wrapper .select-container nv-icon.readonly-icon{color:var(--nv-field-border-default)}nv-fieldselect .select-wrapper .select-container nv-icon.validation{color:var(--nv-field-border-default)}nv-fieldselect .description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;line-height:var(--form-description-line-height)}nv-fieldselect .error-description{align-self:stretch;color:var(--components-form-text-description-default);font-family:\"TT Norms Pro\", sans-serif;font-size:var(--form-description-font-size);font-style:normal;line-height:var(--form-description-line-height);color:var(--components-form-text-description-error)}";
    const NvFieldselectStyle0 = nvFieldselectCss;

    const NvFieldselect = class {
        constructor(hostRef) {
            index.registerInstance(this, hostRef);
            this.valueChanged = index.createEvent(this, "valueChanged");
            //#endregion DEPRECATED
            /****************************************************************************/
            //#region STATES
            this.computedDisplayValue = '';
            this.internalReadonly = false;
            /**
             * Parsed options stored internally
             */
            this.parsedOptions = [];
            //#endregion STATES
            /****************************************************************************/
            //#region PROPERTIES
            /**
             * Sets the ID for the select element and the for attribute of the associated
             * label. If no ID is provided, a random one will be automatically generated
             * to ensure unique identification, facilitating proper label association and
             * accessibility.
             */
            this.inputId = v4A79185f4.v4();
            /**
             * The disabled prop lets you turn off the select field so that users can’t
             * choose something. When disabled, the field is grayed out and won’t respond to
             * clicks or touches.
             */
            this.disabled = false;
            /**
             * Display the select field’s content without allowing users to change it.
             * Users can still click on it, select, and copy the text, but they won’t be
             * able to change or delete anything.
             */
            this.readonly = false;
            /**
             * Marks the select field as required, ensuring that the user must fill it out
             * before submitting the form.
             */
            this.required = false;
            /**
             * Alters the select field’s appearance to indicate an error, helping users
             * identify fields that need correction.
             * @validator error
             */
            this.error = false;
            /**
             * Changes the select field’s appearance to indicate successful input or
             * validation.
             */
            this.success = false;
            /**
             * When enabled, allows the select to handle multiple selections.
             */
            this.multiple = false;
            /**
             * The value of the select field.
             * - If `multiple` is `false`, it's a single string.
             * - If `multiple` is `true`, it's a comma-separated string of selected values.
             */
            this.value = '';
            /**
             * When enabled, displays the value element instead of the label when readonly.
             * By default, the label is displayed in readonly mode. Also it automatically
             * sets the component to readonly.
             */
            this.displayValue = false;
            /**
             * Applies focus to the input field as soon as the component is mounted. This
             * is equivalent to setting the native autofocus attribute on a <select>
             * element.
             */
            this.autofocus = false;
            //#endregion WATCHERS
            /****************************************************************************/
            //#region METHODS
            /**
             * Handles the change event on the select element. This method is used to
             * update the value property when the selected options change. It is also
             * used to emit the selectChanged event when the selected value changes.
             * @param {Event} event - The change event on the select element.
             * @emits selectChanged
             */
            this.handleSelectChange = (event) => {
                const select = event.target;
                let selectedValues = Array.from(select.selectedOptions).map(option => option.value);
                if (!this.multiple) {
                    selectedValues = selectedValues.slice(0, 1);
                }
                this.value = this.multiple
                    ? selectedValues.join(', ')
                    : selectedValues[0] || '';
                this.valueChanged.emit(this.value);
                // Update form value
                this.setFormValue();
            };
            /**
             * Handles focus when the select container is clicked.
             */
            this.handleSelectContainerClick = () => {
                if (!this.internalReadonly && this.selectElement) {
                    this.selectElement.focus();
                }
            };
        }
        //#endregion EVENTS
        /****************************************************************************/
        //#region WATCHERS
        /**
         * Updates the display value when the value property changes. This watcher is
         * used to update the display value when the selected value changes. This is
         * necessary for readonly select fields to display the selected value.
         * @internal This watcher is not intended to be called outside of the component.
         * @param {string} newValue - The new value of the select field.
         */
        updateDisplayValueWatcher(newValue) {
            this.updateDisplayValue();
            if (this.selectElement) {
                const selectedValues = newValue.split(',').map(val => val.trim());
                const options = this.selectElement.options;
                if (options) {
                    Array.from(options).forEach(option => {
                        option.selected = this.multiple
                            ? selectedValues.includes(option.value)
                            : option.value === selectedValues[0];
                    });
                    if (!this.multiple) {
                        this.selectElement.value = newValue; // Only set when not multiple
                    }
                }
                else {
                    this.selectElement.value = selectedValues[0] || '';
                }
            }
            // Update form value
            this.setFormValue();
        }
        /**
         * Watcher for the displayValue prop to ensure internalReadonly is true when displayValue is true.
         * @param {boolean} newValue - The new value of displayValue.
         */
        handleDisplayValueChange(newValue) {
            this.internalReadonly = newValue; // Set internalReadonly to true if displayValue is true
            if (this.readonly) {
                this.internalReadonly = true;
            }
        }
        /**
         * Watcher for the readonly prop to ensure internalReadonly is true when readonly is true.
         * @param {boolean} newValue - The new value of readonly.
         */
        handleReadonlyChange(newValue) {
            this.internalReadonly = newValue; // Set internalReadonly to true if displayValue is true
            if (this.displayValue) {
                this.internalReadonly = true;
            }
        }
        /**
         * Parse options and update the internal state
         * @param {string} newValue - The new value of options
         */
        handleOptionsChange(newValue) {
            if (typeof newValue === 'string') {
                try {
                    const parsedOpts = JSON.parse(newValue);
                    this.parsedOptions = [...parsedOpts];
                    // Update the value if an option is pre-selected
                    const selectedOption = parsedOpts.find(opt => opt.selected);
                    if (selectedOption) {
                        this.value = selectedOption.value;
                    }
                }
                catch (error) {
                    console.error('Error parsing options:', error);
                    this.parsedOptions = [];
                }
            }
        }
        /**
         * Updates the display value of the select field. This method is used to
         * update the display value when the selected value changes. This is necessary
         * for readonly select fields to display the selected value. This method is
         * called in the componentDidLoad lifecycle hook and the updateDisplayValueWatcher
         * watcher.
         * @internal This method is not intended to be called outside of the component.
         */
        updateDisplayValue() {
            if (this.internalReadonly && !this.displayValue) {
                if (this.multiple) {
                    const selectedLabels = this.value
                        .split(',')
                        .map(key => key.trim())
                        .map(key => this.getLabelFromId(key) || '')
                        .filter(label => label !== '');
                    this.computedDisplayValue = selectedLabels.join(', ') || '';
                }
                else {
                    this.computedDisplayValue = this.getLabelFromId(this.value) || '';
                }
            }
            else if (this.internalReadonly && this.displayValue) {
                this.computedDisplayValue = this.value || '';
            }
        }
        /**
         * Retrieves the label from the <option> elements based on the provided key (value).
         * This method uses the id or value attribute directly from the <select> options.
         * @param {string} key - The key (value) for which to find the corresponding label.
         * @returns {string} The label if found; otherwise, an empty string.
         */
        getLabelFromId(key) {
            this.ensureSelectElement();
            if (!this.selectElement) {
                return '';
            }
            // Cache the option list
            const options = this.selectElement.options;
            if (options) {
                const option = Array.from(options).find(option => option.value === key);
                return option ? option.textContent.trim() || '' : '';
            }
            else {
                return '';
            }
        }
        /**
         * Sets the value of the form element for form submission. This method is
         * called when the selected value changes or when the value property is set.
         * @internal This method is not intended to be called outside of the component.
         */
        setFormValue() {
            this.internals.setFormValue(this.value);
        }
        /**
         * Ensures the select element is available. This method is used to ensure
         * the select element is available before attempting to access it.
         * @internal This method is not intended to be called outside of the component.
         */
        ensureSelectElement() {
            if (!this.selectElement) {
                this.selectElement = this.el.querySelector('select');
            }
        }
        //#endregion METHODS
        /****************************************************************************/
        //#region LIFECYCLE
        componentWillRender() {
            this.updateDisplayValue(); // Ensure display value is updated before render
            if (this.message) {
                this.description = this.message;
            }
            if (this.validation) {
                this.errorDescription = this.validation;
                this.error = true;
            }
        }
        /**
         * Lifecycle method that is called before the component is rendered. This is
         * where the internal state is set up before rendering occurs.
         */
        componentWillLoad() {
            // Set internalReadonly based on the readonly prop
            this.internalReadonly = this.readonly;
            // Ensure internalReadonly is true if displayValue is true during loading
            if (this.displayValue) {
                this.internalReadonly = true;
            }
            if ('attachInternals' in this.el) {
                this.internals = this.el.attachInternals();
            }
            else {
                // Fallback logic for browsers without attachInternals support
                this.internals = {
                    setFormValue: (value) => {
                        const formElement = this.el.closest('form');
                        if (formElement) {
                            const input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = this.name;
                            input.value = value;
                            formElement.appendChild(input);
                        }
                    },
                };
            }
            // Initialize value as an empty string if multiple is true
            if (this.multiple && typeof this.value !== 'string') {
                this.value = '';
            }
            // Parse initial options if present
            if (this.options) {
                this.handleOptionsChange(this.options);
            }
        }
        /**
         * Lifecycle method that is called after the component has been rendered.
         * This is where the display value is updated and the initial select element's
         * state is set.
         */
        componentDidLoad() {
            this.updateDisplayValue();
            if (this.selectElement) {
                // Only set the value for single selection, skip for multiple
                if (!this.multiple) {
                    this.selectElement.value = this.value;
                }
                const selectedValues = this.multiple
                    ? this.value.split(',').map(v => v.trim())
                    : [this.value];
                const options = this.selectElement.options;
                if (options) {
                    Array.from(options).forEach(option => {
                        option.selected = this.multiple
                            ? selectedValues.includes(option.value)
                            : option.value === selectedValues[0];
                    });
                }
                else {
                    // Handle case where there are no options
                    this.selectElement.value = selectedValues[0] || '';
                }
            }
            // Set the initial form value
            this.setFormValue();
        }
        //#endregion LIFECYCLE
        /****************************************************************************/
        //#region RENDERING
        /**
         * The render method creates the HTML structure for the component, including
         * the label, select element, and any error or description messages. It also
         * applies the appropriate CSS classes based on the readonly state and
         * displayValue prop. This method is called when the component is rendered.
         * @returns {HTMLStencilElement} The HTML element to render.
         */
        render() {
            return (index.h(index.Host, { key: '38cb85c6698c5541793a1e5d34b36417cd743759' }, (this.label || this.el.querySelector('[slot="label"]')) && (index.h("label", { key: 'd81b9837c43c1a19a2d87b51cede9e7c32bda50c', htmlFor: this.inputId }, index.h("slot", { key: '9d7c10281b117f2006ca1997f91e4e0b99fc5ab5', name: "label" }, this.label))), index.h("div", { key: '2796a31f2aac0604054c4542564fca77c2ac4272', class: "select-wrapper" }, index.h("slot", { key: '0407c6379597b09e1bb11ee6b43110b1d5fb98ea', name: "before-input" }), index.h("div", { key: 'c0ae999fc017fb0352b0a1cfe2ff75e313955f23', class: "select-container", onClick: this.handleSelectContainerClick }, index.h("slot", { key: 'ea2b63ddb3b70521b63e15efd1c3daf06c38cc0a', name: "leading-input" }), this.internalReadonly && (index.h("input", { key: 'f543f67c0360ac315ed873eb14a93af35dd90670', id: this.inputId + '-readonly', type: "text", value: this.computedDisplayValue, readonly: true, class: "readonly-input", "aria-readonly": "true", "aria-label": this.label, "aria-describedby": this.error
                    ? `${this.inputId}-error`
                    : `${this.inputId}-description` })), index.h("select", { key: 'b2ae3854c40ea798069417127cd763c8a0db040e', id: this.inputId, ref: el => (this.selectElement = el), name: this.name, autofocus: this.autofocus, disabled: this.disabled, required: this.required, multiple: this.multiple, onChange: this.handleSelectChange, class: this.internalReadonly ? 'hidden' : '', "aria-label": this.label, "aria-describedby": this.error
                    ? `${this.inputId}-error`
                    : `${this.inputId}-description` }, this.parsedOptions.length > 0 ? (this.parsedOptions.map(option => (index.h("option", { value: option.value, selected: option.selected, disabled: option.disabled }, option.label)))) : (index.h("slot", null))), index.h("div", { key: 'dd59af14105272eaa77218136f5b7b0b40a5b40b', class: "select-icons" }, this.error && (index.h("nv-icon", { key: '719e239472f6b697298682cc8d1b10933d3504ec', name: "alert-circle", class: "validation", size: "md" })), this.success && (index.h("nv-icon", { key: '5d63d5ddbcd8f46296bc067afd45f3921f4f3917', name: "circle-check", class: "validation", size: "md" })), !this.multiple && (index.h("nv-iconbutton", { key: '978a540682409a88ce55d2219dbeb9f2fc82cd51', name: "chevron-down", size: "md", emphasis: "lower", tabindex: -1 })))), index.h("slot", { key: '3483846a9f38be08caaf6f2b02332caefae0cbed', name: "after-input" })), (this.description ||
                this.el.querySelector('[slot="description"]')) && (index.h("div", { key: '5b47c05942549b6e2238696132ab2f3c9af5b7f0', class: "description", id: `${this.inputId}-description` }, index.h("slot", { key: '46b7f053ae343949b540240e1ec438850bb9a015', name: "description" }, this.description))), (this.errorDescription ||
                this.el.querySelector('[slot="error-description"]')) && (index.h("div", { key: '6126ab6967fc430c6a1d3ddfb191a98a8c2ecce9', class: "error-description", id: `${this.inputId}-error` }, index.h("slot", { key: 'afc6a0443c6fe1175213d36a2c59ffefe2923eab', name: "error-description" }, this.errorDescription)))));
        }
        static get formAssociated() { return true; }
        get el() { return index.getElement(this); }
        static get watchers() { return {
            "value": ["updateDisplayValueWatcher"],
            "displayValue": ["handleDisplayValueChange"],
            "readonly": ["handleReadonlyChange"],
            "options": ["handleOptionsChange"]
        }; }
    };
    NvFieldselect.style = NvFieldselectStyle0;

    exports.nv_fieldselect = NvFieldselect;

}));
