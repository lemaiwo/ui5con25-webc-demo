sap.ui.define(['exports'], (function (exports) { 'use strict';

    exports.FeedbackColors = void 0;
    (function (FeedbackColors) {
        FeedbackColors["Information"] = "information";
        FeedbackColors["Warning"] = "warning";
        FeedbackColors["Success"] = "success";
        FeedbackColors["Error"] = "error";
        FeedbackColors["Neutral"] = "neutral";
    })(exports.FeedbackColors || (exports.FeedbackColors = {}));
    var DeprecatedSemanticColors;
    (function (DeprecatedSemanticColors) {
        DeprecatedSemanticColors["Neutral"] = "neutral";
        DeprecatedSemanticColors["Primary"] = "primary";
        DeprecatedSemanticColors["Secondary"] = "secondary";
        DeprecatedSemanticColors["Success"] = "success";
        DeprecatedSemanticColors["Error"] = "error";
    })(DeprecatedSemanticColors || (DeprecatedSemanticColors = {}));
    exports.SemanticSizes = void 0;
    (function (SemanticSizes) {
        SemanticSizes["ExtraSmall"] = "xs";
        SemanticSizes["Small"] = "sm";
        SemanticSizes["Medium"] = "md";
        SemanticSizes["Large"] = "lg";
        SemanticSizes["ExtraLarge"] = "xl";
    })(exports.SemanticSizes || (exports.SemanticSizes = {}));
    exports.ButtonSize = void 0;
    (function (ButtonSize) {
        ButtonSize["ExtraSmall"] = "xs";
        ButtonSize["Small"] = "sm";
        ButtonSize["Medium"] = "md";
        ButtonSize["Large"] = "lg";
    })(exports.ButtonSize || (exports.ButtonSize = {}));
    var ButtonEmphasis;
    (function (ButtonEmphasis) {
        ButtonEmphasis["High"] = "high";
        ButtonEmphasis["Medium"] = "medium";
        ButtonEmphasis["Low"] = "low";
        ButtonEmphasis["Lower"] = "lower";
    })(ButtonEmphasis || (ButtonEmphasis = {}));
    exports.ButtonType = void 0;
    (function (ButtonType) {
        ButtonType["Submit"] = "submit";
        ButtonType["Reset"] = "reset";
        ButtonType["Button"] = "button";
    })(exports.ButtonType || (exports.ButtonType = {}));
    var IconButtonShape;
    (function (IconButtonShape) {
        IconButtonShape["Square"] = "square";
        IconButtonShape["Rounded"] = "rounded";
    })(IconButtonShape || (IconButtonShape = {}));
    var LoaderColors;
    (function (LoaderColors) {
        LoaderColors["High"] = "brand";
        LoaderColors["Low"] = "white";
    })(LoaderColors || (LoaderColors = {}));
    var LabelPlacement;
    (function (LabelPlacement) {
        LabelPlacement["Before"] = "before";
        LabelPlacement["After"] = "after";
    })(LabelPlacement || (LabelPlacement = {}));
    var TextInputAutocomplete;
    (function (TextInputAutocomplete) {
        TextInputAutocomplete["On"] = "on";
        TextInputAutocomplete["Off"] = "off";
        TextInputAutocomplete["Section"] = "section-*";
        TextInputAutocomplete["Shipping"] = "shipping";
        TextInputAutocomplete["Billing"] = "billing";
        TextInputAutocomplete["Home"] = "home";
        TextInputAutocomplete["Work"] = "work";
        TextInputAutocomplete["Mobile"] = "mobile";
        TextInputAutocomplete["Fax"] = "fax";
        TextInputAutocomplete["Pager"] = "pager";
        TextInputAutocomplete["Tel"] = "tel";
        TextInputAutocomplete["TelCountryCode"] = "tel-country-code";
        TextInputAutocomplete["TelNational"] = "tel-national";
        TextInputAutocomplete["TelAreaCode"] = "tel-area-code";
        TextInputAutocomplete["TelLocal"] = "tel-local";
        TextInputAutocomplete["TelLocalPrefix"] = "tel-local-prefix";
        TextInputAutocomplete["TelLocalSuffix"] = "tel-local-suffix";
        TextInputAutocomplete["TelExtension"] = "tel-extension";
        TextInputAutocomplete["Email"] = "email";
        TextInputAutocomplete["IMProtocol"] = "impp";
        TextInputAutocomplete["Name"] = "name";
        TextInputAutocomplete["HonorificPrefix"] = "honorific-prefix";
        TextInputAutocomplete["GivenName"] = "given-name";
        TextInputAutocomplete["AdditionalName"] = "additional-name";
        TextInputAutocomplete["FamilyName"] = "family-name";
        TextInputAutocomplete["HonorificSuffix"] = "honorific-suffix";
        TextInputAutocomplete["Nickname"] = "nickname";
        TextInputAutocomplete["Username"] = "username";
        TextInputAutocomplete["NewPassword"] = "new-password";
        TextInputAutocomplete["CurrentPassword"] = "current-password";
        TextInputAutocomplete["OneTimeCode"] = "one-time-code";
        TextInputAutocomplete["OrganizationTitle"] = "organization-title";
        TextInputAutocomplete["Organization"] = "organization";
        TextInputAutocomplete["StreetAddress"] = "street-address";
        TextInputAutocomplete["AddressLine1"] = "address-line1";
        TextInputAutocomplete["AddressLine2"] = "address-line2";
        TextInputAutocomplete["AddressLine3"] = "address-line3";
        TextInputAutocomplete["AddressLevel4"] = "address-level4";
        TextInputAutocomplete["AddressLevel3"] = "address-level3";
        TextInputAutocomplete["AddressLevel2"] = "address-level2";
        TextInputAutocomplete["AddressLevel1"] = "address-level1";
        TextInputAutocomplete["Country"] = "country";
        TextInputAutocomplete["CountryName"] = "country-name";
        TextInputAutocomplete["PostalCode"] = "postal-code";
        TextInputAutocomplete["CCName"] = "cc-name";
        TextInputAutocomplete["CCGivenName"] = "cc-given-name";
        TextInputAutocomplete["CCAdditionalName"] = "cc-additional-name";
        TextInputAutocomplete["CCFamilyName"] = "cc-family-name";
        TextInputAutocomplete["CCNumber"] = "cc-number";
        TextInputAutocomplete["CCExp"] = "cc-exp";
        TextInputAutocomplete["CCExpMonth"] = "cc-exp-month";
        TextInputAutocomplete["CCExpYear"] = "cc-exp-year";
        TextInputAutocomplete["CCCSC"] = "cc-csc";
        TextInputAutocomplete["CCType"] = "cc-type";
        TextInputAutocomplete["TransactionCurrency"] = "transaction-currency";
        TextInputAutocomplete["TransactionAmount"] = "transaction-amount";
        TextInputAutocomplete["Language"] = "language";
        TextInputAutocomplete["Bday"] = "bday";
        TextInputAutocomplete["BdayDay"] = "bday-day";
        TextInputAutocomplete["BdayMonth"] = "bday-month";
        TextInputAutocomplete["BdayYear"] = "bday-year";
        TextInputAutocomplete["Sex"] = "sex";
        TextInputAutocomplete["Url"] = "url";
        TextInputAutocomplete["Photo"] = "photo";
    })(TextInputAutocomplete || (TextInputAutocomplete = {}));
    exports.TimeType = void 0;
    (function (TimeType) {
        TimeType["Hours"] = "hours";
        TimeType["Minutes"] = "minutes";
        TimeType["Seconds"] = "seconds";
    })(exports.TimeType || (exports.TimeType = {}));
    const WEEK_ABBREVIATIONS = {
        'fr-FR': 'Sem', // Semaine
        'fr-BE': 'Sem', // Semaine
        'nl-BE': 'W', // Week
        'en-BE': 'W', // Week
        'en-US': 'W', // Week
        'en-GB': 'W', // Week
        'es-ES': 'Sem', // Semana
        'de-DE': 'KW', // Kalenderwoche
        'it-IT': 'Set', // Settimana
        'pt-PT': 'Sem', // Semana
        'nl-NL': 'W', // Week
        'pl-PL': 'Tyd', // Tydzień
        'ru-RU': 'Нед', // Неделя
        'ja-JP': '週', // Shū
        'zh-CN': '周', // Zhōu
        'ko-KR': '주', // Ju
    };
    const CUSTOM_DAY_NAMES = {
        'fr-BE': ['Lu', 'Ma', 'Me', 'Je', 'Ve', 'Sa', 'Di'],
        'nl-BE': ['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'],
        'de-DE': ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'],
        'en-BE': ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        'en-US': ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        'en-GB': ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    };
    const CUSTOM_MONTH_NAMES = {
        'fr-BE': [
            'Jan',
            'Fev',
            'Mar',
            'Avr',
            'Mai',
            'Jun',
            'Jul',
            'Aou',
            'Sep',
            'Oct',
            'Nov',
            'Dec',
        ],
        'nl-BE': [
            'Jan',
            'Feb',
            'Maa',
            'Apr',
            'Mei',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Okt',
            'Nov',
            'Dec',
        ],
        'de-DE': [
            'Jan',
            'Feb',
            'Mär',
            'Apr',
            'Mai',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Okt',
            'Nov',
            'Dez',
        ],
        'en-BE': [
            'Jan',
            'Feb',
            'Mar',
            'Apr',
            'May',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Oct',
            'Nov',
            'Dec',
        ],
        'en-US': [
            'Jan',
            'Feb',
            'Mar',
            'Apr',
            'May',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Oct',
            'Nov',
            'Dec',
        ],
        'en-GB': [
            'Jan',
            'Feb',
            'Mar',
            'Apr',
            'May',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Oct',
            'Nov',
            'Dec',
        ],
    };

    exports.CUSTOM_DAY_NAMES = CUSTOM_DAY_NAMES;
    exports.CUSTOM_MONTH_NAMES = CUSTOM_MONTH_NAMES;
    exports.WEEK_ABBREVIATIONS = WEEK_ABBREVIATIONS;

}));
