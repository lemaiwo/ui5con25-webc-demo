sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/fade.animation-2a077983'], (function (exports, fade_animation2a077983) { 'use strict';

    const useCollapse = (node, { duration } = { duration: 200 }) => {
        const nodeStyler = fade_animation2a077983.index(node);
        /**
         * Will set the overflow to hidden, and animate the max height to 0. Make sure
         * the element has no border or y padding set, otherwise the animation will
         * not work as expected.
         */
        function collapse() {
            return new Promise(resolve => {
                const height = node.getBoundingClientRect().height;
                nodeStyler.set({ overflow: 'hidden' });
                fade_animation2a077983.animate({
                    from: height,
                    to: 0,
                    duration,
                    onUpdate: value => {
                        nodeStyler.set({
                            maxHeight: value,
                        });
                    },
                    onComplete: () => {
                        resolve();
                    },
                });
            });
        }
        /**
         * Apply the collapsed styles without animating, useful when initial state
         * is collapsed.
         */
        function setCollapsed() {
            node.style.maxHeight = '0';
            node.style.overflow = 'hidden';
        }
        /**
         * Apply the expanded styles without animating, useful when initial state
         * is expanded.
         */
        function setExpanded() {
            node.style.maxHeight = '';
            node.style.overflow = '';
        }
        /**
         * Will set the overflow to hidden, and animate the max height to the value
         * of the scrollHeight. Make sure the element has no border or y padding set,
         * otherwise the animation will not work as expected. Once complete, the
         * max-height and overflow style properties will be removed.
         */
        function expand() {
            return new Promise(resolve => {
                const scrollHeight = node.scrollHeight;
                nodeStyler.set({
                    overflow: 'hidden',
                });
                fade_animation2a077983.animate({
                    from: 0,
                    to: scrollHeight,
                    duration,
                    onUpdate: value => {
                        nodeStyler.set({
                            maxHeight: value,
                        });
                    },
                    onComplete: () => {
                        node.style.removeProperty('max-height');
                        node.style.removeProperty('overflow');
                        resolve();
                    },
                });
            });
        }
        return {
            collapse,
            expand,
            setCollapsed,
            setExpanded,
        };
    };

    /**
     * Will execute a series of animation promises in sequence.
     * This is useful for chaining animations where each step depends on the
     * previous one completing before starting the next.
     *
     * @param {Array<() => Promise<void>>} animations - The array of animation functions.
     * @returns {Object} - An object with a `start` method to begin the timeline.
     *
     * @example
     * const { fadeOut } = useFade(this.ref);
     * const { collapse } = useCollapse(this.ref);
     *
     * timeline(fadeOut, collapse).start();
     */
    const timeline = (...animations) => ({
        start: () => {
            return animations.reduce((promise, animation) => promise.then(() => animation()), Promise.resolve());
        },
    });

    exports.timeline = timeline;
    exports.useCollapse = useCollapse;

}));
