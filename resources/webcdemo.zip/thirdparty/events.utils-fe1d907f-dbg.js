sap.ui.define(['exports'], (function (exports) { 'use strict';

    /**
     * Adds a set of event listeners to the given target.
     * @param {EventsAndListeners} events - The events and listeners to add.
     * @param {Element | Window | Document} target  - The target element or window to add the event listeners to.
     * @param {T} context - The class context to bind the event listeners to.
     */
    function addEventListeners(events, target, context) {
        events.forEach(([event, listener]) => target.addEventListener(event, listener.bind(context)));
    }
    /**
     * Removes a set of event listeners from the given target.
     * @param {EventsAndListeners} events - The events and listeners to remove.
     * @param {Element | Window | Document} target  - The target element or window to remove the event listeners from.
     * @param {T} context - The class context to bind the event listeners to.
     */
    function removeEventListeners(events, target, context) {
        events.forEach(([event, listener]) => target.removeEventListener(event, listener.bind(context)));
    }

    exports.addEventListeners = addEventListeners;
    exports.removeEventListeners = removeEventListeners;

}));
