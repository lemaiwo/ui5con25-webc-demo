sap.ui.define(['exports', 'be/wl/webc/demo/thirdparty/index2'], (function (exports, index) { 'use strict';



	exports.__esModule = index.__esModule;
	exports.defineCustomElements = index.defineCustomElements;
	exports.setNonce = index.setNonce;

}));
