sap.ui.define(function(){"use strict";return{formatValue:function(e){return e&&e.toUpperCase()}}});
//# sourceMappingURL=formatter.js.map